/** Site-wide settings. Edit these before you deploy, then run `npm run build`. */
export const SITE_NAME = 'IP Atlas';

/** Shown in the footer and API section as a contact link. Leave empty to hide it. */
export const CONTACT_EMAIL = '';

/** Short privacy statement shown in the footer. Keep it accurate for your own hosting setup. */
export const PRIVACY_NOTE =
  'Lookups are not stored or tracked by this site. Your host or CDN may keep standard access logs.';
