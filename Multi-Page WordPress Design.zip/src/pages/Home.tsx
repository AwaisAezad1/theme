type NavFn = (page: any) => void;

const stats = [
  { value: "340+", label: "Sites Launched" },
  { value: "98%", label: "Client Retention" },
  { value: "2.1s", label: "Avg Load Time" },
  { value: "$4.2M", label: "Revenue Generated" },
];

const services = [
  {
    num: "01",
    title: "WordPress Development",
    desc: "Custom themes, plugins, and WooCommerce stores built for performance and scale.",
  },
  {
    num: "02",
    title: "Conversion Design",
    desc: "Every pixel serves a purpose. We design to convert, not just to impress.",
  },
  {
    num: "03",
    title: "SEO & Performance",
    desc: "Core Web Vitals optimization, schema markup, and technical SEO that ranks.",
  },
  {
    num: "04",
    title: "Brand Strategy",
    desc: "Positioning, messaging, and visual identity that makes you the obvious choice.",
  },
];

const testimonials = [
  {
    quote: "Vantage tripled our leads within 60 days of launch. The site doesn't just look good — it sells.",
    author: "Sarah Chen",
    role: "CEO, Apex Consulting",
    img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&auto=format",
  },
  {
    quote: "We went from a DIY WordPress mess to a machine that generates $50k/month. Worth every penny.",
    author: "Marcus Williams",
    role: "Founder, TradeFlow SaaS",
    img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&auto=format",
  },
  {
    quote: "The attention to detail is unmatched. Our bounce rate dropped 40% and time-on-site doubled.",
    author: "Elena Vasquez",
    role: "Marketing Dir., Nova Health",
    img: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop&auto=format",
  },
];

export default function HomePage({ navigate }: { navigate: NavFn }) {
  return (
    <div>
      {/* HERO */}
      <section style={{ minHeight: "100vh", display: "grid", gridTemplateColumns: "1fr 1fr", position: "relative", overflow: "hidden" }}>
        {/* Left — dark */}
        <div style={{
          background: "#080808",
          display: "flex", flexDirection: "column", justifyContent: "center",
          padding: "8rem 4rem 6rem 6rem",
          position: "relative", zIndex: 2,
        }}>
          <div className="section-label fade-up" style={{ marginBottom: "2rem" }}>WordPress Agency — Est. 2018</div>
          <h1 className="font-display fade-up" style={{
            fontSize: "clamp(3rem, 5vw, 5.5rem)", fontWeight: 900, lineHeight: 1.05,
            letterSpacing: "-0.02em", marginBottom: "2rem", animationDelay: "0.1s"
          }}>
            Sites That <br />
            <em style={{ color: "#FF5500", fontStyle: "italic" }}>Actually</em><br />
            Sell.
          </h1>
          <p className="fade-up" style={{ color: "#999", fontSize: "1.05rem", lineHeight: 1.8, maxWidth: 420, marginBottom: "2.5rem", animationDelay: "0.2s" }}>
            We build WordPress websites engineered for one outcome: turning your visitors into paying customers. No fluff. No filler. Just results.
          </p>
          <div className="fade-up" style={{ display: "flex", gap: "1rem", flexWrap: "wrap", animationDelay: "0.3s" }}>
            <button className="btn-primary" onClick={() => navigate("Contact")}>Start Your Project</button>
            <button className="btn-ghost" onClick={() => navigate("Portfolio")}>View Our Work</button>
          </div>

          {/* Stats row */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem", marginTop: "4rem", paddingTop: "3rem", borderTop: "1px solid #1A1A1A" }}>
            {stats.map((s) => (
              <div key={s.label}>
                <div className="font-display" style={{ fontSize: "2rem", fontWeight: 700, color: "#F4EFE6" }}>{s.value}</div>
                <div style={{ fontSize: "0.75rem", color: "#555", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginTop: "0.25rem" }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right — image */}
        <div style={{ position: "relative", overflow: "hidden", background: "#111" }}>
          <img
            src="https://images.unsplash.com/photo-1551434678-e076c223a692?w=900&h=1100&fit=crop&auto=format"
            alt="Team working on website design"
            style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.7 }}
          />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, rgba(8,8,8,0.5) 0%, transparent 60%)" }} />
          {/* Floating badge */}
          <div style={{
            position: "absolute", bottom: "3rem", right: "2rem",
            background: "#FF5500", padding: "1.5rem", maxWidth: 200,
          }}>
            <div className="font-display" style={{ fontSize: "1.8rem", fontWeight: 900, color: "#080808", lineHeight: 1 }}>Top 1%</div>
            <div style={{ fontSize: "0.72rem", fontWeight: 700, color: "#080808", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: "0.5rem" }}>WordPress Agencies Worldwide</div>
          </div>
        </div>

        <style>{`
          @media (max-width: 900px) {
            section[style*="grid-template-columns: 1fr 1fr"] {
              grid-template-columns: 1fr !important;
              min-height: auto !important;
            }
          }
        `}</style>
      </section>

      {/* MARQUEE TICKER */}
      <div style={{ background: "#FF5500", padding: "0.9rem 0", overflow: "hidden", whiteSpace: "nowrap" }}>
        <div style={{ display: "inline-flex", gap: "4rem", animation: "marquee 20s linear infinite" }}>
          {Array(4).fill(["WordPress Development", "Conversion Optimization", "SEO", "WooCommerce", "Brand Strategy", "Custom Plugins"]).flat().map((item, i) => (
            <span key={i} style={{ fontFamily: "'Outfit', sans-serif", fontSize: "0.78rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "#080808" }}>
              {item} ◆
            </span>
          ))}
        </div>
        <style>{`@keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }`}</style>
      </div>

      {/* SERVICES GRID */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "7rem 2rem" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "4rem", flexWrap: "wrap", gap: "2rem" }}>
          <div>
            <div className="section-label" style={{ marginBottom: "1rem" }}>What We Do</div>
            <h2 className="font-display" style={{ fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 700, lineHeight: 1.1, letterSpacing: "-0.02em", maxWidth: 500 }}>
              Every service built to grow your revenue.
            </h2>
          </div>
          <button className="btn-ghost" onClick={() => navigate("Services")}>All Services →</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "1px", background: "#1A1A1A" }}>
          {services.map((s, i) => (
            <div key={i} className="card-hover" style={{ background: "#080808", padding: "3rem 2.5rem" }}>
              <div style={{ fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.15em", color: "#FF5500", marginBottom: "2rem" }}>{s.num}</div>
              <h3 className="font-display" style={{ fontSize: "1.3rem", fontWeight: 600, marginBottom: "1rem", lineHeight: 1.3 }}>{s.title}</h3>
              <p style={{ color: "#666", fontSize: "0.9rem", lineHeight: 1.8 }}>{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED WORK */}
      <section style={{ background: "#0D0D0D", padding: "7rem 2rem" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          <div className="section-label" style={{ marginBottom: "1rem" }}>Featured Work</div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "4rem", flexWrap: "wrap", gap: "1rem" }}>
            <h2 className="font-display" style={{ fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 700, letterSpacing: "-0.02em" }}>Work that speaks for itself.</h2>
            <button className="btn-ghost" onClick={() => navigate("Portfolio")}>Full Portfolio →</button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "1.5rem" }}>
            <div className="card-hover" style={{ position: "relative", overflow: "hidden", background: "#111", aspectRatio: "16/9" }}>
              <img src="https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=900&h=500&fit=crop&auto=format" alt="Apex Consulting website project" style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.6 }} />
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,0.85) 0%, transparent 60%)" }} />
              <div style={{ position: "absolute", bottom: "2rem", left: "2rem" }}>
                <div className="section-label" style={{ marginBottom: "0.5rem" }}>B2B SaaS</div>
                <div className="font-display" style={{ fontSize: "1.5rem", fontWeight: 700 }}>Apex Consulting</div>
              </div>
              <div style={{ position: "absolute", top: "1.5rem", right: "1.5rem", background: "#FF5500", padding: "0.4rem 0.9rem", fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#080808" }}>+312% Leads</div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
              {[
                { img: "photo-1556742049-0cfed4f6a45d", label: "E-commerce", name: "LuxWear Shop", result: "+$200k MRR", h: 500 },
                { img: "photo-1460925895917-afdab827c52f", label: "FinTech", name: "TradeFlow", result: "2.8s → 0.9s", h: 500 },
              ].map((p, i) => (
                <div key={i} className="card-hover" style={{ position: "relative", overflow: "hidden", background: "#111", flex: 1, minHeight: 140 }}>
                  <img src={`https://images.unsplash.com/photo-${p.img}?w=500&h=${p.h}&fit=crop&auto=format`} alt={p.name + " project"} style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.55 }} />
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,0.85) 0%, transparent 60%)" }} />
                  <div style={{ position: "absolute", bottom: "1.2rem", left: "1.5rem" }}>
                    <div style={{ fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.12em", color: "#FF5500", textTransform: "uppercase", marginBottom: "0.3rem" }}>{p.label}</div>
                    <div className="font-display" style={{ fontSize: "1.1rem", fontWeight: 700 }}>{p.name}</div>
                  </div>
                  <div style={{ position: "absolute", top: "1rem", right: "1rem", background: "rgba(255,85,0,0.9)", padding: "0.3rem 0.7rem", fontSize: "0.68rem", fontWeight: 700, color: "#080808" }}>{p.result}</div>
                </div>
              ))}
            </div>
          </div>

          <style>{`
            @media (max-width: 768px) {
              div[style*="grid-template-columns: 2fr 1fr"] { grid-template-columns: 1fr !important; }
            }
          `}</style>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "7rem 2rem" }}>
        <div className="section-label" style={{ marginBottom: "1rem" }}>Client Stories</div>
        <h2 className="font-display" style={{ fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "4rem", maxWidth: 500 }}>
          Results, not just reviews.
        </h2>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "2rem" }}>
          {testimonials.map((t, i) => (
            <div key={i} className="card-hover" style={{ background: "#111", padding: "2.5rem", borderTop: "3px solid #FF5500" }}>
              <p style={{ color: "#CCC", fontSize: "0.95rem", lineHeight: 1.85, marginBottom: "2rem", fontStyle: "italic" }}>"{t.quote}"</p>
              <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                <img src={t.img} alt={t.author} style={{ width: 44, height: 44, borderRadius: "50%", objectFit: "cover" }} />
                <div>
                  <div style={{ fontWeight: 600, fontSize: "0.9rem" }}>{t.author}</div>
                  <div style={{ color: "#555", fontSize: "0.78rem" }}>{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BAND */}
      <section style={{ background: "#FF5500", padding: "6rem 2rem" }}>
        <div style={{ maxWidth: 800, margin: "0 auto", textAlign: "center" }}>
          <h2 className="font-display" style={{ fontSize: "clamp(2rem, 4vw, 3.8rem)", fontWeight: 900, color: "#080808", letterSpacing: "-0.02em", lineHeight: 1.1, marginBottom: "1.5rem" }}>
            Ready to build a site that actually sells?
          </h2>
          <p style={{ color: "rgba(0,0,0,0.65)", fontSize: "1.05rem", lineHeight: 1.7, marginBottom: "2.5rem" }}>
            Free strategy call. No pitch. Just an honest look at what's working and what isn't.
          </p>
          <button onClick={() => navigate("Contact")} style={{
            background: "#080808", color: "#F4EFE6", fontFamily: "'Outfit', sans-serif",
            fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", fontSize: "0.82rem",
            padding: "1rem 2.8rem", border: "none", cursor: "pointer", transition: "background 0.2s",
          }}
            onMouseEnter={e => (e.currentTarget.style.background = "#1A1A1A")}
            onMouseLeave={e => (e.currentTarget.style.background = "#080808")}
          >
            Book Free Strategy Call →
          </button>
        </div>
      </section>
    </div>
  );
}
