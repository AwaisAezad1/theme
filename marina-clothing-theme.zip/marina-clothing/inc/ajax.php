<?php
/**
 * AJAX handlers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Store a newsletter sign-up.
 *
 * Emails are kept in the `marina_newsletter_subscribers` option and the
 * `marina_newsletter_subscribed` action fires so an ESP integration
 * (Mailchimp, Klaviyo, …) can hook in.
 *
 * @return true|WP_Error
 */
function marina_newsletter_store( $raw_email ) {
    $email = sanitize_email( $raw_email );

    if ( ! is_email( $email ) ) {
        return new WP_Error( 'invalid_email', __( 'Please enter a valid email address.', 'marina-clothing' ) );
    }

    $list = get_option( 'marina_newsletter_subscribers', array() );
    if ( ! is_array( $list ) ) {
        $list = array();
    }

    if ( ! isset( $list[ $email ] ) ) {
        $list[ $email ] = time();
        update_option( 'marina_newsletter_subscribers', $list, false );
        do_action( 'marina_newsletter_subscribed', $email );
    }

    return true;
}

/**
 * AJAX endpoint.
 */
function marina_newsletter_ajax() {
    check_ajax_referer( 'marina_nonce', 'nonce' );

    $result = marina_newsletter_store( isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
    }

    wp_send_json_success( array( 'message' => __( 'Welcome, you are on the list.', 'marina-clothing' ) ) );
}
add_action( 'wp_ajax_marina_newsletter', 'marina_newsletter_ajax' );
add_action( 'wp_ajax_nopriv_marina_newsletter', 'marina_newsletter_ajax' );

/**
 * No-JS fallback (admin-post.php).
 */
function marina_newsletter_post() {
    $ok = isset( $_POST['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'marina_nonce' );

    if ( $ok ) {
        $ok = ! is_wp_error( marina_newsletter_store( isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
    }

    $back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
    wp_safe_redirect( add_query_arg( 'subscribed', $ok ? '1' : '0', $back ) );
    exit;
}
add_action( 'admin_post_marina_newsletter', 'marina_newsletter_post' );
add_action( 'admin_post_nopriv_marina_newsletter', 'marina_newsletter_post' );
