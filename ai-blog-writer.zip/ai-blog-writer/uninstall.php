<?php
/**
 * Runs when the plugin is deleted from the Plugins screen.
 * Removes plugin settings (including saved API keys) and the error log.
 * Blogs you already added stay on your site; only the hidden tracking fields are removed.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

function aibw_uninstall_site() {
	delete_option( 'aibw_settings' );
	delete_option( 'aibw_log' );
	delete_option( 'aibw_db_version' );
	delete_option( 'aibw_last_run' );
	delete_option( 'aibw_run_state' );
	delete_option( 'aibw_automation_lock' );
	global $wpdb;
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aibw_topics" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aibw_jobs" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aibw_logs" );
	delete_post_meta_by_key( '_aibw_generated' );
	delete_post_meta_by_key( '_aibw_provider' );
	delete_post_meta_by_key( '_aibw_topic' );
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $site_id ) {
		switch_to_blog( $site_id );
		aibw_uninstall_site();
		restore_current_blog();
	}
} else {
	aibw_uninstall_site();
}
