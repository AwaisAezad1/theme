<?php
/**
 * Plugin Name: AI Blog Writer
 * Description: Type a topic, pick an AI (ChatGPT, Claude, Gemini, Perplexity or free Groq), and add the finished blog to your front page in one click.
 * Version: 1.2.1
 * Author: AI Blog Writer
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ai-blog-writer
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * Adapted from "AI Blog Automator" by Bluteem LLC (GPL v2 or later).
 */

defined( 'ABSPATH' ) || exit;

define( 'AIBW_VERSION', '1.2.1' );
define( 'AIBW_DB_VERSION', '1' );
define( 'AIBW_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIBW_URL', plugin_dir_url( __FILE__ ) );
define( 'AIBW_BASENAME', plugin_basename( __FILE__ ) );

require_once AIBW_DIR . 'includes/class-aibw-settings.php';
require_once AIBW_DIR . 'includes/class-aibw-providers.php';
require_once AIBW_DIR . 'includes/class-aibw-images.php';
require_once AIBW_DIR . 'includes/class-aibw-generator.php';
require_once AIBW_DIR . 'includes/class-aibw-admin.php';
require_once AIBW_DIR . 'includes/class-aibw-db.php';
require_once AIBW_DIR . 'includes/class-aibw-topics.php';
require_once AIBW_DIR . 'includes/class-aibw-jobs.php';
require_once AIBW_DIR . 'includes/class-aibw-research.php';
require_once AIBW_DIR . 'includes/class-aibw-seo.php';
require_once AIBW_DIR . 'includes/class-aibw-scheduler.php';
require_once AIBW_DIR . 'includes/class-aibw-automation.php';

/**
 * Activation: store defaults once.
 */
function aibw_activate() {
	if ( false === get_option( AIBW_Settings::OPTION ) ) {
		add_option( AIBW_Settings::OPTION, AIBW_Settings::defaults() );
	}
	AIBW_DB::install();
	AIBW_Scheduler::restore();
}
register_activation_hook( __FILE__, 'aibw_activate' );

/**
 * Deactivation removes only this plugin's scheduled events.
 * Posts, credentials, history and job rows are left in place.
 */
function aibw_deactivate() {
	AIBW_Scheduler::unschedule();
	delete_option( AIBW_Scheduler::LOCK );
}
register_deactivation_hook( __FILE__, 'aibw_deactivate' );

add_action( 'plugins_loaded', array( 'AIBW_DB', 'maybe_upgrade' ) );

/**
 * Shortcode: [aibw_latest_blogs count="3"]
 * Useful when the site's front page is a static page instead of the blog posts list.
 */
function aibw_latest_blogs_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'count' => 3 ), $atts, 'aibw_latest_blogs' );
	$count = max( 1, min( 20, (int) $atts['count'] ) );

	$query = new WP_Query(
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $count,
			'ignore_sticky_posts' => true,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'            => '_aibw_generated',
			'meta_value'          => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);

	if ( ! $query->have_posts() ) {
		return '';
	}

	$out = '<ul class="aibw-latest-blogs">';
	while ( $query->have_posts() ) {
		$query->the_post();
		$thumb = has_post_thumbnail() ? '<a class="aibw-latest-thumb" href="' . esc_url( get_permalink() ) . '" tabindex="-1" aria-hidden="true">' . get_the_post_thumbnail( null, 'medium_large' ) . '</a>' : '';
		$out  .= '<li>' . $thumb . '<a class="aibw-latest-title" href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a>'
			. '<small>' . esc_html( get_the_date() ) . '</small>'
			. '<p>' . esc_html( wp_trim_words( get_the_excerpt(), 28 ) ) . '</p></li>';
	}
	wp_reset_postdata();

	return $out . '</ul>';
}
add_shortcode( 'aibw_latest_blogs', 'aibw_latest_blogs_shortcode' );

/**
 * Front-end (and block editor) styling so pictures inside blogs are centred and neat in any theme.
 */
function aibw_front_styles() {
	wp_enqueue_style( 'aibw-front', AIBW_URL . 'assets/front.css', array(), AIBW_VERSION );
}
add_action( 'enqueue_block_assets', 'aibw_front_styles' );

AIBW_Admin::init();
AIBW_Scheduler::init();
AIBW_Automation::init();
