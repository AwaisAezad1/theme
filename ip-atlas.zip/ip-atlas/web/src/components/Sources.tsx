import type { ProviderInfo } from '../types';
import { formatDate } from '../lib/format';

const COPY = [
  {
    id: 'maxmind' as const,
    name: 'MaxMind',
    product: 'GeoLite2 City & ASN',
    text: 'Country, region, city, postal code, coordinates, accuracy radius and timezone, plus network ownership (ASN).',
    attribution: (
      <>This product includes GeoLite2 data created by <a className="text-cyan-300 underline" href="https://www.maxmind.com" target="_blank" rel="noopener noreferrer">MaxMind</a>.</>
    ),
  },
  {
    id: 'ipinfo' as const,
    name: 'IPinfo',
    product: 'IPinfo data',
    text: 'Country, continent and network (ASN, organization, domain). City-level data is included with IPinfo paid plans.',
    attribution: (
      <>IP address data powered by <a className="text-cyan-300 underline" href="https://ipinfo.io" target="_blank" rel="noopener noreferrer">IPinfo</a>.</>
    ),
  },
  {
    id: 'ip2location' as const,
    name: 'IP2Location',
    product: 'IP2Location LITE DB11',
    text: 'Country, region, city, postal code, coordinates and UTC offset.',
    attribution: (
      <>This site includes IP2Location LITE data available from <a className="text-cyan-300 underline" href="https://lite.ip2location.com" target="_blank" rel="noopener noreferrer">lite.ip2location.com</a>.</>
    ),
  },
];

export default function Sources({ infos }: { infos: ProviderInfo[] }) {
  return (
    <section id="sources" className="border-t border-white/[0.06]">
      <div className="mx-auto max-w-7xl px-5 py-16 lg:px-8 lg:py-24">
        <p className="section-label">Data sources</p>
        <h2 className="mt-3 max-w-2xl text-3xl font-semibold tracking-[-0.03em] text-white sm:text-4xl">Three providers, one answer you can double-check.</h2>
        <p className="mt-4 max-w-2xl leading-7 text-slate-400">
          Each provider builds its database differently, so results can vary. Seeing them together shows you how confident you can be.
        </p>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {COPY.map((c) => {
            const info = infos.find((i) => i.id === c.id);
            return (
              <article key={c.id} className="data-card flex flex-col">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-lg font-semibold text-white">{c.name}</h3>
                  {info && (
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${info.loaded ? 'bg-emerald-400/10 text-emerald-300' : 'bg-slate-500/15 text-slate-400'}`}>
                      {info.loaded ? 'Active' : 'Unavailable'}
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs text-slate-500">
                  {c.product}
                  {info?.database_date ? ` · updated ${formatDate(info.database_date)}` : ''}
                </p>
                <p className="mt-4 flex-1 text-sm leading-6 text-slate-400">{c.text}</p>
                <p className="mt-5 border-t border-white/[0.06] pt-4 text-xs leading-5 text-slate-500">{c.attribution}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
