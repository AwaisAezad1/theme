<?php get_header(); ?>

<main id="primary" class="site-content">
    <div class="container">

        <h1><?php esc_html_e( 'Page Not Found', 'wp-developer-starter' ); ?></h1>

        <p>
            <?php esc_html_e(
                'The page you are looking for does not exist.',
                'wp-developer-starter'
            ); ?>
        </p>

        <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
            <?php esc_html_e( 'Back to Home', 'wp-developer-starter' ); ?>
        </a>

    </div>
</main>

<?php get_footer(); ?>
