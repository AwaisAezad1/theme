<?php
/**
 * "History" page - recent AI blogs and the error log.
 *
 * Variables: $posts, $log, $msg
 */
defined( 'ABSPATH' ) || exit;
$providers = AIBW_Providers::all();
?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'History', 'ai-blog-writer' ); ?></h1>

	<?php if ( $msg ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div>
	<?php endif; ?>

	<div class="aibw-card">
		<h2><?php esc_html_e( 'Blogs written with AI Blog Writer', 'ai-blog-writer' ); ?></h2>
		<?php if ( empty( $posts ) ) : ?>
			<p><?php esc_html_e( 'Nothing here yet. Your first blog will show up after you add it or save it as a draft.', 'ai-blog-writer' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Title', 'ai-blog-writer' ); ?></th>
						<th><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?></th>
						<th><?php esc_html_e( 'AI', 'ai-blog-writer' ); ?></th>
						<th><?php esc_html_e( 'Status', 'ai-blog-writer' ); ?></th>
						<th><?php esc_html_e( 'Date', 'ai-blog-writer' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $posts as $post ) :
						$pid = get_post_meta( $post->ID, '_aibw_provider', true );
						?>
						<tr>
							<td>
								<?php if ( current_user_can( 'edit_post', $post->ID ) ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $post->ID, 'raw' ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a>
								<?php else : ?>
									<?php echo esc_html( get_the_title( $post ) ); ?>
								<?php endif; ?>
								<?php if ( is_sticky( $post->ID ) ) : ?>
									<span class="aibw-badge aibw-badge-ok"><?php esc_html_e( 'On front page', 'ai-blog-writer' ); ?></span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( wp_trim_words( (string) get_post_meta( $post->ID, '_aibw_topic', true ), 10 ) ); ?></td>
							<td><?php echo esc_html( isset( $providers[ $pid ] ) ? $providers[ $pid ]['short'] : '-' ); ?></td>
							<td><?php echo esc_html( get_post_status_object( $post->post_status )->label ); ?></td>
							<td><?php echo esc_html( get_the_date( '', $post ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>

	<div class="aibw-card">
		<h2><?php esc_html_e( 'Recent errors', 'ai-blog-writer' ); ?></h2>
		<?php if ( empty( $log ) ) : ?>
			<p><?php esc_html_e( 'No errors. Everything is working.', 'ai-blog-writer' ); ?></p>
		<?php else : ?>
			<ul class="aibw-log">
				<?php foreach ( $log as $entry ) : ?>
					<li>
						<span class="aibw-log-time"><?php echo esc_html( $entry['time'] ); ?></span>
						<?php if ( ! empty( $entry['provider'] ) ) : ?>
							<strong><?php echo esc_html( AIBW_Providers::label( $entry['provider'] ) ); ?>:</strong>
						<?php endif; ?>
						<?php echo esc_html( $entry['message'] ); ?>
					</li>
				<?php endforeach; ?>
			</ul>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="aibw_clear_log">
				<?php wp_nonce_field( 'aibw_clear_log' ); ?>
				<?php submit_button( __( 'Clear error log', 'ai-blog-writer' ), 'secondary', 'submit', false ); ?>
			</form>
		<?php endif; ?>
	</div>
</div>
