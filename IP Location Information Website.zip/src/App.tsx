import { FormEvent, useEffect, useState } from "react";

type IpInfo = {
  ip: string;
  type: string;
  continent: string;
  country: string;
  country_code: string;
  region: string;
  city: string;
  postal: string;
  latitude: number;
  longitude: number;
  connection: {
    asn: number;
    org: string;
    isp: string;
  };
  timezone: {
    id: string;
    utc: string;
    current_time: string;
  };
  flag: { emoji: string };
};

const fallbackInfo: IpInfo = {
  ip: "8.8.8.8",
  type: "IPv4",
  continent: "North America",
  country: "United States",
  country_code: "US",
  region: "California",
  city: "Mountain View",
  postal: "94043",
  latitude: 37.4056,
  longitude: -122.0775,
  connection: { asn: 15169, org: "Google LLC", isp: "Google LLC" },
  timezone: {
    id: "America/Los_Angeles",
    utc: "UTC -07:00",
    current_time: "2025-05-22T10:24:18-07:00",
  },
  flag: { emoji: "US" },
};

const codeExamples = {
  cURL: `curl "https://api.ipatlas.io/v1/8.8.8.8" \\
  -H "Authorization: Bearer YOUR_API_KEY"`,
  JavaScript: `const response = await fetch(
  "https://api.ipatlas.io/v1/8.8.8.8",
  {
    headers: {
      Authorization: "Bearer YOUR_API_KEY"
    }
  }
);

const data = await response.json();`,
  Python: `import requests

response = requests.get(
    "https://api.ipatlas.io/v1/8.8.8.8",
    headers={"Authorization": "Bearer YOUR_API_KEY"}
)

data = response.json()`,
};

function LogoMark() {
  return (
    <svg viewBox="0 0 36 36" className="h-9 w-9" aria-hidden="true">
      <path
        fill="currentColor"
        d="M18 2.5A12.5 12.5 0 0 0 5.5 15c0 9.5 12.5 18.5 12.5 18.5S30.5 24.5 30.5 15A12.5 12.5 0 0 0 18 2.5Zm0 17.2a4.8 4.8 0 1 1 0-9.6 4.8 4.8 0 0 1 0 9.6Z"
      />
      <circle cx="18" cy="15" r="2.2" fill="#07111f" />
    </svg>
  );
}

function Icon({
  name,
  className = "h-5 w-5",
}: {
  name: "search" | "locate" | "copy" | "arrow" | "pin" | "network" | "clock" | "code";
  className?: string;
}) {
  const paths = {
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    locate: <><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3" /><circle cx="12" cy="12" r="8" /></>,
    copy: <><rect x="8" y="8" width="11" height="11" rx="2" /><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" /></>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5" /></>,
    pin: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    network: <><circle cx="12" cy="5" r="2" /><circle cx="5" cy="18" r="2" /><circle cx="19" cy="18" r="2" /><path d="M12 7v4M5 16v-3h14v3" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    code: <><path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14" /></>,
  };
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}

function DataCard({
  icon,
  title,
  children,
}: {
  icon: "pin" | "network" | "clock";
  title: string;
  children: React.ReactNode;
}) {
  return (
    <article className="data-card">
      <div className="mb-6 flex items-center gap-3">
        <span className="rounded-lg bg-cyan-400/10 p-2 text-cyan-300">
          <Icon name={icon} className="h-[18px] w-[18px]" />
        </span>
        <h3 className="text-sm font-semibold tracking-wide text-white">{title}</h3>
      </div>
      {children}
    </article>
  );
}

function Row({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex items-start justify-between gap-5 border-b border-white/[0.06] py-3.5 last:border-0">
      <dt className="text-sm text-slate-500">{label}</dt>
      <dd className="max-w-[65%] text-right text-sm font-medium text-slate-200">{value || "—"}</dd>
    </div>
  );
}

export default function App() {
  const [query, setQuery] = useState("");
  const [info, setInfo] = useState<IpInfo>(fallbackInfo);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [activeCode, setActiveCode] = useState<keyof typeof codeExamples>("cURL");
  const [copied, setCopied] = useState(false);

  async function lookup(ip = "") {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`https://ipwho.is/${encodeURIComponent(ip.trim())}`);
      const data = await response.json();
      if (!response.ok || data.success === false) {
        throw new Error(data.message || "We couldn't find that IP address.");
      }
      setInfo(data);
      if (ip) setQuery(data.ip);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Lookup failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    lookup();
  }, []);

  function submit(event: FormEvent) {
    event.preventDefault();
    if (!query.trim()) {
      lookup();
      return;
    }
    const isIp = /^((\d{1,3}\.){3}\d{1,3}|[a-fA-F0-9:]+)$/.test(query.trim());
    if (!isIp) {
      setError("Enter a valid IPv4 or IPv6 address.");
      return;
    }
    lookup(query);
  }

  async function copyCode() {
    await navigator.clipboard.writeText(codeExamples[activeCode]);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  const coordinates = `${Number(info.latitude).toFixed(4)}, ${Number(info.longitude).toFixed(4)}`;
  const localTime = info.timezone.current_time
    ? new Date(info.timezone.current_time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : "—";

  return (
    <div className="min-h-screen overflow-hidden bg-[#07111f] text-slate-300">
      <header className="relative z-20 border-b border-white/[0.07] bg-[#07111f]/90 backdrop-blur">
        <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 lg:px-8">
          <a href="#" className="flex items-center gap-2.5 text-cyan-300">
            <LogoMark />
            <span className="text-lg font-bold tracking-tight text-white">IP Atlas</span>
          </a>
          <nav className="hidden items-center gap-8 text-sm md:flex">
            <a href="#lookup" className="text-white">IP Lookup</a>
            <a href="#api" className="transition hover:text-white">API</a>
            <a href="#features" className="transition hover:text-white">Features</a>
          </nav>
          <a href="#api" className="button-secondary">
            Get API key <Icon name="arrow" className="h-4 w-4" />
          </a>
        </div>
      </header>

      <main>
        <section id="lookup" className="hero-grid relative border-b border-white/[0.06]">
          <div className="orb orb-one" />
          <div className="orb orb-two" />
          <div className="relative mx-auto max-w-7xl px-5 pb-16 pt-20 text-center lg:px-8 lg:pb-20 lg:pt-24">
            <div className="eyebrow mx-auto mb-6">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-300 shadow-[0_0_8px_#67e8f9]" />
              Fast, accurate IP intelligence
            </div>
            <h1 className="mx-auto max-w-4xl text-4xl font-semibold leading-[1.08] tracking-[-0.04em] text-white sm:text-6xl lg:text-[68px]">
              Know where any <span className="text-gradient">IP lives.</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-7 text-slate-400 sm:text-lg">
              Instantly uncover location, network, and timezone data for any IPv4 or IPv6 address.
            </p>

            <form onSubmit={submit} className="mx-auto mt-10 max-w-3xl">
              <div className="search-shell">
                <Icon name="search" className="ml-1 h-5 w-5 shrink-0 text-slate-500" />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Enter an IP address, e.g. 8.8.8.8"
                  aria-label="IP address"
                  className="min-w-0 flex-1 bg-transparent px-2 text-sm text-white outline-none placeholder:text-slate-600 sm:px-3 sm:text-base"
                />
                <button type="button" onClick={() => lookup()} className="detect-button">
                  <Icon name="locate" className="h-4 w-4" />
                  <span className="hidden sm:inline">Use my IP</span>
                </button>
                <button type="submit" className="lookup-button" disabled={loading}>
                  {loading ? "Locating…" : "Look up"}
                </button>
              </div>
              {error ? (
                <p className="mt-3 text-left text-sm text-rose-400">{error}</p>
              ) : (
                <p className="mt-3 text-left text-xs text-slate-600">Supports public IPv4 and IPv6 addresses</p>
              )}
            </form>
          </div>
        </section>

        <section className="relative mx-auto max-w-7xl px-5 py-16 lg:px-8 lg:py-20">
          <div className="mb-7 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
            <div>
              <p className="section-label">Lookup result</p>
              <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white">IP intelligence overview</h2>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
              Live data
            </div>
          </div>

          <div className={`result-panel ${loading ? "opacity-50" : ""}`}>
            <div className="relative z-10 flex flex-col justify-between gap-8 p-6 sm:flex-row sm:items-end lg:p-9">
              <div>
                <div className="mb-3 flex items-center gap-3">
                  <span className="rounded bg-cyan-400/10 px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-cyan-300">
                    {info.type}
                  </span>
                  <span className="text-xs text-slate-500">Public address</span>
                </div>
                <p className="font-mono text-3xl font-semibold tracking-tight text-white sm:text-4xl">{info.ip}</p>
              </div>
              <div className="sm:text-right">
                <p className="text-sm text-slate-500">Approximate location</p>
                <p className="mt-1 text-lg font-medium text-white">
                  {info.city}, {info.country}
                </p>
              </div>
            </div>
            <div className="map-lines" aria-hidden="true">
              <span className="map-pulse" />
            </div>
          </div>

          <div className="mt-5 grid gap-5 md:grid-cols-3">
            <DataCard icon="pin" title="Location">
              <dl>
                <Row label="Country" value={`${info.country} (${info.country_code})`} />
                <Row label="Region" value={info.region} />
                <Row label="City" value={info.city} />
                <Row label="Postal code" value={info.postal} />
                <Row label="Coordinates" value={coordinates} />
              </dl>
            </DataCard>
            <DataCard icon="network" title="Network">
              <dl>
                <Row label="ISP" value={info.connection.isp} />
                <Row label="Organization" value={info.connection.org} />
                <Row label="ASN" value={`AS${info.connection.asn}`} />
                <Row label="IP type" value={info.type} />
                <Row label="Connection" value="Business" />
              </dl>
            </DataCard>
            <DataCard icon="clock" title="Time & timezone">
              <dl>
                <Row label="Timezone" value={info.timezone.id} />
                <Row label="UTC offset" value={info.timezone.utc} />
                <Row label="Local time" value={localTime} />
                <Row label="Continent" value={info.continent} />
                <Row label="Currency" value={info.country_code === "US" ? "USD" : "Local currency"} />
              </dl>
            </DataCard>
          </div>
        </section>

        <section id="api" className="border-y border-white/[0.06] bg-[#091522]">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-[0.8fr_1.2fr] lg:items-center lg:px-8 lg:py-28">
            <div>
              <p className="section-label">Built for developers</p>
              <h2 className="mt-4 text-3xl font-semibold leading-tight tracking-[-0.03em] text-white sm:text-4xl">
                IP intelligence in a single request.
              </h2>
              <p className="mt-5 max-w-lg leading-7 text-slate-400">
                A fast, reliable REST API with global coverage. Integrate precise IP data into your app in minutes, not days.
              </p>
              <div id="features" className="mt-8 grid grid-cols-2 gap-5 text-sm">
                {["99.99% uptime", "< 50ms response", "IPv4 & IPv6", "Simple REST API"].map((item) => (
                  <div key={item} className="flex items-center gap-2.5 text-slate-300">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-cyan-400/10 text-xs text-cyan-300">✓</span>
                    {item}
                  </div>
                ))}
              </div>
              <a href="#" className="mt-9 inline-flex items-center gap-2 font-semibold text-cyan-300 transition hover:text-cyan-200">
                Read the documentation <Icon name="arrow" className="h-4 w-4" />
              </a>
            </div>

            <div className="code-window">
              <div className="flex items-center justify-between border-b border-white/[0.08] px-4 sm:px-6">
                <div className="flex">
                  {(Object.keys(codeExamples) as Array<keyof typeof codeExamples>).map((language) => (
                    <button
                      key={language}
                      onClick={() => setActiveCode(language)}
                      className={`code-tab ${activeCode === language ? "active" : ""}`}
                    >
                      {language}
                    </button>
                  ))}
                </div>
                <button onClick={copyCode} className="text-slate-500 transition hover:text-white" aria-label="Copy code">
                  {copied ? <span className="text-xs text-cyan-300">Copied</span> : <Icon name="copy" className="h-4 w-4" />}
                </button>
              </div>
              <pre className="min-h-[260px] overflow-x-auto p-6 text-[13px] leading-6 text-slate-300 sm:p-8">
                <code>{codeExamples[activeCode]}</code>
              </pre>
              <div className="flex items-center gap-2 border-t border-white/[0.07] px-6 py-3 text-[11px] text-slate-600">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> 200 OK · 38ms
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="mx-auto flex max-w-7xl flex-col gap-5 px-5 py-8 text-xs text-slate-600 sm:flex-row sm:items-center sm:justify-between lg:px-8">
        <div className="flex items-center gap-2 text-slate-400"><LogoMark /> <span className="font-semibold">IP Atlas</span></div>
        <p>© 2025 IP Atlas. Accurate data, thoughtfully delivered.</p>
        <div className="flex gap-5"><a href="#">Privacy</a><a href="#">Status</a><a href="#">Contact</a></div>
      </footer>
    </div>
  );
}
