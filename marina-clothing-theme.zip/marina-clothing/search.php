<?php
/**
 * Search results.
 */

get_header();

global $wp_query;
?>

<main id="primary" class="site-main">
    <?php
    marina_page_header(
        /* translators: %s: search query */
        sprintf( __( 'Results for “%s”', 'marina-clothing' ), esc_html( get_search_query() ) ),
        array(
            'eyebrow'     => __( 'Search', 'marina-clothing' ),
            /* translators: %s: number of results */
            'description' => sprintf( _n( '%s result found', '%s results found', (int) $wp_query->found_posts, 'marina-clothing' ), number_format_i18n( (int) $wp_query->found_posts ) ),
            'breadcrumb'  => false,
        )
    );
    ?>

    <section class="section">
        <div class="container">
            <div class="search-again"><?php get_search_form(); ?></div>

            <?php if ( have_posts() ) : ?>
                <div class="post-grid">
                    <?php
                    while ( have_posts() ) {
                        the_post();
                        get_template_part( 'template-parts/content', 'card' );
                    }
                    ?>
                </div>
                <?php marina_pagination(); ?>
            <?php else : ?>
                <?php get_template_part( 'template-parts/content', 'none' ); ?>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php
get_footer();
