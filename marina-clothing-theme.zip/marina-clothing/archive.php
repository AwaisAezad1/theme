<?php
/**
 * Archives (category, tag, author, date).
 */

get_header();
?>

<main id="primary" class="site-main">
    <?php
    marina_page_header(
        get_the_archive_title(),
        array(
            'eyebrow'     => is_category() ? __( 'Journal Category', 'marina-clothing' ) : ( is_tag() ? __( 'Journal Tag', 'marina-clothing' ) : __( 'The Journal', 'marina-clothing' ) ),
            'description' => get_the_archive_description(),
        )
    );
    ?>

    <section class="section">
        <div class="container">
            <?php if ( have_posts() ) : ?>
                <div class="post-grid">
                    <?php
                    while ( have_posts() ) {
                        the_post();
                        get_template_part( 'template-parts/content', 'card' );
                    }
                    ?>
                </div>
                <?php marina_pagination(); ?>
            <?php else : ?>
                <?php get_template_part( 'template-parts/content', 'none' ); ?>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php
get_footer();
