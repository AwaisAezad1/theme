<?php
/**
 * AJAX handlers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Example AJAX endpoint.
 *
 * Replace this example with project-specific functionality.
 */
function wds_example_ajax() {
    check_ajax_referer( 'wds_nonce', 'nonce' );

    $message = isset( $_POST['message'] )
        ? sanitize_text_field( wp_unslash( $_POST['message'] ) )
        : '';

    wp_send_json_success(
        array(
            'message' => sprintf(
                __( 'Received: %s', 'wp-developer-starter' ),
                $message
            ),
        )
    );
}

add_action( 'wp_ajax_wds_example', 'wds_example_ajax' );
add_action( 'wp_ajax_nopriv_wds_example', 'wds_example_ajax' );
