/**
 * Main theme JavaScript.
 */

(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        // Theme initialization goes here.
    });

    /**
     * Example AJAX helper.
     *
     * Usage:
     *
     * wdsAjax('wds_example', { message: 'Hello' })
     *     .then(function (response) {
     *         console.log(response);
     *     });
     */
    window.wdsAjax = function (action, data) {
        var formData = new FormData();

        formData.append('action', action);
        formData.append('nonce', wdsData.nonce);

        Object.keys(data || {}).forEach(function (key) {
            formData.append(key, data[key]);
        });

        return fetch(wdsData.ajaxUrl, {
            method: 'POST',
            body: formData
        }).then(function (response) {
            return response.json();
        });
    };
})();
