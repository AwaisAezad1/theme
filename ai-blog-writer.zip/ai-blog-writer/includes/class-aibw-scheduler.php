<?php
defined( 'ABSPATH' ) || exit;

/**
 * WordPress cron scheduling. Events are single-use and re-armed after each run.
 * WP-Cron only runs when the site receives traffic unless a server cron calls wp-cron.php.
 */
class AIBW_Scheduler {

	const HOOK = 'aibw_automation_tick';
	const LOCK = 'aibw_automation_lock';

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'ensure' ) );
	}

	public static function ensure() {
		if ( wp_installing() ) {
			return;
		}
		$auto = AIBW_Settings::automation();
		$next = wp_next_scheduled( self::HOOK );
		if ( empty( $auto['enabled'] ) || ! empty( $auto['paused'] ) ) {
			return;
		}
		if ( ! $next ) {
			self::arm( self::next_timestamp() );
		}
	}

	public static function restore() {
		$auto = AIBW_Settings::automation();
		if ( ! empty( $auto['enabled'] ) && empty( $auto['paused'] ) ) {
			self::arm( self::next_timestamp() );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public static function arm( $timestamp ) {
		wp_clear_scheduled_hook( self::HOOK );
		wp_schedule_single_event( $timestamp, self::HOOK );
	}

	public static function tick() {
		AIBW_Automation::step( false );
		$auto = AIBW_Settings::automation();
		if ( empty( $auto['enabled'] ) || ! empty( $auto['paused'] ) ) {
			return;
		}
		$pending = AIBW_Jobs::active();
		$when    = $pending ? time() + 60 : self::next_timestamp();
		self::arm( $when );
	}

	/**
	 * Next run in the site timezone, returned as a UTC unix timestamp.
	 */
	public static function next_timestamp( $after = null ) {
		$auto = AIBW_Settings::automation();
		$tz   = wp_timezone();
		if ( $after instanceof DateTime ) {
			$now = new DateTimeImmutable( $after->format( 'Y-m-d H:i:s' ), $tz );
		} else {
			$now = new DateTimeImmutable( 'now', $tz );
		}
		$now  = $now->setTimezone( $tz );
		$parts = explode( ':', $auto['time'] );
		$hour  = isset( $parts[0] ) ? max( 0, min( 23, (int) $parts[0] ) ) : 9;
		$min   = isset( $parts[1] ) ? max( 0, min( 59, (int) $parts[1] ) ) : 0;

		$candidate = $now->setTime( $hour, $min, 0 );
		if ( $candidate <= $now ) {
			$candidate = $candidate->modify( '+1 day' );
		}

		if ( 'weekly' === $auto['frequency'] ) {
			$wanted = isset( $auto['weekdays'][0] ) ? (int) $auto['weekdays'][0] : 1;
			$guard  = 0;
			while ( (int) $candidate->format( 'w' ) !== $wanted && $guard < 8 ) {
				$candidate = $candidate->modify( '+1 day' );
				++$guard;
			}
		} elseif ( 'days' === $auto['frequency'] ) {
			$days  = array_map( 'intval', (array) $auto['weekdays'] );
			$guard = 0;
			while ( ! in_array( (int) $candidate->format( 'w' ), $days, true ) && $guard < 8 ) {
				$candidate = $candidate->modify( '+1 day' );
				++$guard;
			}
			if ( ! $days ) {
				$candidate = $now->modify( '+1 day' );
			}
		}
		return $candidate->getTimestamp();
	}

	public static function next_local_label() {
		$ts = wp_next_scheduled( self::HOOK );
		if ( ! $ts ) {
			return __( 'Not scheduled', 'ai-blog-writer' );
		}
		return wp_date( 'Y-m-d H:i T', $ts );
	}

	public static function acquire_lock() {
		$lock = get_option( self::LOCK, array() );
		$now  = time();
		if ( is_array( $lock ) && ! empty( $lock['expires'] ) && (int) $lock['expires'] > $now ) {
			return false;
		}
		update_option(
			self::LOCK,
			array(
				'expires' => $now + 15 * MINUTE_IN_SECONDS,
				'token'   => wp_generate_password( 12, false ),
			),
			false
		);
		return true;
	}

	public static function release_lock() {
		delete_option( self::LOCK );
	}
}
