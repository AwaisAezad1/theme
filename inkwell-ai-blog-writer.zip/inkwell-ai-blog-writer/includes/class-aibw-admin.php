<?php
defined( 'ABSPATH' ) || exit;

/**
 * Admin menus, pages, AJAX handlers and form handlers.
 */
class AIBW_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menus' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );

		add_action( 'wp_ajax_aibw_generate', array( __CLASS__, 'ajax_generate' ) );
		add_action( 'wp_ajax_aibw_publish', array( __CLASS__, 'ajax_publish' ) );
		add_action( 'wp_ajax_aibw_test', array( __CLASS__, 'ajax_test' ) );

		add_action( 'admin_post_aibw_save_accounts', array( __CLASS__, 'save_accounts' ) );
		add_action( 'admin_post_aibw_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_aibw_clear_log', array( __CLASS__, 'clear_log' ) );

		add_filter( 'plugin_action_links_' . AIBW_BASENAME, array( __CLASS__, 'action_links' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Menus & assets                                                      */
	/* ------------------------------------------------------------------ */

	public static function menus() {
		add_menu_page( __( 'Inkwell AI Blog Writer', 'inkwell-ai-blog-writer' ), __( 'Inkwell AI Blog Writer', 'inkwell-ai-blog-writer' ), 'edit_posts', 'aibw', array( __CLASS__, 'page_writer' ), 'dashicons-edit-page' );
		add_submenu_page( 'aibw', __( 'Write a Blog', 'inkwell-ai-blog-writer' ), __( 'Write a Blog', 'inkwell-ai-blog-writer' ), 'edit_posts', 'aibw', array( __CLASS__, 'page_writer' ) );
		add_submenu_page( 'aibw', __( 'AI Accounts', 'inkwell-ai-blog-writer' ), __( 'AI Accounts', 'inkwell-ai-blog-writer' ), 'manage_options', 'aibw-accounts', array( __CLASS__, 'page_accounts' ) );
		add_submenu_page( 'aibw', __( 'Settings', 'inkwell-ai-blog-writer' ), __( 'Settings', 'inkwell-ai-blog-writer' ), 'manage_options', 'aibw-settings', array( __CLASS__, 'page_settings' ) );
		add_submenu_page( 'aibw', __( 'History', 'inkwell-ai-blog-writer' ), __( 'History', 'inkwell-ai-blog-writer' ), 'edit_posts', 'aibw-history', array( __CLASS__, 'page_history' ) );
	}

	public static function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=aibw' ) ) . '">' . esc_html__( 'Write a Blog', 'inkwell-ai-blog-writer' ) . '</a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=aibw-accounts' ) ) . '">' . esc_html__( 'AI Accounts', 'inkwell-ai-blog-writer' ) . '</a>'
		);
		return $links;
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'aibw' ) ) {
			return;
		}
		wp_enqueue_style( 'aibw-admin', AIBW_URL . 'assets/admin.css', array(), AIBW_VERSION );
		wp_enqueue_script( 'aibw-admin', AIBW_URL . 'assets/admin.js', array(), AIBW_VERSION, true );
		wp_localize_script(
			'aibw-admin',
			'AIBW',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'aibw_nonce' ),
				'i18n'  => array(
					'needTopic'   => __( 'Please type a topic first.', 'inkwell-ai-blog-writer' ),
					'writing'     => __( 'Writing your blog... this can take up to a minute.', 'inkwell-ai-blog-writer' ),
					'generate'    => __( 'Generate Blog', 'inkwell-ai-blog-writer' ),
					'regenerate'  => __( 'Generate Blog', 'inkwell-ai-blog-writer' ),
					'saving'      => __( 'Saving...', 'inkwell-ai-blog-writer' ),
					'testing'     => __( 'Testing...', 'inkwell-ai-blog-writer' ),
					'badResponse' => __( 'The server did not answer properly. If this keeps happening, your host may be cutting long requests - try a shorter blog length.', 'inkwell-ai-blog-writer' ),
					'needTitle'   => __( 'Please give the blog a title.', 'inkwell-ai-blog-writer' ),
					'needContent' => __( 'The blog is empty.', 'inkwell-ai-blog-writer' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Pages                                                               */
	/* ------------------------------------------------------------------ */

	public static function page_writer() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) );
		}
		$settings    = AIBW_Settings::get();
		$providers   = AIBW_Providers::all();
		$ready       = AIBW_Settings::ready_providers();
		$selected    = AIBW_Settings::preferred_provider();
		$categories  = get_categories( array( 'hide_empty' => false ) );
		$can_publish = current_user_can( 'publish_posts' );
		$static_front = ( 'page' === get_option( 'show_on_front' ) );
		include AIBW_DIR . 'includes/templates/writer-page.php';
	}

	public static function page_accounts() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) );
		}
		$settings  = AIBW_Settings::get();
		$providers = AIBW_Providers::all();
		$msg       = self::flash();
		include AIBW_DIR . 'includes/templates/accounts-page.php';
	}

	public static function page_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) );
		}
		$settings     = AIBW_Settings::get();
		$categories   = get_categories( array( 'hide_empty' => false ) );
		$static_front = ( 'page' === get_option( 'show_on_front' ) );
		$msg          = self::flash();
		include AIBW_DIR . 'includes/templates/settings-page.php';
	}

	public static function page_history() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) );
		}
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'posts_per_page' => 20,
				'meta_key'       => '_aibw_generated', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
		$log = AIBW_Settings::get_log();
		$msg = self::flash();
		include AIBW_DIR . 'includes/templates/history-page.php';
	}

	/** One-time message shown after a form is saved. */
	private static function flash() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$code = isset( $_GET['aibw_msg'] ) ? sanitize_key( wp_unslash( $_GET['aibw_msg'] ) ) : '';
		$all  = array(
			'saved'   => __( 'Saved.', 'inkwell-ai-blog-writer' ),
			'cleared' => __( 'Error log cleared.', 'inkwell-ai-blog-writer' ),
		);
		return isset( $all[ $code ] ) ? $all[ $code ] : '';
	}

	private static function back( $page, $code ) {
		wp_safe_redirect( add_query_arg( array(
			'page' => $page,
			'aibw_msg' => $code,
		), admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Form handlers                                                       */
	/* ------------------------------------------------------------------ */

	private static function clean_model( $value ) {
		return preg_replace( '/[^A-Za-z0-9._:\/-]/', '', (string) $value );
	}

	public static function save_accounts() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_save_accounts' );

		$settings  = AIBW_Settings::get();
		$providers = AIBW_Providers::all();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$keys   = isset( $_POST['key'] ) && is_array( $_POST['key'] ) ? wp_unslash( $_POST['key'] ) : array();
		$models = isset( $_POST['model'] ) && is_array( $_POST['model'] ) ? wp_unslash( $_POST['model'] ) : array();
		$clear  = isset( $_POST['clear'] ) && is_array( $_POST['clear'] ) ? wp_unslash( $_POST['clear'] ) : array();
		// phpcs:enable

		foreach ( array_keys( $providers ) as $id ) {
			if ( ! empty( $clear[ $id ] ) ) {
				unset( $settings['keys'][ $id ] );
			} elseif ( isset( $keys[ $id ] ) && '' !== trim( (string) $keys[ $id ] ) ) {
				$settings['keys'][ $id ] = AIBW_Settings::encrypt( trim( sanitize_text_field( $keys[ $id ] ) ) );
			}
			if ( isset( $models[ $id ] ) ) {
				$model = self::clean_model( $models[ $id ] );
				if ( '' === $model ) {
					unset( $settings['models'][ $id ] );
				} else {
					$settings['models'][ $id ] = $model;
				}
			}
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$default = isset( $_POST['default_provider'] ) ? sanitize_key( wp_unslash( $_POST['default_provider'] ) ) : 'groq';
		$settings['default_provider'] = isset( $providers[ $default ] ) ? $default : 'groq';
		$settings['fallback']         = empty( $_POST['fallback'] ) ? 0 : 1;
		// phpcs:enable

		AIBW_Settings::update( $settings );
		self::back( 'aibw-accounts', 'saved' );
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_save_settings' );

		$settings = AIBW_Settings::get();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$tone   = isset( $_POST['tone'] ) ? sanitize_key( wp_unslash( $_POST['tone'] ) ) : 'informative';
		$length = isset( $_POST['length'] ) ? sanitize_key( wp_unslash( $_POST['length'] ) ) : 'medium';

		$settings['tone']     = array_key_exists( $tone, AIBW_Generator::tones() ) ? $tone : 'informative';
		$settings['length']   = array_key_exists( $length, AIBW_Generator::lengths() ) ? $length : 'medium';
		$settings['language'] = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : 'English';
		$settings['category'] = isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0;
		$settings['sticky']   = empty( $_POST['sticky'] ) ? 0 : 1;
		// phpcs:enable

		AIBW_Settings::update( $settings );
		self::back( 'aibw-settings', 'saved' );
	}

	public static function clear_log() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_clear_log' );
		AIBW_Settings::clear_log();
		self::back( 'aibw-history', 'cleared' );
	}

	/* ------------------------------------------------------------------ */
	/* AJAX                                                                */
	/* ------------------------------------------------------------------ */

	public static function ajax_generate() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 200 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$topic    = isset( $_POST['topic'] ) ? sanitize_textarea_field( wp_unslash( $_POST['topic'] ) ) : '';
		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$tone     = isset( $_POST['tone'] ) ? sanitize_key( wp_unslash( $_POST['tone'] ) ) : 'informative';
		$length   = isset( $_POST['length'] ) ? sanitize_key( wp_unslash( $_POST['length'] ) ) : 'medium';
		$language = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : 'English';
		$notes    = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';
		// phpcs:enable

		$topic = trim( mb_substr( $topic, 0, 500 ) );
		if ( mb_strlen( $topic ) < 3 ) {
			wp_send_json_error( array( 'message' => __( 'Please type a topic first.', 'inkwell-ai-blog-writer' ) ) );
		}
		if ( ! AIBW_Providers::get( $provider ) ) {
			wp_send_json_error( array( 'message' => __( 'Please choose an AI.', 'inkwell-ai-blog-writer' ) ) );
		}

		$result = AIBW_Generator::generate(
			$topic,
			$provider,
			array(
				'tone'     => array_key_exists( $tone, AIBW_Generator::tones() ) ? $tone : 'informative',
				'length'   => array_key_exists( $length, AIBW_Generator::lengths() ) ? $length : 'medium',
				'language' => mb_substr( $language, 0, 40 ),
				'notes'    => mb_substr( $notes, 0, 500 ),
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( $result );
	}

	public static function ajax_publish() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$status   = ( isset( $_POST['status'] ) && 'draft' === $_POST['status'] ) ? 'draft' : 'publish';
		$title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$content  = isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '';
		$topic    = isset( $_POST['topic'] ) ? sanitize_textarea_field( wp_unslash( $_POST['topic'] ) ) : '';
		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$sticky   = ! empty( $_POST['sticky'] );
		$category = isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0;
		// phpcs:enable

		if ( 'publish' === $status && ! current_user_can( 'publish_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You can save drafts, but you are not allowed to publish.', 'inkwell-ai-blog-writer' ) ) );
		}
		if ( '' === $title ) {
			wp_send_json_error( array( 'message' => __( 'Please give the blog a title.', 'inkwell-ai-blog-writer' ) ) );
		}
		if ( '' === trim( wp_strip_all_tags( $content ) ) ) {
			wp_send_json_error( array( 'message' => __( 'The blog is empty.', 'inkwell-ai-blog-writer' ) ) );
		}

		$post_id = AIBW_Generator::publish(
			array(
				'status'   => $status,
				'title'    => $title,
				'content'  => $content,
				'topic'    => $topic,
				'provider' => $provider,
				'sticky'   => $sticky,
				'category' => $category,
			)
		);
		if ( is_wp_error( $post_id ) ) {
			wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
		}

		$on_posts_front = ( 'posts' === get_option( 'show_on_front' ) );
		if ( 'draft' === $status ) {
			$message = __( 'Saved as a draft. You can finish it in the WordPress editor.', 'inkwell-ai-blog-writer' );
		} elseif ( $on_posts_front ) {
			$message = __( 'Done! Your blog is now on your front page.', 'inkwell-ai-blog-writer' );
		} else {
			$message = __( 'Published! Note: your front page is a fixed page, so add the shortcode [aibw_latest_blogs] to it to show your newest AI blogs there.', 'inkwell-ai-blog-writer' );
		}

		wp_send_json_success(
			array(
				'message'  => $message,
				'view_url' => 'publish' === $status ? get_permalink( $post_id ) : get_preview_post_link( $post_id ),
				'edit_url' => get_edit_post_link( $post_id, 'raw' ),
				'home_url' => home_url( '/' ),
				'status'   => $status,
			)
		);
	}

	public static function ajax_test() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'inkwell-ai-blog-writer' ) ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$key      = isset( $_POST['key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['key'] ) ) ) : '';
		$model    = isset( $_POST['model'] ) ? self::clean_model( wp_unslash( $_POST['model'] ) ) : '';
		// phpcs:enable

		if ( ! AIBW_Providers::get( $provider ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown AI.', 'inkwell-ai-blog-writer' ) ) );
		}
		if ( '' === $key ) {
			$key = AIBW_Settings::get_key( $provider ); // Use the saved key when the field is empty.
		}
		if ( '' === $model ) {
			$model = AIBW_Settings::get_model( $provider );
		}

		$start  = microtime( true );
		$result = AIBW_Providers::test( $provider, $key, $model );
		$ms     = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				/* translators: %d: milliseconds */
				'message' => sprintf( __( 'Connected! The AI answered in %d ms.', 'inkwell-ai-blog-writer' ), $ms ),
				'models'  => AIBW_Providers::list_models( $provider, $key ),
			)
		);
	}
}
