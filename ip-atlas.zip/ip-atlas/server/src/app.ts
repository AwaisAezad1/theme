import fs from 'node:fs';
import path from 'node:path';
import Fastify, { LogController, type FastifyInstance } from 'fastify';
import compress from '@fastify/compress';
import helmet from '@fastify/helmet';
import fastifyStatic from '@fastify/static';
import type { Config } from './config.js';
import { buildTrustedProxyCheck } from './lib/ip.js';
import { ProviderRegistry, type Logger } from './providers/registry.js';
import { ApiError, apiRoutes } from './routes/api.js';

declare module 'fastify' {
  interface FastifyInstance {
    registry: ProviderRegistry;
  }
}

export type RegistryFactory = (log: Logger) => ProviderRegistry;

export async function buildApp(
  config: Config,
  createRegistry: RegistryFactory = (log) => ProviderRegistry.fromConfig(config, log),
  options: { logger?: boolean } = {},
): Promise<FastifyInstance> {
  const isTrustedProxy = buildTrustedProxyCheck(config.trustProxy);
  const hasWeb = fs.existsSync(path.join(config.webDist, 'index.html'));

  const app = Fastify({
    logger: options.logger === false ? false : { level: config.logLevel },
    // Per-request access logging is off by default so visitor IP addresses are not written to our logs.
    logController: new LogController({ disableRequestLogging: !config.logRequests }),
    trustProxy: (address: string) => isTrustedProxy(address),
    routerOptions: { ignoreTrailingSlash: true, maxParamLength: 100 },
    bodyLimit: 1024,
  });

  // Handlers must be set before child plugins are registered, otherwise those scopes would not inherit them.
  app.setErrorHandler((err, req, reply) => {
    const e = err as Partial<ApiError> & { statusCode?: number; code?: string; message: string; validation?: unknown };
    let status = typeof e.statusCode === 'number' && e.statusCode >= 400 ? e.statusCode : 500;
    let code = e.code && !e.code.startsWith('FST_') ? e.code : '';
    if (!code) {
      code =
        status === 429 ? 'rate_limited' : status === 404 ? 'not_found' : status < 500 ? 'bad_request' : 'internal_error';
    }
    if (status >= 500) {
      req.log.error({ err }, 'Unhandled error');
      status = 500;
    }
    const message = status >= 500 ? 'Internal server error.' : e.message;
    void reply.code(status).send({ error: { code, message, status } });
  });

  app.setNotFoundHandler((req, reply) => {
    const url = req.raw.url ?? '';
    const isApi = url.startsWith('/api/');
    const wantsHtml = (req.headers.accept ?? '').includes('text/html');
    if (hasWeb && !isApi && (req.method === 'GET' || req.method === 'HEAD') && wantsHtml) {
      return reply.code(200).sendFile('index.html');
    }
    return reply.code(404).send({ error: { code: 'not_found', message: 'Not found.', status: 404 } });
  });

  const registry = createRegistry(app.log);
  app.decorate('registry', registry);
  await registry.init();
  registry.startAutoReload(config.dbReloadIntervalMin);
  app.addHook('onClose', async () => registry.close());

  await app.register(helmet, {
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:'],
        fontSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
      },
    },
    hsts: config.isProduction,
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  });
  await app.register(compress, { global: true, threshold: 1024 });

  app.get('/healthz', async (_req, reply) => reply.header('Cache-Control', 'no-store').send({ status: 'ok' }));

  // API routes live in their own encapsulated scope so CORS and rate limiting never touch the website files.
  await app.register(async (scope) => apiRoutes(scope, { config, registry, isTrustedProxy }));

  if (hasWeb) {
    await app.register(fastifyStatic, {
      root: config.webDist,
      cacheControl: false,
      setHeaders(res, filePath) {
        const immutable = filePath.includes(`${path.sep}assets${path.sep}`);
        res.header('Cache-Control', immutable ? 'public, max-age=31536000, immutable' : 'no-cache');
      },
    });
  } else {
    app.log.warn(`Web build not found at ${config.webDist}. Serving the API only (run "npm run build").`);
  }

  return app;
}
