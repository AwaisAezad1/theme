<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'Generated Drafts', 'ai-blog-writer' ); ?></h1>
	<p class="aibw-lead"><?php esc_html_e( 'Review a draft here, then publish it from the normal WordPress editor when you are satisfied. Automation never publishes.', 'ai-blog-writer' ); ?></p>
	<?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
	<?php if ( $focus && current_user_can( 'edit_post', $focus->ID ) ) : ?>
		<div class="aibw-card">
			<h2><?php echo esc_html( get_the_title( $focus ) ); ?></h2>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( get_edit_post_link( $focus->ID ) ); ?>"><?php esc_html_e( 'Edit article', 'ai-blog-writer' ); ?></a>
				<a class="button" href="<?php echo esc_url( get_preview_post_link( $focus ) ); ?>"><?php esc_html_e( 'Preview', 'ai-blog-writer' ); ?></a>
			</p>
			<?php
			$seo  = get_post_meta( $focus->ID, '_aibw_seo', true );
			$res  = get_post_meta( $focus->ID, '_aibw_research', true );
			$warn = get_post_meta( $focus->ID, '_aibw_warnings', true );
			?>
			<h3><?php esc_html_e( 'SEO fields', 'ai-blog-writer' ); ?></h3>
			<?php if ( is_array( $seo ) ) : ?>
				<ul>
					<li><?php esc_html_e( 'SEO title:', 'ai-blog-writer' ); ?> <?php echo esc_html( $seo['seo_title'] ); ?></li>
					<li><?php esc_html_e( 'Meta description:', 'ai-blog-writer' ); ?> <?php echo esc_html( $seo['meta_description'] ); ?></li>
					<li><?php esc_html_e( 'Focus keyword:', 'ai-blog-writer' ); ?> <?php echo esc_html( $seo['focus_keyword'] ); ?></li>
				</ul>
				<?php if ( ! AIBW_SEO::active_plugin() ) : ?>
					<p class="description"><?php esc_html_e( 'These fields are stored by AI Blog Writer. Install Yoast SEO or Rank Math if you want them output as frontend meta tags.', 'ai-blog-writer' ); ?></p>
				<?php endif; ?>
			<?php else : ?>
				<p><?php esc_html_e( 'No SEO record on this draft.', 'ai-blog-writer' ); ?></p>
			<?php endif; ?>
			<h3><?php esc_html_e( 'Research', 'ai-blog-writer' ); ?></h3>
			<?php if ( is_array( $res ) && ! empty( $res['sources'] ) ) : ?>
				<ul>
					<?php foreach ( $res['sources'] as $source ) : ?>
						<li><a href="<?php echo esc_url( $source['url'] ); ?>"><?php echo esc_html( $source['title'] ); ?></a> <small><?php echo esc_html( isset( $source['verification'] ) ? $source['verification'] : '' ); ?></small></li>
					<?php endforeach; ?>
				</ul>
				<?php if ( ! empty( $res['limitations'] ) ) : ?><p class="description"><?php echo esc_html( $res['limitations'] ); ?></p><?php endif; ?>
			<?php else : ?>
				<p><?php esc_html_e( 'No research sources are stored for this draft.', 'ai-blog-writer' ); ?></p>
			<?php endif; ?>
			<h3><?php esc_html_e( 'Warnings', 'ai-blog-writer' ); ?></h3>
			<?php if ( is_array( $warn ) && $warn ) : ?>
				<ul><?php foreach ( $warn as $line ) : ?><li><?php echo esc_html( $line ); ?></li><?php endforeach; ?></ul>
			<?php else : ?>
				<p><?php esc_html_e( 'No stored quality warnings.', 'ai-blog-writer' ); ?></p>
			<?php endif; ?>
			<p><?php echo has_post_thumbnail( $focus ) ? esc_html__( 'A featured image is assigned.', 'ai-blog-writer' ) : esc_html__( 'No featured image is assigned. Some themes hide the cover even when one is assigned.', 'ai-blog-writer' ); ?></p>
			<?php if ( get_post_meta( $focus->ID, '_aibw_user_edited', true ) ) : ?>
				<p class="aibw-warn"><?php esc_html_e( 'You edited this draft. A later retry will not replace it.', 'ai-blog-writer' ); ?></p>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Draft', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?></th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $posts ) : ?><tr><td colspan="3"><?php esc_html_e( 'No generated drafts yet.', 'ai-blog-writer' ); ?></td></tr><?php endif; ?>
		<?php foreach ( $posts as $post ) : ?>
			<tr>
				<td><?php echo esc_html( get_the_title( $post ) ); ?></td>
				<td><?php echo esc_html( (string) get_post_meta( $post->ID, '_aibw_topic', true ) ); ?></td>
				<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=aibw-drafts&draft=' . (int) $post->ID ) ); ?>"><?php esc_html_e( 'Review', 'ai-blog-writer' ); ?></a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
