<?php
/**
 * Page content.
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <header class="entry-header">
        <h1 class="entry-title"><?php the_title(); ?></h1>
    </header>

    <?php if ( has_post_thumbnail() ) : ?>
        <?php the_post_thumbnail( 'large' ); ?>
    <?php endif; ?>

    <div class="entry-content">
        <?php the_content(); ?>
    </div>

</article>
