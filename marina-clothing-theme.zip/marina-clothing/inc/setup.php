<?php
/**
 * Theme setup and configuration.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function marina_setup() {
    load_theme_textdomain(
        'marina-clothing',
        MARINA_DIR . '/languages'
    );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 80,
            'width'       => 240,
            'flex-height' => true,
            'flex-width'  => true,
        )
    );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'automatic-feed-links' );

    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
            'navigation-widgets',
        )
    );

    add_theme_support(
        'customize-selective-refresh-widgets'
    );

    // Editorial 3:4 portrait crop used by cards across the site.
    add_image_size( 'marina-portrait', 600, 800, true );
    add_image_size( 'marina-landscape', 1200, 800, true );

    register_nav_menus(
        array(
            'primary'          => __( 'Primary Menu', 'marina-clothing' ),
            'footer'           => __( 'Footer: Collections', 'marina-clothing' ),
            'footer-concierge' => __( 'Footer: Concierge', 'marina-clothing' ),
            'footer-legal'     => __( 'Footer: Legal (bottom bar)', 'marina-clothing' ),
        )
    );
}
add_action( 'after_setup_theme', 'marina_setup' );

/**
 * Set content width.
 */
function marina_content_width() {
    $GLOBALS['content_width'] = 1280;
}
add_action( 'after_setup_theme', 'marina_content_width', 0 );

/**
 * Body classes.
 */
function marina_body_classes( $classes ) {
    if ( is_front_page() ) {
        $classes[] = 'is-home';
    }

    if ( is_singular() && ! is_front_page() ) {
        $classes[] = 'is-singular';
    }

    return $classes;
}
add_filter( 'body_class', 'marina_body_classes' );

/**
 * Shorter, cleaner excerpts for editorial cards.
 */
function marina_excerpt_length() {
    return 24;
}
add_filter( 'excerpt_length', 'marina_excerpt_length' );

function marina_excerpt_more() {
    return '&hellip;';
}
add_filter( 'excerpt_more', 'marina_excerpt_more' );

/**
 * Archive titles without the "Category:" prefix.
 */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );
