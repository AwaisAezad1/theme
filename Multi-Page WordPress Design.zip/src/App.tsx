import { useState } from "react";
import HomePage from "./pages/Home";
import AboutPage from "./pages/About";
import ServicesPage from "./pages/Services";
import PortfolioPage from "./pages/Portfolio";
import BlogPage from "./pages/Blog";
import ContactPage from "./pages/Contact";

const PAGES = ["Home", "About", "Services", "Portfolio", "Blog", "Contact"] as const;
type Page = (typeof PAGES)[number];

export default function App() {
  const [activePage, setActivePage] = useState<Page>("Home");
  const [menuOpen, setMenuOpen] = useState(false);

  const renderPage = () => {
    switch (activePage) {
      case "Home": return <HomePage navigate={setActivePage} />;
      case "About": return <AboutPage navigate={setActivePage} />;
      case "Services": return <ServicesPage navigate={setActivePage} />;
      case "Portfolio": return <PortfolioPage navigate={setActivePage} />;
      case "Blog": return <BlogPage navigate={setActivePage} />;
      case "Contact": return <ContactPage />;
    }
  };

  return (
    <div className="min-h-screen" style={{ background: "#080808", color: "#F4EFE6" }}>
      {/* NAV */}
      <nav
        style={{
          position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
          background: "rgba(8,8,8,0.92)", backdropFilter: "blur(12px)",
          borderBottom: "1px solid #1A1A1A",
        }}
      >
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem", display: "flex", alignItems: "center", justifyContent: "space-between", height: 68 }}>
          <button
            onClick={() => setActivePage("Home")}
            style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.25rem", fontWeight: 700, color: "#F4EFE6", background: "none", border: "none", cursor: "pointer", letterSpacing: "-0.01em" }}
          >
            Vantage<span style={{ color: "#FF5500" }}>.</span>
          </button>

          {/* Desktop Nav */}
          <div className="nav-desktop" style={{ display: "flex", gap: "2.5rem", alignItems: "center" }}>
            {PAGES.map((p) => (
              <button
                key={p}
                onClick={() => setActivePage(p)}
                className={`nav-link${activePage === p ? " active" : ""}`}
                style={{ background: "none", border: "none", cursor: "pointer" }}
              >
                {p}
              </button>
            ))}
            <button onClick={() => setActivePage("Contact")} className="btn-primary" style={{ padding: "0.6rem 1.4rem", fontSize: "0.72rem" }}>
              Get Started
            </button>
          </div>

          {/* Mobile Hamburger */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ display: "none", background: "none", border: "none", cursor: "pointer", color: "#F4EFE6", fontSize: "1.5rem" }}
            className="mobile-menu-btn"
          >
            {menuOpen ? "✕" : "☰"}
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div style={{ background: "#0F0F0F", borderTop: "1px solid #222", padding: "1.5rem 2rem", display: "flex", flexDirection: "column", gap: "1.2rem" }}>
            {PAGES.map((p) => (
              <button
                key={p}
                onClick={() => { setActivePage(p); setMenuOpen(false); }}
                className="nav-link"
                style={{ background: "none", border: "none", cursor: "pointer", textAlign: "left", fontSize: "0.9rem" }}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </nav>

      {/* Page Content */}
      <div style={{ paddingTop: 68 }}>
        {renderPage()}
      </div>

      {/* FOOTER */}
      <footer style={{ background: "#060606", borderTop: "1px solid #1A1A1A", padding: "4rem 2rem 2.5rem" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: "3rem", marginBottom: "3rem" }}>
            <div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.4rem", fontWeight: 700, marginBottom: "1rem" }}>
                Vantage<span style={{ color: "#FF5500" }}>.</span>
              </div>
              <p style={{ color: "#666", fontSize: "0.88rem", lineHeight: 1.8, maxWidth: 280 }}>
                We build high-performance WordPress sites that convert visitors into customers. Strategy, design, and code — all under one roof.
              </p>
              <div style={{ display: "flex", gap: "1rem", marginTop: "1.5rem" }}>
                {["LinkedIn", "Twitter", "Instagram"].map((s) => (
                  <span key={s} style={{ fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.1em", color: "#444", textTransform: "uppercase", cursor: "pointer", transition: "color 0.2s" }}
                    onMouseEnter={e => (e.currentTarget.style.color = "#FF5500")}
                    onMouseLeave={e => (e.currentTarget.style.color = "#444")}
                  >{s}</span>
                ))}
              </div>
            </div>
            {[
              { title: "Pages", links: ["Home", "About", "Services", "Portfolio"] },
              { title: "Services", links: ["Web Design", "WordPress Dev", "SEO", "Branding"] },
              { title: "Company", links: ["Case Studies", "Blog", "Contact", "Careers"] },
            ].map((col) => (
              <div key={col.title}>
                <div className="section-label" style={{ marginBottom: "1.2rem" }}>{col.title}</div>
                {col.links.map((l) => (
                  <div key={l} style={{ marginBottom: "0.7rem" }}>
                    <span style={{ fontSize: "0.88rem", color: "#666", cursor: "pointer", transition: "color 0.2s" }}
                      onMouseEnter={e => (e.currentTarget.style.color = "#F4EFE6")}
                      onMouseLeave={e => (e.currentTarget.style.color = "#666")}
                    >{l}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="divider" style={{ paddingTop: "2rem", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <p style={{ fontSize: "0.75rem", color: "#444" }}>© 2026 Vantage Studio. All rights reserved.</p>
            <p style={{ fontSize: "0.75rem", color: "#444" }}>Privacy Policy · Terms of Service</p>
          </div>
        </div>
      </footer>

      <style>{`
        @media (max-width: 900px) {
          .nav-desktop { display: none !important; }
          .mobile-menu-btn { display: block !important; }
        }
      `}</style>
    </div>
  );
}
