<?php get_header(); ?>

<main id="primary" class="site-content">
    <div class="container">

        <?php if ( have_posts() ) : ?>

            <?php while ( have_posts() ) : the_post(); ?>

                <?php get_template_part( 'template-parts/content', get_post_type() ); ?>

            <?php endwhile; ?>

            <?php the_posts_pagination(); ?>

        <?php else : ?>

            <p><?php esc_html_e( 'No content found.', 'wp-developer-starter' ); ?></p>

        <?php endif; ?>

    </div>
</main>

<?php get_footer(); ?>
