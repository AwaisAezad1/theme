<?php
/**
 * Single product overlays: full-screen viewer, size guide, sticky mobile bar.
 *
 * @var WC_Product $product
 */

defined( 'ABSPATH' ) || exit;
?>
<dialog class="zoom-dialog" data-zoom-dialog aria-label="<?php esc_attr_e( 'Image viewer', 'marina-clothing' ); ?>">
    <button type="button" class="zoom-dialog__close" data-dialog-close aria-label="<?php esc_attr_e( 'Close', 'marina-clothing' ); ?>"><?php marina_the_icon( 'close' ); ?></button>
    <button type="button" class="zoom-dialog__nav zoom-dialog__nav--prev" data-zoom-step="-1" aria-label="<?php esc_attr_e( 'Previous image', 'marina-clothing' ); ?>"><?php marina_the_icon( 'chevron_left' ); ?></button>
    <figure class="zoom-dialog__figure">
        <img src="" alt="" data-zoom-img>
        <figcaption data-zoom-caption></figcaption>
    </figure>
    <button type="button" class="zoom-dialog__nav zoom-dialog__nav--next" data-zoom-step="1" aria-label="<?php esc_attr_e( 'Next image', 'marina-clothing' ); ?>"><?php marina_the_icon( 'chevron_right' ); ?></button>
</dialog>

<?php if ( marina_product_has_size( $product ) ) : ?>
    <dialog class="modal" data-size-guide aria-labelledby="size-guide-title">
        <div class="modal__head">
            <div>
                <span class="eyebrow"><?php esc_html_e( 'Fit Guide', 'marina-clothing' ); ?></span>
                <h3 class="modal__title" id="size-guide-title"><?php esc_html_e( 'Size & Body Proportions', 'marina-clothing' ); ?></h3>
            </div>
            <button type="button" class="icon-btn" data-dialog-close aria-label="<?php esc_attr_e( 'Close', 'marina-clothing' ); ?>"><?php marina_the_icon( 'close' ); ?></button>
        </div>
        <p class="modal__text"><?php esc_html_e( 'Our pieces follow standard sizing with a relaxed fit. If you fall between sizes, we suggest taking your usual size.', 'marina-clothing' ); ?></p>
        <?php
        $marina_rows = apply_filters(
            'marina_size_guide_rows',
            array(
                array( 'XS', '0–2 / 6', '31–33', '24–26', '34–36' ),
                array( 'S', '4–6 / 8–10', '34–36', '27–29', '37–39' ),
                array( 'M', '8–10 / 12', '37–39', '30–32', '40–42' ),
                array( 'L', '12–14 / 14–16', '40–42', '33–35', '43–45' ),
                array( 'XL', '16 / 18', '43–45', '36–38', '46–48' ),
            ),
            $product
        );
        ?>
        <div class="table-scroll">
            <table class="size-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Size', 'marina-clothing' ); ?></th>
                        <th><?php esc_html_e( 'US / UK', 'marina-clothing' ); ?></th>
                        <th><?php esc_html_e( 'Bust (in)', 'marina-clothing' ); ?></th>
                        <th><?php esc_html_e( 'Waist (in)', 'marina-clothing' ); ?></th>
                        <th><?php esc_html_e( 'Hip (in)', 'marina-clothing' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $marina_rows as $marina_row ) : ?>
                        <tr>
                            <?php foreach ( $marina_row as $marina_ci => $marina_cell ) : ?>
                                <td><?php echo 0 === $marina_ci ? '<strong>' . esc_html( $marina_cell ) . '</strong>' : esc_html( $marina_cell ); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </dialog>
<?php endif; ?>

<?php if ( $product->is_purchasable() && $product->is_in_stock() ) : ?>
    <div class="buy-bar" data-buy-bar aria-hidden="true">
        <div class="buy-bar__info">
            <span class="buy-bar__name"><?php echo esc_html( $product->get_name() ); ?></span>
            <span class="buy-bar__price price"><?php echo $product->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
        </div>
        <button type="button" class="btn btn--primary" data-buy-bar-go tabindex="-1">
            <?php marina_the_icon( 'shopping_bag' ); ?>
            <span><?php esc_html_e( 'Add to Bag', 'marina-clothing' ); ?></span>
        </button>
    </div>
<?php endif; ?>
