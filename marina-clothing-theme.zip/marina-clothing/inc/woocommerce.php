<?php
/**
 * WooCommerce compatibility & Marina templates.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Declare WooCommerce theme support.
 *
 * The product gallery (zoom, lightbox, thumbnails) is provided by the theme,
 * so WooCommerce's gallery features are intentionally not declared.
 */
function marina_woocommerce_setup() {
    add_theme_support(
        'woocommerce',
        array(
            'thumbnail_image_width' => 600,
            'single_image_width'    => 1000,
            'product_grid'          => array(
                'default_rows'    => 3,
                'min_rows'        => 1,
                'max_rows'        => 8,
                'default_columns' => 4,
                'min_columns'     => 1,
                'max_columns'     => 6,
            ),
        )
    );
}
add_action( 'after_setup_theme', 'marina_woocommerce_setup' );

/* --------------------------------------------------------------------------
 * Global wrappers
 * ----------------------------------------------------------------------- */

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

function marina_wc_wrapper_start() {
    echo '<main id="primary" class="site-main wc-main">';
}
add_action( 'woocommerce_before_main_content', 'marina_wc_wrapper_start', 10 );

function marina_wc_wrapper_end() {
    echo '</main>';
}
add_action( 'woocommerce_after_main_content', 'marina_wc_wrapper_end', 10 );

/**
 * Breadcrumb markup.
 */
function marina_breadcrumb_defaults( $defaults ) {
    $defaults['delimiter']   = '<span class="sep" aria-hidden="true">/</span>';
    $defaults['wrap_before'] = '<nav class="woocommerce-breadcrumb" aria-label="' . esc_attr__( 'Breadcrumb', 'marina-clothing' ) . '">';
    $defaults['wrap_after']  = '</nav>';
    return $defaults;
}
add_filter( 'woocommerce_breadcrumb_defaults', 'marina_breadcrumb_defaults' );

/* --------------------------------------------------------------------------
 * Header cart count + fragments
 * ----------------------------------------------------------------------- */

function marina_cart_count_badge() {
    $count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;

    printf(
        '<span class="count-badge" data-cart-count%1$s>%2$s</span>',
        $count ? '' : ' hidden',
        esc_html( $count )
    );
}

function marina_cart_fragments( $fragments ) {
    ob_start();
    marina_cart_count_badge();
    $fragments['span[data-cart-count]'] = ob_get_clean();

    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'marina_cart_fragments' );

/* --------------------------------------------------------------------------
 * Shop loop
 * ----------------------------------------------------------------------- */

add_filter(
    'loop_shop_per_page',
    function () {
        return 12;
    }
);

add_filter(
    'loop_shop_columns',
    function () {
        return 4;
    }
);

/**
 * Toolbar wrapper around result count + ordering.
 */
function marina_shop_toolbar_open() {
    echo '<div class="shop-toolbar">';
}
add_action( 'woocommerce_before_shop_loop', 'marina_shop_toolbar_open', 15 );

function marina_shop_toolbar_close() {
    echo '</div>';
}
add_action( 'woocommerce_before_shop_loop', 'marina_shop_toolbar_close', 35 );

/**
 * Pagination arrows.
 */
function marina_wc_pagination_args( $args ) {
    $args['prev_text'] = marina_icon( 'chevron_left' );
    $args['next_text'] = marina_icon( 'chevron_right' );
    $args['mid_size']  = 1;
    return $args;
}
add_filter( 'woocommerce_pagination_args', 'marina_wc_pagination_args' );

/**
 * Sale flash text.
 */
function marina_sale_flash( $html, $post, $product ) {
    return '<span class="onsale badge badge--dark">' . esc_html( marina_sale_label( $product ) ) . '</span>';
}
add_filter( 'woocommerce_sale_flash', 'marina_sale_flash', 10, 3 );

function marina_sale_label( $product ) {
    $pct = 0;

    if ( $product->is_type( 'simple' ) || $product->is_type( 'external' ) ) {
        $regular = (float) $product->get_regular_price();
        $sale    = (float) $product->get_sale_price();
        if ( $regular > 0 && $sale > 0 ) {
            $pct = round( ( ( $regular - $sale ) / $regular ) * 100 );
        }
    }

    /* translators: %d: discount percentage */
    return $pct ? sprintf( __( 'Save %d%%', 'marina-clothing' ), $pct ) : __( 'Sale', 'marina-clothing' );
}

/**
 * Single add to cart label.
 */
add_filter(
    'woocommerce_product_single_add_to_cart_text',
    function () {
        return __( 'Add to Bag', 'marina-clothing' );
    }
);

/* --------------------------------------------------------------------------
 * Product helpers (cards, badges, swatches, wishlist)
 * ----------------------------------------------------------------------- */

/**
 * The single most relevant badge for a product card.
 */
function marina_product_badge( $product ) {
    if ( ! $product->is_in_stock() ) {
        return array( __( 'Sold Out', 'marina-clothing' ), 'badge--muted' );
    }

    if ( $product->is_on_sale() ) {
        return array( marina_sale_label( $product ), 'badge--sale' );
    }

    if ( $product->is_featured() ) {
        return array( __( 'Editor\'s Pick', 'marina-clothing' ), '' );
    }

    $created = $product->get_date_created();
    if ( $created && $created->getTimestamp() > strtotime( '-45 days' ) ) {
        return array( __( 'New Arrival', 'marina-clothing' ), '' );
    }

    return array();
}

/**
 * Secondary line under the product title: colour attribute or category.
 */
function marina_product_subtitle( $product ) {
    $colors = marina_product_colors( $product );
    if ( $colors ) {
        return $colors[0]['name'];
    }

    $terms = get_the_terms( $product->get_id(), 'product_cat' );
    if ( $terms && ! is_wp_error( $terms ) ) {
        foreach ( $terms as $term ) {
            if ( (int) get_option( 'default_product_cat' ) !== $term->term_id ) {
                return $term->name;
            }
        }
    }

    return '';
}

/**
 * Colour options of a product (from any attribute named colour/color).
 */
function marina_product_colors( $product ) {
    $out = array();

    foreach ( $product->get_attributes() as $attribute ) {
        if ( ! preg_match( '/colou?r/i', $attribute->get_name() ) ) {
            continue;
        }

        if ( $attribute->is_taxonomy() ) {
            $terms = wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'all' ) );
            foreach ( $terms as $term ) {
                $out[] = array(
                    'name' => $term->name,
                    'hex'  => marina_color_from_name( $term->slug . ' ' . $term->name ),
                );
            }
        } else {
            foreach ( $attribute->get_options() as $option ) {
                $out[] = array(
                    'name' => $option,
                    'hex'  => marina_color_from_name( $option ),
                );
            }
        }
    }

    return $out;
}

/**
 * Category slugs for client-side filtering.
 */
function marina_product_cat_slugs( $product ) {
    $terms = get_the_terms( $product->get_id(), 'product_cat' );
    return ( $terms && ! is_wp_error( $terms ) ) ? implode( ' ', wp_list_pluck( $terms, 'slug' ) ) : '';
}

/**
 * Plain-text price for data attributes.
 */
function marina_plain_price( $product ) {
    $price = $product->get_price();

    if ( '' === $price ) {
        return '';
    }

    $text = html_entity_decode( wp_strip_all_tags( wc_price( wc_get_price_to_display( $product ) ) ), ENT_QUOTES, 'UTF-8' );

    if ( $product->is_type( 'variable' ) && $product->get_variation_price( 'min' ) !== $product->get_variation_price( 'max' ) ) {
        /* translators: %s: price */
        $text = sprintf( __( 'From %s', 'marina-clothing' ), $text );
    }

    return $text;
}

/**
 * Wishlist toggle button (client-side wishlist stored in localStorage).
 */
function marina_wishlist_button( $product, $class = '' ) {
    $data = array(
        'id'    => $product->get_id(),
        'name'  => $product->get_name(),
        'url'   => $product->get_permalink(),
        'img'   => wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' ) ?: wc_placeholder_img_src(),
        'price' => marina_plain_price( $product ),
    );

    printf(
        '<button type="button" class="wishlist-btn %1$s" data-wishlist="%2$s" aria-pressed="false" aria-label="%3$s">%4$s</button>',
        esc_attr( $class ),
        esc_attr( wp_json_encode( $data ) ),
        /* translators: %s: product name */
        esc_attr( sprintf( __( 'Save %s to wishlist', 'marina-clothing' ), $product->get_name() ) ),
        marina_icon( 'favorite' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    );
}

/**
 * Add-to-cart link that WooCommerce's AJAX handler understands.
 */
function marina_add_to_cart_button( $product, $class = '', $show_price = false ) {
    $ajax = $product->is_purchasable() && $product->is_in_stock() && $product->supports( 'ajax_add_to_cart' );

    $classes = array_filter(
        array(
            'button',
            $class,
            'product_type_' . $product->get_type(),
            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
            $ajax ? 'ajax_add_to_cart' : '',
        )
    );

    if ( $ajax ) {
        $label = __( 'Quick Add', 'marina-clothing' );
        if ( $show_price && $product->get_price() !== '' ) {
            $label .= ' • ' . html_entity_decode( wp_strip_all_tags( wc_price( wc_get_price_to_display( $product ), array( 'decimals' => 0 ) ) ), ENT_QUOTES, 'UTF-8' );
        }
        $icon = 'add_shopping_cart';
    } else {
        $label = $product->add_to_cart_text();
        $icon  = 'arrow_forward';
    }

    printf(
        '<a href="%1$s" data-quantity="1" data-product_id="%2$s" data-product_sku="%3$s" class="%4$s" aria-label="%5$s" rel="nofollow">%6$s<span>%7$s</span></a>',
        esc_url( $product->add_to_cart_url() ),
        esc_attr( $product->get_id() ),
        esc_attr( $product->get_sku() ),
        esc_attr( implode( ' ', $classes ) ),
        esc_attr( wp_strip_all_tags( $product->add_to_cart_description() ) ),
        marina_icon( $icon ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        esc_html( $label )
    );
}

/**
 * Inline rating "★ 4.9 (68)".
 */
function marina_rating_inline( $product ) {
    $count = $product->get_review_count();

    if ( ! $count || ! wc_review_ratings_enabled() ) {
        return;
    }

    printf(
        '<div class="rating-inline">%1$s<strong>%2$s</strong><span>(%3$s)</span><span class="screen-reader-text">%4$s</span></div>',
        marina_icon( 'star', 'icon--fill' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        esc_html( number_format_i18n( (float) $product->get_average_rating(), 1 ) ),
        esc_html( $count ),
        esc_html__( 'average rating and number of reviews', 'marina-clothing' )
    );
}

/**
 * Five-star display.
 */
function marina_stars( $rating ) {
    echo '<span class="stars" aria-hidden="true">';
    for ( $i = 1; $i <= 5; $i++ ) {
        echo marina_icon( 'star', $rating >= $i - 0.25 ? 'icon--fill' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    echo '</span>';
}

/**
 * Image for a product category: its own thumbnail, else a product photo
 * from inside it, else one of the bundled editorial images.
 */
function marina_category_image_url( $term, $fallback = '' ) {
    $thumb_id = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );

    if ( $thumb_id ) {
        return wp_get_attachment_image_url( $thumb_id, 'woocommerce_thumbnail' );
    }

    $ids = wc_get_products(
        array(
            'category' => array( $term->slug ),
            'limit'    => 1,
            'return'   => 'ids',
            'status'   => 'publish',
            'include'  => marina_photo_product_ids() ? marina_photo_product_ids() : array( 0 ),
        )
    );

    if ( $ids ) {
        $url = get_the_post_thumbnail_url( $ids[0], 'woocommerce_thumbnail' );
        if ( $url ) {
            return $url;
        }
    }

    return $fallback;
}

/**
 * Products for home sections.
 */
function marina_query_products( $args ) {
    $defaults = array(
        'status'     => 'publish',
        'limit'      => 8,
        'visibility' => 'catalog',
    );

    return wc_get_products( wp_parse_args( $args, $defaults ) );
}

/**
 * Does the product's main image actually exist on disk?
 * (Imported demo data often references missing files.)
 */
function marina_product_has_photo( $product ) {
    $id = $product->get_image_id();
    if ( ! $id ) {
        return false;
    }
    $file = get_attached_file( $id );
    return $file && file_exists( $file );
}

/**
 * IDs of products whose featured image is an existing attachment.
 * Cached for an hour; cleared whenever a product is saved.
 */
function marina_photo_product_ids() {
    $ids = get_transient( 'marina_photo_product_ids' );

    if ( false === $ids ) {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $ids = array_map(
            'intval',
            $wpdb->get_col(
                "SELECT pm.post_id FROM {$wpdb->postmeta} pm
                INNER JOIN {$wpdb->posts} a ON a.ID = pm.meta_value AND a.post_type = 'attachment'
                INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id AND p.post_type = 'product' AND p.post_status = 'publish'
                WHERE pm.meta_key = '_thumbnail_id'"
            )
        );
        set_transient( 'marina_photo_product_ids', $ids, HOUR_IN_SECONDS );
    }

    return $ids;
}

function marina_flush_photo_product_ids() {
    delete_transient( 'marina_photo_product_ids' );
}
add_action( 'woocommerce_update_product', 'marina_flush_photo_product_ids' );
add_action( 'woocommerce_new_product', 'marina_flush_photo_product_ids' );
add_action( 'before_delete_post', 'marina_flush_photo_product_ids' );

/**
 * Query products that have a real photo, topping up until $limit is reached.
 */
function marina_products_with_photos( $args, $limit ) {
    $ids = marina_photo_product_ids();
    if ( ! $ids ) {
        return array();
    }

    $args['limit']   = $limit * 2;
    $args['include'] = $ids;

    $products = array_filter( marina_query_products( $args ), 'marina_product_has_photo' );

    return array_slice( array_values( $products ), 0, $limit );
}

/**
 * Showcase products: featured first, then best sellers.
 */
function marina_showcase_products( $limit = 8, $exclude = array() ) {
    $products = marina_products_with_photos(
        array(
            'featured' => true,
            'exclude'  => $exclude,
        ),
        $limit
    );

    if ( count( $products ) < $limit ) {
        $ids  = array_map(
            function ( $p ) {
                return $p->get_id();
            },
            $products
        );
        $more = marina_products_with_photos(
            array(
                'exclude' => array_merge( $exclude, $ids ),
                'orderby' => 'popularity',
            ),
            $limit - count( $products )
        );
        $products = array_merge( $products, $more );
    }

    return $products;
}

/**
 * Render products through the shared card template.
 */
function marina_render_product_cards( $products, $class = '' ) {
    if ( ! $products ) {
        return;
    }

    echo '<ul class="products product-grid ' . esc_attr( $class ) . '">';

    foreach ( $products as $product ) {
        $post_object = get_post( $product->get_id() );
        setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found
        $GLOBALS['product'] = $product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
        wc_get_template_part( 'content', 'product' );
    }

    echo '</ul>';
    wp_reset_postdata();
}

/* --------------------------------------------------------------------------
 * Single product
 * ----------------------------------------------------------------------- */

// Gallery: replace WooCommerce's with the theme's editorial gallery.
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );

// Summary order.
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
add_action( 'woocommerce_single_product_summary', 'marina_single_heading', 5 );
add_action( 'woocommerce_single_product_summary', 'marina_single_trust', 35 );
add_action( 'woocommerce_single_product_summary', 'marina_single_accordions', 45 );

// Below the fold.
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
add_action( 'woocommerce_after_single_product_summary', 'marina_complete_the_look', 15 );
add_action( 'woocommerce_after_single_product_summary', 'marina_single_reviews', 20 );

// Wishlist next to the add to bag button.
add_action(
    'woocommerce_after_add_to_cart_button',
    function () {
        global $product;
        if ( $product ) {
            marina_wishlist_button( $product, 'wishlist-btn--square' );
        }
    }
);

// Headings inside accordions are redundant.
add_filter( 'woocommerce_product_description_heading', '__return_empty_string' );
add_filter( 'woocommerce_product_additional_information_heading', '__return_empty_string' );

/**
 * Gallery images for the current product (with captions).
 */
function marina_product_gallery_items( $product ) {
    $ids = array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) );
    $out = array();

    foreach ( array_unique( $ids ) as $id ) {
        $caption = wp_get_attachment_caption( $id );
        if ( ! $caption ) {
            $caption = get_post_meta( $id, '_wp_attachment_image_alt', true );
        }

        $out[] = array(
            'src'     => wp_get_attachment_image_url( $id, 'woocommerce_single' ),
            'full'    => wp_get_attachment_image_url( $id, 'full' ),
            'thumb'   => wp_get_attachment_image_url( $id, 'woocommerce_thumbnail' ),
            'alt'     => get_post_meta( $id, '_wp_attachment_image_alt', true ) ?: $product->get_name(),
            'caption' => $caption,
            'srcset'  => wp_get_attachment_image_srcset( $id, 'woocommerce_single' ),
        );
    }

    if ( ! $out ) {
        $out[] = array(
            'src'     => wc_placeholder_img_src( 'woocommerce_single' ),
            'full'    => wc_placeholder_img_src( 'full' ),
            'thumb'   => wc_placeholder_img_src(),
            'alt'     => $product->get_name(),
            'caption' => '',
            'srcset'  => '',
        );
    }

    return $out;
}

/**
 * Editorial gallery (left column).
 */
function marina_single_gallery() {
    global $product;
    wc_get_template( 'single-product/marina-gallery.php', array( 'product' => $product, 'items' => marina_product_gallery_items( $product ) ) );
}
add_action( 'woocommerce_before_single_product_summary', 'marina_single_gallery', 20 );

/**
 * Eyebrow, rating, title, price.
 */
function marina_single_heading() {
    global $product;

    $cats  = get_the_terms( $product->get_id(), 'product_cat' );
    $names = array();
    if ( $cats && ! is_wp_error( $cats ) ) {
        foreach ( $cats as $cat ) {
            if ( (int) get_option( 'default_product_cat' ) !== $cat->term_id ) {
                $names[] = $cat->name;
            }
        }
    }
    $count = $product->get_review_count();
    ?>
    <div class="psummary__head">
        <div class="psummary__meta">
            <span class="eyebrow"><?php echo esc_html( $names ? implode( ' • ', array_slice( $names, 0, 2 ) ) : get_bloginfo( 'name' ) ); ?></span>
            <?php if ( $count && wc_review_ratings_enabled() ) : ?>
                <a class="psummary__rating" href="#reviews">
                    <?php marina_stars( (float) $product->get_average_rating() ); ?>
                    <strong><?php echo esc_html( number_format_i18n( (float) $product->get_average_rating(), 1 ) ); ?></strong>
                    <?php /* translators: %s: review count */ ?>
                    <span><?php echo esc_html( sprintf( _n( '(%s review)', '(%s reviews)', $count, 'marina-clothing' ), number_format_i18n( $count ) ) ); ?></span>
                </a>
            <?php endif; ?>
        </div>

        <?php the_title( '<h1 class="product_title entry-title psummary__title">', '</h1>' ); ?>

        <div class="psummary__price-row">
            <p class="price psummary__price"><?php echo $product->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
            <?php if ( $product->is_on_sale() ) : ?>
                <span class="badge badge--pill badge--sand"><?php echo esc_html( marina_sale_label( $product ) ); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <hr class="psummary__rule">
    <?php
}

/**
 * Trust badges.
 */
function marina_single_trust() {
    $items = apply_filters(
        'marina_product_trust_items',
        array(
            array( 'local_shipping', __( 'Fast Delivery', 'marina-clothing' ), __( 'Tracked to your door', 'marina-clothing' ) ),
            array( 'published_with_changes', __( '30-Day Returns', 'marina-clothing' ), __( 'Prepaid home pickup', 'marina-clothing' ) ),
            array( 'lock', __( 'Secure Checkout', 'marina-clothing' ), __( 'Safe, encrypted payment', 'marina-clothing' ) ),
        )
    );
    ?>
    <ul class="trust-row">
        <?php foreach ( $items as $item ) : ?>
            <li>
                <?php marina_the_icon( $item[0] ); ?>
                <strong><?php echo esc_html( $item[1] ); ?></strong>
                <span><?php echo esc_html( $item[2] ); ?></span>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php
}

/**
 * Product tabs rendered as accordions.
 */
function marina_single_accordions() {
    global $product;

    $tabs = apply_filters( 'woocommerce_product_tabs', array() );
    unset( $tabs['reviews'] );

    $shipping = marina_opt_lines( 'shipping_text' );
    if ( $shipping ) {
        $tabs['marina_shipping'] = array(
            'title'    => __( 'Delivery & Returns', 'marina-clothing' ),
            'priority' => 90,
            'callback' => function () use ( $shipping ) {
                foreach ( $shipping as $line ) {
                    echo '<p>' . esc_html( $line ) . '</p>';
                }
            },
        );
    }

    $sku = $product->get_sku();
    if ( $sku || $product->get_tag_ids() ) {
        $tabs['marina_details'] = array(
            'title'    => __( 'Reference & Tags', 'marina-clothing' ),
            'priority' => 95,
            'callback' => 'woocommerce_template_single_meta',
        );
    }

    if ( ! $tabs ) {
        return;
    }

    echo '<div class="accordions">';
    $first = true;
    foreach ( $tabs as $key => $tab ) {
        if ( empty( $tab['callback'] ) ) {
            continue;
        }
        printf(
            '<details class="accordion" id="tab-%1$s"%2$s><summary class="accordion__head"><span>%3$s</span>%4$s</summary><div class="accordion__body">',
            esc_attr( $key ),
            $first ? ' open' : '',
            wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $tab['title'], $key ) ),
            marina_icon( 'keyboard_arrow_down', 'accordion__icon' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        );
        call_user_func( $tab['callback'], $key, $tab );
        echo '</div></details>';
        $first = false;
    }
    echo '</div>';
}

/**
 * Does the product have a size attribute? (shows the size guide)
 */
function marina_product_has_size( $product ) {
    foreach ( $product->get_attributes() as $attribute ) {
        if ( preg_match( '/size/i', $attribute->get_name() ) ) {
            return true;
        }
    }
    return false;
}

/**
 * "Complete the look": upsells, else cross-sells, else related products.
 */
function marina_complete_the_look() {
    global $product;

    $ids = $product->get_upsell_ids();
    if ( ! $ids ) {
        $ids = $product->get_cross_sell_ids();
    }
    if ( ! $ids ) {
        $ids = wc_get_related_products( $product->get_id(), 3 );
    }

    $items = array_filter( array_map( 'wc_get_product', array_slice( $ids, 0, 3 ) ) );
    $items = array_filter(
        $items,
        function ( $p ) {
            return $p && $p->is_visible();
        }
    );

    if ( ! $items ) {
        return;
    }
    ?>
    <section class="section section--low complete-look">
        <div class="container">
            <div class="section-head">
                <div>
                    <span class="eyebrow"><?php esc_html_e( 'Styled Together', 'marina-clothing' ); ?></span>
                    <h2 class="section-head__title section-head__title--display"><?php esc_html_e( 'Complete The Look', 'marina-clothing' ); ?></h2>
                </div>
                <p class="section-head__aside">
                    <?php
                    /* translators: %s: product name */
                    echo esc_html( sprintf( __( 'Curated by our head stylist to complement %s with natural, tactile pieces.', 'marina-clothing' ), $product->get_name() ) );
                    ?>
                </p>
            </div>
            <div class="pairing-grid">
                <?php foreach ( $items as $item ) : ?>
                    <?php get_template_part( 'template-parts/product/card-pairing', null, array( 'product' => $item ) ); ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
}

/**
 * Reviews ledger.
 */
function marina_single_reviews() {
    global $product;

    if ( ! comments_open() && ! $product->get_review_count() ) {
        return;
    }

    echo '<section class="section reviews-section"><div class="container">';
    comments_template();
    echo '</div></section>';
}

/**
 * Size guide + zoom dialogs, sticky mobile buy bar.
 */
function marina_single_footer_ui() {
    global $product;
    if ( ! $product ) {
        return;
    }
    wc_get_template( 'single-product/marina-dialogs.php', array( 'product' => $product ) );
}
add_action( 'woocommerce_after_single_product', 'marina_single_footer_ui' );

/* --------------------------------------------------------------------------
 * Misc
 * ----------------------------------------------------------------------- */

/**
 * Related product args (used if anything else calls them).
 */
add_filter(
    'woocommerce_output_related_products_args',
    function ( $args ) {
        $args['posts_per_page'] = 4;
        $args['columns']        = 4;
        return $args;
    }
);

/**
 * Review avatars a touch larger.
 */
add_filter(
    'woocommerce_review_gravatar_size',
    function () {
        return 48;
    }
);
