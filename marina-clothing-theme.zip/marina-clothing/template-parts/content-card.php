<?php
/**
 * Editorial card for posts (and any post type in search results).
 */

$marina_is_product = 'product' === get_post_type() && function_exists( 'wc_get_product' );
$marina_product    = $marina_is_product ? wc_get_product( get_the_ID() ) : null;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
    <a class="post-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
        <?php if ( has_post_thumbnail() ) : ?>
            <?php the_post_thumbnail( 'marina-landscape', array( 'loading' => 'lazy', 'alt' => '' ) ); ?>
        <?php else : ?>
            <span class="post-card__placeholder"><?php marina_the_icon( $marina_is_product ? 'checkroom' : 'history_edu' ); ?></span>
        <?php endif; ?>
        <?php if ( 'post' !== get_post_type() ) : ?>
            <span class="badge post-card__type"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?></span>
        <?php endif; ?>
    </a>

    <div class="post-card__body">
        <?php if ( 'post' === get_post_type() ) : ?>
            <?php marina_post_meta(); ?>
        <?php endif; ?>

        <h2 class="post-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

        <?php if ( $marina_product ) : ?>
            <p class="price"><?php echo $marina_product->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
        <?php else : ?>
            <div class="post-card__excerpt"><?php the_excerpt(); ?></div>
        <?php endif; ?>

        <a class="text-link" href="<?php the_permalink(); ?>">
            <span><?php echo $marina_product ? esc_html__( 'View Piece', 'marina-clothing' ) : esc_html__( 'Read Story', 'marina-clothing' ); ?></span>
            <?php marina_the_icon( 'arrow_forward' ); ?>
        </a>
    </div>
</article>
