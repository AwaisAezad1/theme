<?php
/**
 * Product Loop Start
 *
 * Override of woocommerce/templates/loop/loop-start.php
 *
 * @package     WooCommerce\Templates
 * @version     3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<ul class="products product-grid columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?>">
