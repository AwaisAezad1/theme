import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { buildTrustedProxyCheck, parseIp } from '../src/lib/ip.js';

describe('parseIp', () => {
  it('accepts public IPv4 and IPv6', () => {
    assert.deepEqual(parseIp('8.8.8.8'), { ip: '8.8.8.8', version: 4, isPublic: true, range: 'public' });
    const v6 = parseIp('2001:4860:4860:0:0:0:0:8888');
    assert.equal(v6?.ip, '2001:4860:4860::8888');
    assert.equal(v6?.version, 6);
    assert.equal(v6?.isPublic, true);
  });

  it('trims whitespace and brackets', () => {
    assert.equal(parseIp('  8.8.4.4 ')?.ip, '8.8.4.4');
    assert.equal(parseIp('[2001:4860:4860::8844]')?.ip, '2001:4860:4860::8844');
  });

  it('unwraps IPv4-mapped IPv6', () => {
    const p = parseIp('::ffff:8.8.8.8');
    assert.equal(p?.ip, '8.8.8.8');
    assert.equal(p?.version, 4);
    assert.equal(p?.isPublic, true);
  });

  it('classifies non-public ranges', () => {
    assert.equal(parseIp('127.0.0.1')?.isPublic, false);
    assert.equal(parseIp('127.0.0.1')?.range, 'loopback');
    assert.equal(parseIp('10.1.2.3')?.range, 'private');
    assert.equal(parseIp('192.168.1.1')?.range, 'private');
    assert.equal(parseIp('172.16.0.1')?.range, 'private');
    assert.equal(parseIp('100.64.0.1')?.range, 'carrier-grade-nat');
    assert.equal(parseIp('169.254.1.1')?.range, 'link-local');
    assert.equal(parseIp('::1')?.range, 'loopback');
    assert.equal(parseIp('fe80::1')?.range, 'link-local');
    assert.equal(parseIp('fd00::1')?.range, 'private');
    assert.equal(parseIp('224.0.0.1')?.isPublic, false);
    assert.equal(parseIp('0.0.0.0')?.isPublic, false);
    assert.equal(parseIp('203.0.113.9')?.isPublic, false); // documentation range
  });

  it('rejects anything that is not a plain IP', () => {
    for (const bad of [
      '',
      ' ',
      'abc',
      '1.2',
      '1.2.3',
      '1.2.3.4.5',
      '256.1.1.1',
      '01.1.1.1',
      '0x7f.0.0.1',
      '8.8.8.8/24',
      '8.8.8.8:80',
      'fe80::1%eth0',
      '::g',
      '2001:db8::1::2',
      '8.8.8.8 8.8.4.4',
      'example.com',
      '1'.repeat(60),
    ]) {
      assert.equal(parseIp(bad), null, `should reject ${JSON.stringify(bad)}`);
    }
  });
});

describe('buildTrustedProxyCheck', () => {
  it('handles named ranges', () => {
    const t = buildTrustedProxyCheck('loopback,linklocal,uniquelocal');
    assert.equal(t('127.0.0.1'), true);
    assert.equal(t('::1'), true);
    assert.equal(t('::ffff:127.0.0.1'), true);
    assert.equal(t('10.0.0.5'), true);
    assert.equal(t('172.17.0.2'), true);
    assert.equal(t('8.8.8.8'), false);
    assert.equal(t(undefined), false);
  });

  it('handles true / false / CIDR / single IP', () => {
    assert.equal(buildTrustedProxyCheck('true')('8.8.8.8'), true);
    assert.equal(buildTrustedProxyCheck('false')('127.0.0.1'), false);
    const t = buildTrustedProxyCheck('203.0.113.0/24, 2001:db8::/32, 198.51.100.7');
    assert.equal(t('203.0.113.50'), true);
    assert.equal(t('203.0.114.1'), false);
    assert.equal(t('2001:db8::1'), true);
    assert.equal(t('198.51.100.7'), true);
    assert.equal(t('198.51.100.8'), false);
  });

  it('throws on garbage', () => {
    assert.throws(() => buildTrustedProxyCheck('loopback,not-an-ip'), /Invalid TRUST_PROXY/);
  });
});
