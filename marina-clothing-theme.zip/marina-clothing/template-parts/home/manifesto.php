<?php
/**
 * Home: dark navy brand story.
 */

$marina_img = marina_opt( 'manifesto_image' ) ? marina_opt( 'manifesto_image' ) : marina_image( 'story' );
$marina_url = marina_opt( 'manifesto_url' );
?>
<section class="section section--dark manifesto">
    <div class="manifesto__motif" aria-hidden="true">
        <svg viewBox="0 0 400 400" fill="none" stroke="currentColor" stroke-width="1">
            <circle cx="200" cy="200" r="180" stroke-dasharray="4 8"></circle>
            <circle cx="200" cy="200" r="120"></circle>
            <circle cx="200" cy="200" r="60"></circle>
            <path d="M20,200 L380,200 M200,20 L200,380"></path>
        </svg>
    </div>

    <div class="container manifesto__grid">
        <figure class="manifesto__media">
            <img src="<?php echo esc_url( $marina_img ); ?>" alt="" loading="lazy">
            <figcaption>
                <span><?php esc_html_e( 'The Marina Clothing Studio', 'marina-clothing' ); ?></span>
                <strong><?php esc_html_e( 'Thoughtfully Designed • Made to Last', 'marina-clothing' ); ?></strong>
            </figcaption>
        </figure>

        <div class="manifesto__copy">
            <span class="eyebrow eyebrow--rule eyebrow--light"><?php esc_html_e( 'Our Story', 'marina-clothing' ); ?></span>
            <h2 class="manifesto__title">
                <?php esc_html_e( 'Designed With Care,', 'marina-clothing' ); ?><br>
                <em><?php esc_html_e( 'Made', 'marina-clothing' ); ?></em> <?php esc_html_e( 'To Last.', 'marina-clothing' ); ?>
            </h2>
            <p class="manifesto__lead"><?php esc_html_e( 'At Marina Clothing we believe great clothes should feel as good as they look. We focus on quality fabrics, flattering fits and timeless pieces you will reach for again and again.', 'marina-clothing' ); ?></p>
            <p class="manifesto__text"><?php esc_html_e( 'From the first sketch to the final stitch, every garment is designed with intention, so you can build a wardrobe that works for every day and every occasion, season after season.', 'marina-clothing' ); ?></p>
            <?php if ( $marina_url ) : ?>
                <a class="manifesto__link" href="<?php echo esc_url( $marina_url ); ?>">
                    <span><?php esc_html_e( 'Read Our Story', 'marina-clothing' ); ?></span>
                    <?php marina_the_icon( 'arrow_forward' ); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>
