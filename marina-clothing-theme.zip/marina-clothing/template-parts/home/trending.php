<?php
/**
 * Home: "Trending Now" grid with category filter chips.
 */

$marina_products = marina_products_with_photos( array( 'orderby' => 'popularity' ), 8 );

if ( ! $marina_products ) {
    return;
}

$marina_chips = array();
foreach ( $marina_products as $marina_p ) {
    $marina_terms = get_the_terms( $marina_p->get_id(), 'product_cat' );
    if ( $marina_terms && ! is_wp_error( $marina_terms ) ) {
        foreach ( $marina_terms as $marina_t ) {
            if ( (int) get_option( 'default_product_cat' ) !== $marina_t->term_id ) {
                $marina_chips[ $marina_t->slug ] = $marina_t->name;
            }
        }
    }
}
$marina_chips = array_slice( $marina_chips, 0, 4, true );
?>
<section class="section section--low trending" id="trending" data-filter-group>
    <div class="container">
        <div class="section-head section-head--spaced">
            <div>
                <span class="eyebrow"><?php esc_html_e( 'Seasonal Edit', 'marina-clothing' ); ?></span>
                <h2 class="section-head__title"><?php esc_html_e( 'Trending Now', 'marina-clothing' ); ?></h2>
            </div>
            <?php if ( count( $marina_chips ) > 1 ) : ?>
                <div class="chip-row" role="group" aria-label="<?php esc_attr_e( 'Filter pieces', 'marina-clothing' ); ?>">
                    <button type="button" class="chip is-active" aria-pressed="true" data-filter="all"><?php esc_html_e( 'All Pieces', 'marina-clothing' ); ?></button>
                    <?php foreach ( $marina_chips as $marina_slug => $marina_name ) : ?>
                        <button type="button" class="chip" aria-pressed="false" data-filter="<?php echo esc_attr( $marina_slug ); ?>"><?php echo esc_html( $marina_name ); ?></button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php marina_render_product_cards( $marina_products, 'columns-4' ); ?>

        <div class="section-foot">
            <a class="btn btn--ghost" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">
                <span><?php esc_html_e( 'Shop Every Piece', 'marina-clothing' ); ?></span>
                <?php marina_the_icon( 'arrow_forward' ); ?>
            </a>
        </div>
    </div>
</section>
