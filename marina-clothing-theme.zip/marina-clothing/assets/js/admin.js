/**
 * Admin JavaScript.
 *
 * Enqueue this file from inc/enqueue.php when needed.
 */
(function () {
    'use strict';
})();
