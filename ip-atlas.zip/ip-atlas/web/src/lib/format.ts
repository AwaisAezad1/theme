import type { GeoRecord, ProviderResult } from '../types';

export const DASH = '\u2014';
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function formatCoordinates(lat: number | null, lon: number | null): string | null {
  if (lat === null || lon === null) return null;
  return `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
}

/** "2026-10-09T11:24:18+05:00" -> "11:24" */
export function formatClock(localTime: string | null | undefined): string | null {
  const m = localTime ? /T(\d{2}:\d{2})/.exec(localTime) : null;
  return m ? m[1]! : null;
}

/** "2026-10-09T11:24:18+05:00" or "2026-10-09" -> "9 Oct 2026" */
export function formatDate(value: string | null | undefined): string | null {
  const m = value ? /^(\d{4})-(\d{2})-(\d{2})/.exec(value) : null;
  return m ? `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[1]}` : null;
}

export function openStreetMapUrl(lat: number, lon: number): string {
  return `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=10/${lat}/${lon}`;
}

const norm = (s: string) =>
  s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

/** True when at least two providers answered with a value and the values are not all the same. */
export function valuesDiffer(values: Array<string | null>): boolean {
  const present = values.filter((v): v is string => v !== null && v !== '').map(norm);
  return present.length >= 2 && new Set(present).size > 1;
}

function haversineKm(a: [number, number], b: [number, number]): number {
  const rad = (d: number) => (d * Math.PI) / 180;
  const dLat = rad(b[0] - a[0]);
  const dLon = rad(b[1] - a[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}

/** True when two providers place the IP more than `thresholdKm` apart. */
export function coordinatesDiffer(points: Array<[number, number] | null>, thresholdKm = 100): boolean {
  const present = points.filter((p): p is [number, number] => p !== null);
  for (let i = 0; i < present.length; i++) {
    for (let j = i + 1; j < present.length; j++) {
      if (haversineKm(present[i]!, present[j]!) > thresholdKm) return true;
    }
  }
  return false;
}

export type Row = {
  key: string;
  label: string;
  get: (r: GeoRecord) => string | null;
  /** Returns true when the providers disagree for this row. */
  differs?: (results: ProviderResult[]) => boolean;
};

const okData = (results: ProviderResult[]) => results.map((r) => (r.status === 'ok' ? r.data : null));

export const COMPARE_ROWS: Row[] = [
  {
    key: 'country',
    label: 'Country',
    get: (r) => (r.country ? (r.country_code ? `${r.country} (${r.country_code})` : r.country) : r.country_code),
    differs: (rs) => valuesDiffer(okData(rs).map((d) => d?.country_code ?? null)),
  },
  { key: 'region', label: 'Region', get: (r) => r.region, differs: (rs) => valuesDiffer(okData(rs).map((d) => d?.region ?? null)) },
  { key: 'city', label: 'City', get: (r) => r.city, differs: (rs) => valuesDiffer(okData(rs).map((d) => d?.city ?? null)) },
  { key: 'postal', label: 'Postal code', get: (r) => r.postal_code, differs: (rs) => valuesDiffer(okData(rs).map((d) => d?.postal_code ?? null)) },
  {
    key: 'coords',
    label: 'Coordinates',
    get: (r) => formatCoordinates(r.latitude, r.longitude),
    differs: (rs) =>
      coordinatesDiffer(okData(rs).map((d) => (d && d.latitude !== null && d.longitude !== null ? [d.latitude, d.longitude] : null))),
  },
  { key: 'accuracy', label: 'Accuracy radius', get: (r) => (r.accuracy_radius_km !== null ? `${r.accuracy_radius_km} km` : null) },
  { key: 'timezone', label: 'Timezone', get: (r) => r.timezone ?? (r.utc_offset ? `UTC${r.utc_offset}` : null) },
  { key: 'asn', label: 'ASN', get: (r) => (r.asn !== null ? `AS${r.asn}` : null) },
  { key: 'org', label: 'Organization', get: (r) => r.organization ?? r.isp },
  { key: 'domain', label: 'Domain', get: (r) => r.domain },
];

/** Core rows always; optional rows only when some provider has a value. */
export function visibleRows(results: ProviderResult[]): Row[] {
  const optional = new Set(['accuracy', 'domain']);
  return COMPARE_ROWS.filter((row) => !optional.has(row.key) || results.some((r) => r.data && row.get(r.data) !== null));
}

export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // fall through to the legacy path
  }
  try {
    const el = document.createElement('textarea');
    el.value = text;
    el.setAttribute('readonly', '');
    el.style.position = 'fixed';
    el.style.opacity = '0';
    document.body.appendChild(el);
    el.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(el);
    return ok;
  } catch {
    return false;
  }
}
