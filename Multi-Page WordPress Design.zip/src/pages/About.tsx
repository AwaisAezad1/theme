type NavFn = (page: any) => void;

const team = [
  { name: "Jordan Reeves", role: "Founder & Creative Director", img: "photo-1560250097-0b93528c311a", years: "12 yrs exp" },
  { name: "Priya Nair", role: "Lead Developer", img: "photo-1573496359142-b8d87734a5a2", years: "9 yrs exp" },
  { name: "Tom Eriksson", role: "Head of SEO & Growth", img: "photo-1519085360753-af0119f7cbe7", years: "8 yrs exp" },
  { name: "Camille Moreau", role: "Brand & UX Strategist", img: "photo-1487412720507-e7ab37603c6f", years: "7 yrs exp" },
];

const values = [
  { icon: "◈", title: "Results first", desc: "Beautiful means nothing if it doesn't convert. We obsess over outcomes, not aesthetics alone." },
  { icon: "◉", title: "Radical transparency", desc: "You see everything — strategy, timelines, metrics. No black boxes, no billing surprises." },
  { icon: "◐", title: "Speed as a feature", desc: "Every site we ship scores 95+ on PageSpeed. Because slow sites lose sales." },
  { icon: "◇", title: "Long-term partnership", desc: "We don't disappear after launch. We're your growth partner for the long haul." },
];

export default function AboutPage({ navigate }: { navigate: NavFn }) {
  return (
    <div>
      {/* HERO */}
      <section style={{ padding: "6rem 2rem 5rem", maxWidth: 1280, margin: "0 auto" }}>
        <div className="section-label" style={{ marginBottom: "1.5rem" }}>About Vantage</div>
        <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: "6rem", alignItems: "center" }}>
          <div>
            <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 5vw, 5rem)", fontWeight: 900, lineHeight: 1.05, letterSpacing: "-0.02em", marginBottom: "2rem" }}>
              We're the agency<br />
              <em style={{ color: "#FF5500", fontStyle: "italic" }}>results-obsessed</em><br />
              founders trust.
            </h1>
            <p style={{ color: "#888", fontSize: "1rem", lineHeight: 1.9, marginBottom: "1.5rem" }}>
              Founded in 2018 out of frustration with agencies that delivered pretty portfolios but ignored revenue, Vantage was built on a single premise: your website should be your best salesperson.
            </p>
            <p style={{ color: "#888", fontSize: "1rem", lineHeight: 1.9, marginBottom: "2.5rem" }}>
              Today we work with B2B companies, SaaS startups, e-commerce brands, and professional service firms — anyone who is serious about growth and tired of sites that just sit there.
            </p>
            <button className="btn-primary" onClick={() => navigate("Contact")}>Work With Us</button>
          </div>
          <div style={{ position: "relative" }}>
            <img
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=700&fit=crop&auto=format"
              alt="Vantage team collaborating"
              style={{ width: "100%", height: 500, objectFit: "cover" }}
            />
            <div style={{ position: "absolute", bottom: "-2rem", left: "-2rem", background: "#FF5500", padding: "2rem" }}>
              <div className="font-display" style={{ fontSize: "2.5rem", fontWeight: 900, color: "#080808", lineHeight: 1 }}>2018</div>
              <div style={{ fontSize: "0.72rem", fontWeight: 700, color: "#080808", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: "0.4rem" }}>Founded</div>
            </div>
          </div>
        </div>

        <style>{`@media (max-width: 900px) { section > div[style*="grid-template-columns: 1.2fr"] { grid-template-columns: 1fr !important; } }`}</style>
      </section>

      {/* VALUES */}
      <section style={{ background: "#0D0D0D", padding: "6rem 2rem" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          <div className="section-label" style={{ marginBottom: "1rem" }}>Our Values</div>
          <h2 className="font-display" style={{ fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "4rem" }}>
            Principles we won't compromise on.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "2rem" }}>
            {values.map((v, i) => (
              <div key={i} className="card-hover" style={{ padding: "2.5rem", background: "#111", borderLeft: "3px solid #FF5500" }}>
                <div style={{ fontSize: "1.5rem", marginBottom: "1.5rem", color: "#FF5500" }}>{v.icon}</div>
                <h3 className="font-display" style={{ fontSize: "1.15rem", fontWeight: 700, marginBottom: "0.8rem" }}>{v.title}</h3>
                <p style={{ color: "#666", fontSize: "0.88rem", lineHeight: 1.8 }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TEAM */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "7rem 2rem" }}>
        <div className="section-label" style={{ marginBottom: "1rem" }}>The Team</div>
        <h2 className="font-display" style={{ fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "4rem" }}>
          Experts. Not order-takers.
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "2rem" }}>
          {team.map((m, i) => (
            <div key={i} className="card-hover" style={{ overflow: "hidden" }}>
              <div style={{ position: "relative", aspectRatio: "3/4", overflow: "hidden", background: "#111" }}>
                <img
                  src={`https://images.unsplash.com/${m.img}?w=400&h=530&fit=crop&auto=format`}
                  alt={m.name}
                  style={{ width: "100%", height: "100%", objectFit: "cover", filter: "grayscale(30%)", transition: "filter 0.3s" }}
                  onMouseEnter={e => (e.currentTarget.style.filter = "grayscale(0%)")}
                  onMouseLeave={e => (e.currentTarget.style.filter = "grayscale(30%)")}
                />
                <div style={{ position: "absolute", top: "1rem", right: "1rem", background: "#FF5500", padding: "0.3rem 0.6rem", fontSize: "0.68rem", fontWeight: 700, color: "#080808", letterSpacing: "0.08em", textTransform: "uppercase" }}>{m.years}</div>
              </div>
              <div style={{ padding: "1.5rem 0.5rem 0" }}>
                <div className="font-display" style={{ fontSize: "1.1rem", fontWeight: 700, marginBottom: "0.3rem" }}>{m.name}</div>
                <div style={{ fontSize: "0.8rem", color: "#555", letterSpacing: "0.05em" }}>{m.role}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* TIMELINE */}
      <section style={{ background: "#0D0D0D", padding: "6rem 2rem" }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <div className="section-label" style={{ marginBottom: "1rem" }}>Our Story</div>
          <h2 className="font-display" style={{ fontSize: "clamp(1.8rem, 3vw, 2.8rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "4rem" }}>
            How we got here.
          </h2>
          {[
            { year: "2018", event: "Founded with 3 clients and a mission to fix WordPress agencies" },
            { year: "2019", event: "Launched our proprietary conversion audit framework" },
            { year: "2020", event: "Grew to a team of 8 through client referrals alone" },
            { year: "2022", event: "Crossed $1M ARR in managed WordPress contracts" },
            { year: "2024", event: "Opened our second studio in Berlin" },
            { year: "2026", event: "340+ sites launched. Still obsessed with results." },
          ].map((e, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "80px 1fr", gap: "2rem", marginBottom: "2.5rem", paddingBottom: "2.5rem", borderBottom: "1px solid #1A1A1A" }}>
              <div className="font-display" style={{ fontSize: "1.1rem", fontWeight: 700, color: "#FF5500", paddingTop: "0.2rem" }}>{e.year}</div>
              <div style={{ color: "#BBB", fontSize: "0.95rem", lineHeight: 1.7 }}>{e.event}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "6rem 2rem", textAlign: "center" }}>
        <div style={{ maxWidth: 600, margin: "0 auto" }}>
          <h2 className="font-display" style={{ fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "1.5rem" }}>
            Let's build something<br /><em style={{ color: "#FF5500", fontStyle: "italic" }}>worth talking about.</em>
          </h2>
          <p style={{ color: "#666", marginBottom: "2.5rem", lineHeight: 1.8 }}>We're selective about who we work with because we're committed to delivering real results.</p>
          <button className="btn-primary" onClick={() => navigate("Contact")}>Start a Conversation</button>
        </div>
      </section>
    </div>
  );
}
