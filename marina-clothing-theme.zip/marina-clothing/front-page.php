<?php
/**
 * Front page.
 *
 * Editorial home built from the Marina design. Product-driven sections pull
 * live WooCommerce data; copy & imagery are editable in the Customizer.
 * If the front page is a static page with its own content, that content is
 * shown after the hero.
 */

get_header();
?>

<main id="primary" class="site-main home">
    <?php
    get_template_part( 'template-parts/home/hero' );

    if ( is_page() ) {
        while ( have_posts() ) {
            the_post();
            if ( '' !== trim( get_the_content() ) ) {
                echo '<section class="section"><div class="container container--prose entry-content">';
                the_content();
                echo '</div></section>';
            }
        }
    }

    if ( marina_is_woocommerce_active() ) {
        get_template_part( 'template-parts/home/categories' );
        get_template_part( 'template-parts/home/closet' );
        get_template_part( 'template-parts/home/spotlight' );
        get_template_part( 'template-parts/home/trending' );
    } else {
        get_template_part( 'template-parts/home/journal' );
    }

    get_template_part( 'template-parts/home/manifesto' );
    get_template_part( 'template-parts/home/values' );
    get_template_part( 'template-parts/home/newsletter' );
    ?>
</main>

<?php
get_footer();
