(function () {
  'use strict';

  var cfg = window.AIBW || {};
  var t = cfg.i18n || {};

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function post(action, data) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('nonce', cfg.nonce);
    Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(cfg.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function (r) { return r.text(); })
      .then(function (txt) {
        try { return JSON.parse(txt); } catch (e) { throw new Error(t.badResponse); }
      });
  }

  /* ---------------------------------------------------------------- */
  /* Write a Blog page                                                */
  /* ---------------------------------------------------------------- */
  function initWriter() {
    var topicEl = $('#aibw-topic');
    var genBtn = $('#aibw-generate');
    var result = $('#aibw-result');
    var done = $('#aibw-done');
    var state = { provider: '', topic: '', cover: null, coverQuery: '', run: 0 };

    function setStatus(id, msg, isError) {
      var el = $(id);
      if (!el) { return; }
      el.textContent = msg || '';
      el.className = 'aibw-status' + (isError ? ' is-error' : '');
    }

    function busy(on) {
      $$('#aibw-generate, #aibw-publish, #aibw-draft, #aibw-regenerate').forEach(function (b) { b.disabled = on; });
      $$('#aibw-spinner, #aibw-spinner2').forEach(function (s) { s.classList.toggle('is-active', on); });
    }

    // Highlight the chosen AI card.
    $$('input[name="aibw_provider"]').forEach(function (radio) {
      radio.addEventListener('change', function () {
        $$('.aibw-provider').forEach(function (l) { l.classList.remove('is-selected'); });
        if (radio.checked) { radio.closest('.aibw-provider').classList.add('is-selected'); }
      });
    });

    /* ---------- pictures ---------- */
    function usedUids() {
      var ids = $$('#aibw-content figure.aibw-figure[data-aibw-uid]').map(function (f) { return f.getAttribute('data-aibw-uid'); });
      if (state.cover && state.cover.uid) { ids.push(state.cover.uid); }
      return ids;
    }

    function lockPublish(on) {
      $$('#aibw-publish, #aibw-draft').forEach(function (b) { b.disabled = on; });
    }

    function makeBtn(act, label, cls) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = cls;
      b.setAttribute('data-act', act);
      b.textContent = label;
      return b;
    }

    function fillFigure(fig, item) {
      fig.classList.remove('aibw-pending');
      fig.setAttribute('data-aibw-uid', item.uid);
      fig.setAttribute('contenteditable', 'false');
      fig.innerHTML = '';
      var img = document.createElement('img');
      img.src = item.src;
      img.alt = item.alt || '';
      var cap = document.createElement('figcaption');
      cap.innerHTML = item.credit; // Built and escaped on the server.
      var tools = document.createElement('div');
      tools.className = 'aibw-tools';
      tools.setAttribute('contenteditable', 'false');
      tools.appendChild(makeBtn('swap', t.swap, 'button button-small'));
      tools.appendChild(makeBtn('remove', t.remove, 'button button-small'));
      fig.appendChild(img);
      fig.appendChild(cap);
      fig.appendChild(tools);
    }

    function setCover(item) {
      var box = $('#aibw-cover');
      if (!item) { state.cover = null; box.hidden = true; return; }
      state.cover = { src: item.src, alt: item.alt || '', credit: item.credit, uid: item.uid };
      $('#aibw-cover-img').src = item.src;
      $('#aibw-cover-img').alt = item.alt || '';
      $('#aibw-cover-credit').innerHTML = item.credit;
      box.hidden = false;
    }

    function swapPicture(query, onItem, btn) {
      setStatus('#aibw-imgstatus', t.findingImages);
      if (btn) { btn.disabled = true; }
      post('aibw_images', { queries: JSON.stringify([query]), exclude: JSON.stringify(usedUids()) })
        .then(function (res) {
          if (btn) { btn.disabled = false; }
          if (!res.success) { setStatus('#aibw-imgstatus', (res.data && res.data.message) || t.noImage, true); return; }
          var item = res.data.items && res.data.items[0];
          if (!item) { setStatus('#aibw-imgstatus', t.noImage, true); return; }
          setStatus('#aibw-imgstatus', '');
          onItem(item);
        })
        .catch(function (err) {
          if (btn) { btn.disabled = false; }
          setStatus('#aibw-imgstatus', err.message, true);
        });
    }

    function loadImages(coverQuery, run) {
      var figs = $$('#aibw-content figure.aibw-figure[data-aibw-query]');
      var queries = [];
      if (coverQuery) { queries.push(coverQuery); }
      figs.forEach(function (f) { queries.push(f.getAttribute('data-aibw-query')); });
      if (!queries.length) { return; }

      lockPublish(true);
      setStatus('#aibw-imgstatus', t.findingImages);
      post('aibw_images', { queries: JSON.stringify(queries), exclude: '[]' })
        .then(function (res) {
          if (run !== state.run) { return; }
          lockPublish(false);
          if (!res.success) {
            figs.forEach(function (f) { f.remove(); });
            setStatus('#aibw-imgstatus', t.imagesFailed + ' ' + ((res.data && res.data.message) || ''), true);
            return;
          }
          var items = res.data.items || [];
          var i = 0;
          if (coverQuery) { setCover(items[i++]); }
          figs.forEach(function (f) {
            var it = items[i++];
            if (it) { fillFigure(f, it); } else { f.remove(); }
          });
          setStatus('#aibw-imgstatus', '');
        })
        .catch(function (err) {
          if (run !== state.run) { return; }
          lockPublish(false);
          figs.forEach(function (f) { f.remove(); });
          setStatus('#aibw-imgstatus', t.imagesFailed + ' ' + err.message, true);
        });
    }

    // Swap / remove buttons on pictures inside the blog.
    $('#aibw-content').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('.aibw-tools button') : null;
      if (!btn) { return; }
      e.preventDefault();
      var fig = btn.closest('figure');
      if (btn.getAttribute('data-act') === 'remove') { fig.remove(); return; }
      swapPicture(fig.getAttribute('data-aibw-query') || '', function (item) { fillFigure(fig, item); }, btn);
    });

    $('#aibw-cover-remove').addEventListener('click', function () { setCover(null); });
    $('#aibw-cover-swap').addEventListener('click', function () {
      swapPicture(state.coverQuery, setCover, this);
    });

    function generate() {
      var topic = topicEl.value.trim();
      var chosen = $('input[name="aibw_provider"]:checked');
      setStatus('#aibw-status', '');
      setStatus('#aibw-status2', '');
      if (topic.length < 3) { setStatus('#aibw-status', t.needTopic, true); topicEl.focus(); return; }
      if (!chosen) { setStatus('#aibw-status', 'Please choose an AI that is connected.', true); return; }

      busy(true);
      setStatus('#aibw-status', t.writing);
      setStatus('#aibw-status2', t.writing);
      done.hidden = true;

      post('aibw_generate', {
        topic: topic,
        provider: chosen.value,
        tone: $('#aibw-tone').value,
        length: $('#aibw-length').value,
        language: $('#aibw-language').value,
        notes: $('#aibw-notes').value,
        images: $('#aibw-images') ? $('#aibw-images').value : 'none'
      }).then(function (res) {
        busy(false);
        if (!res.success) {
          var m = (res.data && res.data.message) || 'Something went wrong.';
          setStatus('#aibw-status', m, true);
          setStatus('#aibw-status2', m, true);
          return;
        }
        var d = res.data;
        state.provider = d.provider;
        state.topic = topic;
        state.run += 1;
        state.coverQuery = d.cover_query || '';
        setCover(null);
        setStatus('#aibw-imgstatus', '');
        $('#aibw-title').value = d.title;
        $('#aibw-content').innerHTML = d.content; // Already sanitised on the server.
        $('#aibw-by-name').textContent = d.provider_label;
        var notice = $('#aibw-notice');
        if (d.notice) { $('p', notice).textContent = d.notice; notice.hidden = false; } else { notice.hidden = true; }
        setStatus('#aibw-status', '');
        setStatus('#aibw-status2', '');
        result.hidden = false;
        result.scrollIntoView({ behavior: 'smooth', block: 'start' });
        loadImages(state.coverQuery, state.run);
      }).catch(function (err) {
        busy(false);
        setStatus('#aibw-status', err.message, true);
        setStatus('#aibw-status2', err.message, true);
      });
    }

    function publish(status) {
      var title = $('#aibw-title').value.trim();
      var clone = $('#aibw-content').cloneNode(true);
      $$('.aibw-tools, figure.aibw-pending', clone).forEach(function (n) { n.remove(); });
      $$('[contenteditable]', clone).forEach(function (n) { n.removeAttribute('contenteditable'); });
      var content = clone.innerHTML.trim();
      setStatus('#aibw-status2', '');
      if (!title) { setStatus('#aibw-status2', t.needTitle, true); return; }
      if (!$('#aibw-content').textContent.trim()) { setStatus('#aibw-status2', t.needContent, true); return; }

      busy(true);
      setStatus('#aibw-status2', t.saving);
      var sticky = $('#aibw-sticky');

      post('aibw_publish', {
        status: status,
        title: title,
        content: content,
        topic: state.topic,
        provider: state.provider,
        sticky: sticky && sticky.checked ? '1' : '',
        category: $('#aibw-category').value,
        cover: state.cover ? JSON.stringify({ src: state.cover.src, alt: state.cover.alt, credit: state.cover.credit }) : ''
      }).then(function (res) {
        if (!res.success) {
          busy(false);
          setStatus('#aibw-status2', (res.data && res.data.message) || 'Something went wrong.', true);
          return;
        }
        var d = res.data;
        $('#aibw-done-msg').textContent = d.message;
        $('#aibw-done-view').href = d.view_url;
        $('#aibw-done-home').href = d.home_url;
        $('#aibw-done-home').hidden = d.status !== 'publish';
        $('#aibw-done-edit').href = d.edit_url;
        result.hidden = true;
        done.hidden = false;
        busy(false);
        done.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }).catch(function (err) {
        busy(false);
        setStatus('#aibw-status2', err.message, true);
      });
    }

    genBtn.addEventListener('click', generate);
    $('#aibw-regenerate').addEventListener('click', generate);
    var pub = $('#aibw-publish');
    if (pub) { pub.addEventListener('click', function () { publish('publish'); }); }
    $('#aibw-draft').addEventListener('click', function () { publish('draft'); });

    $('#aibw-another').addEventListener('click', function () {
      topicEl.value = '';
      done.hidden = true;
      result.hidden = true;
      window.scrollTo({ top: 0, behavior: 'smooth' });
      topicEl.focus();
    });
  }

  /* ---------------------------------------------------------------- */
  /* AI Accounts page                                                 */
  /* ---------------------------------------------------------------- */
  function initAccounts() {
    $$('.aibw-account').forEach(function (card) {
      var id = card.getAttribute('data-provider');
      var btn = $('.aibw-test', card);
      var spin = $('.spinner', card);
      var out = $('.aibw-test-result', card);
      var keyEl = $('input[type="password"]', card);
      var modelEl = $('input[list]', card);
      var list = $('datalist', card);

      btn.addEventListener('click', function () {
        out.textContent = t.testing;
        out.className = 'aibw-test-result';
        spin.classList.add('is-active');
        btn.disabled = true;

        post('aibw_test', { provider: id, key: keyEl.value, model: modelEl.value })
          .then(function (res) {
            spin.classList.remove('is-active');
            btn.disabled = false;
            if (!res.success) {
              out.textContent = (res.data && res.data.message) || 'Failed.';
              out.className = 'aibw-test-result is-error';
              return;
            }
            out.textContent = res.data.message;
            out.className = 'aibw-test-result is-ok';
            list.innerHTML = '';
            (res.data.models || []).forEach(function (m) {
              var o = document.createElement('option');
              o.value = m;
              list.appendChild(o);
            });
          })
          .catch(function (err) {
            spin.classList.remove('is-active');
            btn.disabled = false;
            out.textContent = err.message;
            out.className = 'aibw-test-result is-error';
          });
      });
    });
  }

  function initImageSources() {
    $$('.aibw-imgsrc').forEach(function (card) {
      var source = card.getAttribute('data-source');
      var btn = $('.aibw-test', card);
      var spin = $('.spinner', card);
      var out = $('.aibw-test-result', card);
      var keyEl = $('input[type="password"]', card);

      btn.addEventListener('click', function () {
        out.textContent = t.testing;
        out.className = 'aibw-test-result';
        spin.classList.add('is-active');
        btn.disabled = true;
        post('aibw_test_image', { source: source, key: keyEl.value })
          .then(function (res) {
            spin.classList.remove('is-active');
            btn.disabled = false;
            out.textContent = (res.data && res.data.message) || (res.success ? 'OK' : 'Failed.');
            out.className = 'aibw-test-result ' + (res.success ? 'is-ok' : 'is-error');
          })
          .catch(function (err) {
            spin.classList.remove('is-active');
            btn.disabled = false;
            out.textContent = err.message;
            out.className = 'aibw-test-result is-error';
          });
      });
    });
  }

  if ($('#aibw-form')) { initWriter(); }
  if ($('.aibw-imgsrc')) { initImageSources(); }
  if ($('.aibw-account')) { initAccounts(); }
})();
