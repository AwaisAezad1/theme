<?php
/**
 * Plugin Name: Inkwell AI Blog Writer
 * Description: Type a topic, pick an AI (ChatGPT, Claude, Gemini, Perplexity or free Groq), and add the finished blog to your front page in one click.
 * Version: 1.0.0
 * Author: Nitrozeus
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: inkwell-ai-blog-writer
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 */

defined( 'ABSPATH' ) || exit;

define( 'AIBW_VERSION', '1.0.0' );
define( 'AIBW_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIBW_URL', plugin_dir_url( __FILE__ ) );
define( 'AIBW_BASENAME', plugin_basename( __FILE__ ) );

require_once AIBW_DIR . 'includes/class-aibw-settings.php';
require_once AIBW_DIR . 'includes/class-aibw-providers.php';
require_once AIBW_DIR . 'includes/class-aibw-generator.php';
require_once AIBW_DIR . 'includes/class-aibw-admin.php';

/**
 * Activation: store defaults once.
 */
function aibw_activate() {
	if ( false === get_option( AIBW_Settings::OPTION ) ) {
		add_option( AIBW_Settings::OPTION, AIBW_Settings::defaults() );
	}
}
register_activation_hook( __FILE__, 'aibw_activate' );

/**
 * Shortcode: [aibw_latest_blogs count="3"]
 * Useful when the site's front page is a static page instead of the blog posts list.
 */
function aibw_latest_blogs_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'count' => 3 ), $atts, 'aibw_latest_blogs' );
	$count = max( 1, min( 20, (int) $atts['count'] ) );

	$query = new WP_Query(
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $count,
			'ignore_sticky_posts' => true,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'            => '_aibw_generated',
			'meta_value'          => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);

	if ( ! $query->have_posts() ) {
		return '';
	}

	$out = '<ul class="aibw-latest-blogs">';
	while ( $query->have_posts() ) {
		$query->the_post();
		$out .= '<li><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a>'
			. '<br><small>' . esc_html( get_the_date() ) . '</small>'
			. '<p>' . esc_html( wp_trim_words( get_the_excerpt(), 28 ) ) . '</p></li>';
	}
	wp_reset_postdata();

	return $out . '</ul>';
}
add_shortcode( 'aibw_latest_blogs', 'aibw_latest_blogs_shortcode' );

AIBW_Admin::init();
