import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildApp } from '../src/app.js';
import { loadConfig, type Config } from '../src/config.js';
import { Ip2LocationProvider, type Ip2LocationLike } from '../src/providers/ip2location.js';
import { MaxmindProvider } from '../src/providers/maxmind.js';
import { ProviderRegistry } from '../src/providers/registry.js';
import {
  emptyRecord,
  type GeoProvider,
  type GeoRecord,
  type ProviderId,
  type ProviderInfo,
  type ProviderResult,
} from '../src/providers/types.js';

export const FIXTURES = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fixtures');

export function testConfig(overrides: Record<string, string> = {}): Config {
  return loadConfig({
    NODE_ENV: 'test',
    DATA_DIR: FIXTURES,
    MAXMIND_CITY_DB: 'GeoIP2-City-Test.mmdb',
    MAXMIND_ASN_DB: 'GeoLite2-ASN-Test.mmdb',
    IPINFO_DB: 'does-not-exist.mmdb',
    IP2LOCATION_DB: 'does-not-exist.BIN',
    WEB_DIST: path.join(os.tmpdir(), 'ip-atlas-no-web-build'),
    ...overrides,
  });
}

export const silent = { info() {}, warn() {}, error() {} };

/** Provider returning a fixed record, for tests that need all three providers answering. */
export class StubProvider implements GeoProvider {
  constructor(
    readonly id: ProviderId,
    readonly name: string,
    private record: Partial<GeoRecord> | null,
    private loaded = true,
  ) {}
  async init() {}
  async reloadIfChanged() {
    return false;
  }
  async lookup(): Promise<ProviderResult> {
    if (!this.loaded) return { status: 'unavailable', data: null };
    if (!this.record) return { status: 'no_data', data: null };
    return { status: 'ok', data: { ...emptyRecord(), ...this.record } };
  }
  info(): ProviderInfo {
    return { id: this.id, name: this.name, source: 'stub', loaded: this.loaded, database_date: null, note: null, warning: null };
  }
  close() {}
}

/** Fake IP2Location library object returning a DB11-shaped record for every IP. */
export function fakeIp2Location(raw: Record<string, unknown>): () => Ip2LocationLike {
  return () => ({
    open() {},
    close: () => 0,
    getAll: () => raw,
    getPackageVersion: () => 11,
    getDatabaseVersion: () => '2026.10.1',
  });
}

export const NA = 'This method is not applicable for current IP2Location binary data file. Please upgrade your subscription package to install new data file.';

export const LONDON_DB11: Record<string, unknown> = {
  countryShort: 'GB',
  countryLong: 'United Kingdom of Great Britain and Northern Ireland',
  region: 'England',
  city: 'London',
  latitude: 51.50853,
  longitude: -0.12574,
  zipCode: 'EC1A',
  timeZone: '+00:00',
  isp: NA,
  domain: NA,
  asn: NA,
  as: NA,
};

/** Build an app where MaxMind is real (test databases) and IPinfo / IP2Location are stubs. */
export async function makeApp(overrides: Record<string, string> = {}, opts: { realIp2: boolean } = { realIp2: false }) {
  const config = testConfig(overrides);
  const tmpBin = path.join(os.tmpdir(), `ip-atlas-test-${process.pid}.BIN`);
  fs.writeFileSync(tmpBin, 'x');
  const app = await buildApp(
    config,
    (log) =>
      new ProviderRegistry(
        [
          new MaxmindProvider(config.paths.maxmindCity, config.paths.maxmindAsn, log),
          new StubProvider('ipinfo', 'IPinfo', {
            country_code: 'GB',
            country: 'United Kingdom',
            continent_code: 'EU',
            continent: 'Europe',
            asn: 5089,
            organization: 'Virgin Media Limited',
          }),
          opts.realIp2
            ? new Ip2LocationProvider(tmpBin, log, fakeIp2Location(LONDON_DB11))
            : new StubProvider('ip2location', 'IP2Location', null, false),
        ],
        log,
      ),
    { logger: false },
  );
  return app;
}
