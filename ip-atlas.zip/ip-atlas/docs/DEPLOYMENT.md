# Going live

## What kind of hosting do you need?

This is a Node.js application, so it needs a host that can run Node 20.12+ (22 recommended):

* **A small VPS** (Ubuntu 22.04/24.04, 1 GB RAM should be plenty; the databases are loaded into memory, which I estimate at a few hundred MB in total, so check with `free -m` after your first start). Recommended and described below.
* **Docker** on any machine, see below.
* **cPanel with "Setup Node.js App"**: works if your plan offers it (start file `server/dist/index.js`), but you will have to run `npm ci`, `npm run build` and the database update from its terminal / cron.
* Plain PHP / WordPress shared hosting and static hosts (Netlify, GitHub Pages) **cannot** run this.

## Option A: VPS with nginx (Ubuntu)

```bash
# 1. Node 22 and nginx
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs nginx certbot python3-certbot-nginx

# 2. App user and code
sudo useradd --system --create-home --shell /usr/sbin/nologin ipatlas
sudo mkdir -p /srv/ip-atlas && sudo chown ipatlas:ipatlas /srv/ip-atlas
# copy the project into /srv/ip-atlas (git clone, scp or rsync)

# 3. Build
cd /srv/ip-atlas
sudo -u ipatlas npm ci
sudo -u ipatlas cp .env.example .env     # edit it: add credentials (docs/SETUP.md)
sudo -u ipatlas npm run build
sudo -u ipatlas npm run db:update
sudo -u ipatlas npm run db:check

# 4. Run as a service
sudo cp deploy/ip-atlas.service /etc/systemd/system/
sudo cp deploy/ip-atlas-db-update.service deploy/ip-atlas-db-update.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now ip-atlas ip-atlas-db-update.timer

# 5. nginx + HTTPS (edit the domain in the file first)
sudo cp deploy/nginx.conf.example /etc/nginx/sites-available/ip-atlas
sudo ln -s /etc/nginx/sites-available/ip-atlas /etc/nginx/sites-enabled/
sudo certbot --nginx -d example.com -d www.example.com
sudo nginx -t && sudo systemctl reload nginx
```

Point your domain's DNS A (and AAAA) record to the server before running certbot.

**Updating the site later:** copy the new files, then `npm ci && npm run build && sudo systemctl restart ip-atlas`.

## Option B: Docker

```bash
cp .env.example .env            # add credentials
docker compose build
docker compose run --rm app node server/dist/cli/update-databases.js
docker compose run --rm app node server/dist/cli/check-databases.js
docker compose up -d
```

The container listens on `127.0.0.1:3000`; put nginx / Caddy in front for HTTPS (the nginx example in `deploy/` works unchanged).
Schedule the update command daily with cron.

## Getting the real visitor IP right (important)

The app trusts `X-Forwarded-For` only from the proxies listed in `TRUST_PROXY` (default: the same machine and private networks).

| Setup | What to set |
|---|---|
| nginx / Caddy on the same server or Docker network | nothing (default) |
| Cloudflare in front of nginx | `CLIENT_IP_HEADER=cf-connecting-ip`. Also restrict your firewall so port 443 only accepts Cloudflare's published IP ranges, otherwise anyone reaching the origin directly could fake the header |
| A cloud load balancer with its own address range | add its CIDR to `TRUST_PROXY`, e.g. `TRUST_PROXY=loopback,10.0.0.0/8` |
| App exposed directly to the internet (no proxy) | `TRUST_PROXY=false` |

Verify after deploying: open the site from your phone on mobile data. The "Your IP address" shown must be your public address
(compare with `curl https://yourdomain.com/ip` from another network). If it shows a private address, your proxy settings are wrong.

## Checklist before launch

- [ ] `npm run db:check` shows all three providers loaded with no warnings
- [ ] Visiting the site shows your real public IP (see above)
- [ ] `https://yourdomain.com/api/v1/status` reports `"status": "ok"`
- [ ] `web/src/config.ts`: site name, contact email and privacy note are yours; rebuild afterwards
- [ ] You have a privacy policy / terms that suit your country, and the provider attributions are visible
- [ ] Optional: `API_KEYS` set if you want to hand out higher limits
- [ ] The database update timer is active: `systemctl list-timers | grep ip-atlas`
- [ ] If you add analytics or ads, extend the Content-Security-Policy in `server/src/app.ts` (currently only the site itself is allowed)
