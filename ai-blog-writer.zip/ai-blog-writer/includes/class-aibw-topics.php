<?php
defined( 'ABSPATH' ) || exit;

/**
 * Topic queue and content calendar.
 */
class AIBW_Topics {

	const STATUSES = array( 'suggested', 'pending', 'assigned', 'processing', 'completed', 'failed', 'skipped' );

	public static function insert( $data ) {
		global $wpdb;
		$now   = current_time( 'mysql' );
		$title = isset( $data['title'] ) ? sanitize_text_field( $data['title'] ) : '';
		$title = trim( mb_substr( $title, 0, 300 ) );
		if ( mb_strlen( $title ) < 3 ) {
			return new WP_Error( 'aibw_topic', __( 'A topic needs at least a few words.', 'ai-blog-writer' ) );
		}
		$status = isset( $data['status'] ) && in_array( $data['status'], self::STATUSES, true ) ? $data['status'] : 'pending';
		$row    = array(
			'title'           => $title,
			'keyword'         => isset( $data['keyword'] ) ? sanitize_text_field( $data['keyword'] ) : '',
			'audience'        => isset( $data['audience'] ) ? sanitize_text_field( $data['audience'] ) : '',
			'category'        => isset( $data['category'] ) ? absint( $data['category'] ) : 0,
			'tags'            => isset( $data['tags'] ) ? sanitize_text_field( $data['tags'] ) : '',
			'priority'        => isset( $data['priority'] ) ? (int) $data['priority'] : 0,
			'status'          => $status,
			'scheduled_date'  => self::date_or_null( isset( $data['scheduled_date'] ) ? $data['scheduled_date'] : '' ),
			'source'          => isset( $data['source'] ) ? sanitize_key( $data['source'] ) : 'manual',
			'notes'           => isset( $data['notes'] ) ? sanitize_textarea_field( $data['notes'] ) : '',
			'similarity_note' => isset( $data['similarity_note'] ) ? sanitize_text_field( $data['similarity_note'] ) : self::similarity_warning( $title, isset( $data['keyword'] ) ? $data['keyword'] : '' ),
			'created_at'      => $now,
			'updated_at'      => $now,
		);
		$ok = $wpdb->insert( AIBW_DB::topics(), $row );
		if ( ! $ok ) {
			return new WP_Error( 'aibw_db', __( 'Could not save the topic.', 'ai-blog-writer' ) );
		}
		return (int) $wpdb->insert_id;
	}

	public static function update( $id, $data ) {
		global $wpdb;
		$id   = absint( $id );
		$sets = array( 'updated_at' => current_time( 'mysql' ) );
		$map  = array(
			'title'    => 'sanitize_text_field',
			'keyword'  => 'sanitize_text_field',
			'audience' => 'sanitize_text_field',
			'tags'     => 'sanitize_text_field',
			'notes'    => 'sanitize_textarea_field',
		);
		foreach ( $map as $key => $fn ) {
			if ( isset( $data[ $key ] ) ) {
				$sets[ $key ] = $fn( $data[ $key ] );
			}
		}
		if ( isset( $data['category'] ) ) {
			$sets['category'] = absint( $data['category'] );
		}
		if ( isset( $data['priority'] ) ) {
			$sets['priority'] = (int) $data['priority'];
		}
		if ( isset( $data['status'] ) && in_array( $data['status'], self::STATUSES, true ) ) {
			$sets['status'] = $data['status'];
		}
		if ( array_key_exists( 'scheduled_date', $data ) ) {
			$sets['scheduled_date'] = self::date_or_null( $data['scheduled_date'] );
		}
		if ( isset( $sets['title'] ) ) {
			$sets['similarity_note'] = self::similarity_warning( $sets['title'], isset( $sets['keyword'] ) ? $sets['keyword'] : '' );
		}
		$wpdb->update( AIBW_DB::topics(), $sets, array( 'id' => $id ) );
		return $id;
	}

	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( AIBW_DB::topics(), array( 'id' => absint( $id ) ) );
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . AIBW_DB::topics() . ' WHERE id = %d', absint( $id ) ) );
	}

	public static function list_topics( $args = array() ) {
		global $wpdb;
		$status = isset( $args['status'] ) ? sanitize_key( $args['status'] ) : '';
		$limit  = isset( $args['limit'] ) ? max( 1, min( 200, (int) $args['limit'] ) ) : 50;
		$table  = AIBW_DB::topics();
		if ( $status && in_array( $status, self::STATUSES, true ) ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY priority DESC, id ASC LIMIT %d", $status, $limit ) );
		}
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY FIELD(status,'processing','assigned','pending','suggested','failed','skipped','completed'), priority DESC, id DESC LIMIT %d", $limit ) );
	}

	public static function counts() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT status, COUNT(*) AS c FROM ' . AIBW_DB::topics() . ' GROUP BY status', ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$out[ $row['status'] ] = (int) $row['c'];
		}
		return $out;
	}

	/**
	 * Next topic that is pending and not scheduled in the future.
	 */
	public static function next_pending() {
		global $wpdb;
		$today = current_time( 'Y-m-d' );
		$table = AIBW_DB::topics();
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status = 'pending' AND (scheduled_date IS NULL OR scheduled_date = '0000-00-00' OR scheduled_date <= %s) ORDER BY priority DESC, id ASC LIMIT 1",
				$today
			)
		);
	}

	public static function import_lines( $text ) {
		$lines = preg_split( '/\r\n|\n|\r/', (string) $text );
		$ids   = array();
		$errors = array();
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			$parts = str_getcsv( $line );
			$title = isset( $parts[0] ) ? $parts[0] : '';
			$id    = self::insert(
				array(
					'title'    => $title,
					'keyword'  => isset( $parts[1] ) ? $parts[1] : '',
					'audience' => isset( $parts[2] ) ? $parts[2] : '',
					'source'   => 'import',
				)
			);
			if ( is_wp_error( $id ) ) {
				$errors[] = $id->get_error_message();
			} else {
				$ids[] = $id;
			}
		}
		return array( 'ids' => $ids, 'errors' => $errors );
	}

	/**
	 * Warn when a title looks close to an existing post or topic.
	 * This is a string overlap check, not a guarantee of semantic uniqueness.
	 */
	public static function similarity_warning( $title, $keyword = '' ) {
		$title = strtolower( trim( wp_strip_all_tags( $title ) ) );
		if ( strlen( $title ) < 8 ) {
			return '';
		}
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
				'posts_per_page' => 30,
				's'              => $keyword ? $keyword : implode( ' ', array_slice( explode( ' ', $title ), 0, 3 ) ),
			)
		);
		foreach ( $posts as $post ) {
			$percent = 0;
			similar_text( $title, strtolower( $post->post_title ), $percent );
			if ( $percent >= 72 ) {
				return sprintf(
					/* translators: %s: existing post title */
					__( 'Possible duplicate of “%s”. This check only compares titles and keywords.', 'ai-blog-writer' ),
					$post->post_title
				);
			}
		}
		global $wpdb;
		$existing = $wpdb->get_results( 'SELECT title FROM ' . AIBW_DB::topics() . " WHERE status IN ('pending','completed','processing') ORDER BY id DESC LIMIT 40" );
		foreach ( (array) $existing as $row ) {
			$percent = 0;
			similar_text( $title, strtolower( $row->title ), $percent );
			if ( $percent >= 80 ) {
				return __( 'This looks similar to a topic already in the queue. Overlap is estimated from the title text only.', 'ai-blog-writer' );
			}
		}
		return '';
	}

	private static function date_or_null( $value ) {
		$value = sanitize_text_field( (string) $value );
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			return $value;
		}
		return null;
	}
}
