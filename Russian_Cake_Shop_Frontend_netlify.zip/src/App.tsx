import { useState } from "react";

const products = [
  {
    name: "Медовик",
    english: "Honey layer cake",
    description: "Thin honey layers, cultured sour cream and toasted crumb.",
    price: "$8",
    category: "Cakes",
    image:
      "https://images.unsplash.com/photo-1605138693981-6c8a5ea87796?auto=format&fit=crop&w=900&q=85",
  },
  {
    name: "Манник",
    english: "Semolina cake",
    description: "Golden, tender and gently sweet with orange and vanilla.",
    price: "$6",
    category: "Cakes",
    image:
      "https://images.unsplash.com/photo-1516054237859-4e834cda4ac9?auto=format&fit=crop&w=900&q=85",
  },
  {
    name: "Ватрушка",
    english: "Farmer’s cheese bun",
    description: "Soft brioche filled with sweet tvorog and seasonal berries.",
    price: "$5",
    category: "Pastries",
    image:
      "https://images.unsplash.com/photo-1590695443280-ea42f641b98e?auto=format&fit=crop&w=900&q=85",
  },
  {
    name: "Плюшка",
    english: "Sugar heart bun",
    description: "Buttery layers folded by hand with cinnamon sugar.",
    price: "$4",
    category: "Pastries",
    image:
      "https://images.unsplash.com/photo-1711641076489-ed226d3b9059?auto=format&fit=crop&w=900&q=85",
  },
];

const filters = ["All", "Cakes", "Pastries"];

function OvenMark() {
  return (
    <svg
      aria-hidden="true"
      className="h-11 w-11"
      viewBox="0 0 48 48"
      fill="none"
    >
      <path
        d="M8 22C8 12.6 15.6 5 25 5s17 7.6 17 17v18H8V22Z"
        fill="#9B243E"
      />
      <path d="M13 22c0-6.6 5.4-12 12-12s12 5.4 12 12v13H13V22Z" fill="#F4D7A0" />
      <path d="M19 35V24.5a6 6 0 0 1 12 0V35H19Z" fill="#9B243E" />
      <path d="M24.8 17c-1.8 2.3-2.8 4-2.8 5.2 0 1.7 1.3 2.8 3 2.8s3-1.2 3-3c0-1.4-1-3-3.2-5Z" fill="#F4D7A0" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 20 20" className="h-4 w-4" fill="none">
      <path d="M4 10h12M11 5l5 5-5 5" stroke="currentColor" strokeWidth="1.7" />
    </svg>
  );
}

export default function App() {
  const [activeFilter, setActiveFilter] = useState("All");
  const [cartCount, setCartCount] = useState(0);

  const visibleProducts =
    activeFilter === "All"
      ? products
      : products.filter((product) => product.category === activeFilter);

  return (
    <div className="min-h-screen overflow-hidden bg-[#F8F2E8] text-[#321E19]">
      <div className="bg-[#862038] px-5 py-2 text-center text-[11px] font-semibold uppercase tracking-[0.22em] text-[#FFF9EF]">
        Baked fresh every morning · Local pickup & city delivery
      </div>

      <header className="relative z-20 border-b border-[#321E19]/10 bg-[#F8F2E8]/95">
        <div className="mx-auto flex max-w-[1380px] items-center justify-between px-5 py-4 md:px-10">
          <a href="#" className="flex items-center gap-3" aria-label="Pechka home">
            <OvenMark />
            <div>
              <div className="font-display text-[29px] font-bold leading-[0.8] tracking-tight text-[#862038]">
                Печка
              </div>
              <div className="mt-1.5 text-[8px] font-bold uppercase tracking-[0.28em]">
                Russian bakehouse
              </div>
            </div>
          </a>

          <nav className="hidden items-center gap-8 text-sm font-semibold lg:flex">
            <a className="nav-link" href="#bakes">Our bakes</a>
            <a className="nav-link" href="#story">Our story</a>
            <a className="nav-link" href="#visit">Visit us</a>
          </nav>

          <div className="flex items-center gap-3">
            <button
              className="relative grid h-11 w-11 cursor-pointer place-items-center rounded-full border border-[#321E19]/20 transition hover:border-[#862038] hover:text-[#862038]"
              aria-label={`Shopping bag with ${cartCount} items`}
            >
              <svg aria-hidden="true" viewBox="0 0 24 24" className="h-5 w-5" fill="none">
                <path d="M6.5 8.5h11l1 11h-13l1-11Z" stroke="currentColor" strokeWidth="1.6" />
                <path d="M9 9V7a3 3 0 0 1 6 0v2" stroke="currentColor" strokeWidth="1.6" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-[#862038] px-1 text-[10px] font-bold text-white">
                  {cartCount}
                </span>
              )}
            </button>
            <a className="button-primary hidden sm:flex" href="#bakes">
              Order online
            </a>
          </div>
        </div>
      </header>

      <main>
        <section className="relative mx-auto max-w-[1500px] px-5 pb-14 pt-7 md:px-10 md:pb-24 md:pt-10">
          <div className="grid min-h-[660px] items-center gap-10 lg:grid-cols-[0.88fr_1.12fr]">
            <div className="relative z-10 max-w-[610px] py-8 lg:pl-[5vw]">
              <div className="mb-7 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.24em] text-[#862038]">
                <span className="h-px w-9 bg-[#862038]" />
                Made slowly, shared warmly
              </div>
              <h1 className="font-display text-[64px] font-medium leading-[0.87] tracking-[-0.045em] sm:text-[82px] md:text-[104px]">
                From our
                <br />
                <span className="italic text-[#862038]">печка</span> to
                <br />
                your table.
              </h1>
              <p className="mt-7 max-w-md text-[15px] leading-7 text-[#5D4941] md:text-base">
                Nostalgic Russian cakes and pastries, baked by hand with honey,
                butter and recipes carried across generations.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-5">
                <a className="button-primary" href="#bakes">
                  Explore the bakery <ArrowIcon />
                </a>
                <a className="story-link" href="#story">
                  Meet our bakers
                </a>
              </div>
            </div>

            <div className="relative h-[470px] sm:h-[590px] lg:h-[660px]">
              <div className="absolute inset-x-5 bottom-0 top-0 overflow-hidden rounded-[42%_42%_7rem_7rem] sm:left-12 sm:right-0">
                <img
                  className="h-full w-full object-cover"
                  src="https://images.unsplash.com/photo-1737796348807-e717a904d53e?auto=format&fit=crop&w=1400&q=88"
                  alt="A generous table filled with fresh baked goods"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#321E19]/30 via-transparent to-transparent" />
              </div>
              <div className="absolute bottom-8 left-0 max-w-[220px] rotate-[-3deg] rounded-sm bg-[#FFF9EF] p-5 shadow-[0_18px_50px_rgba(50,30,25,0.16)] sm:bottom-12 sm:left-5">
                <div className="font-display text-2xl font-bold">Today’s batch</div>
                <div className="mt-2 text-xs leading-5 text-[#6C554B]">
                  Warm vatrushki leave the oven at 10:30
                </div>
                <div className="mt-3 h-px bg-[#321E19]/10" />
                <div className="mt-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[#862038]">
                  While they last
                </div>
              </div>
              <div className="absolute right-0 top-12 grid h-24 w-24 rotate-6 place-items-center rounded-full border border-[#F8F2E8]/60 bg-[#862038] text-center text-[9px] font-bold uppercase leading-4 tracking-[0.16em] text-white shadow-xl sm:right-[-20px] sm:h-28 sm:w-28">
                <span>честно<br />и вкусно<br />· bakery ·</span>
              </div>
            </div>
          </div>
        </section>

        <section id="bakes" className="bg-[#EFE3D2] px-5 py-20 md:px-10 md:py-28">
          <div className="mx-auto max-w-[1280px]">
            <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
              <div>
                <div className="eyebrow">From the display</div>
                <h2 className="section-title mt-4">Beloved bakes</h2>
              </div>
              <div className="flex flex-wrap gap-2" aria-label="Filter products">
                {filters.map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setActiveFilter(filter)}
                    className={`cursor-pointer rounded-full px-5 py-2.5 text-xs font-bold transition ${
                      activeFilter === filter
                        ? "bg-[#862038] text-white"
                        : "border border-[#321E19]/20 hover:border-[#862038] hover:text-[#862038]"
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {visibleProducts.map((product) => (
                <article key={product.name} className="group">
                  <div className="relative aspect-[4/5] overflow-hidden rounded-t-[8rem] bg-[#DDC9AE]">
                    <img
                      className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                      src={product.image}
                      alt={`${product.name}, ${product.english}`}
                    />
                    <button
                      onClick={() => setCartCount((count) => count + 1)}
                      className="absolute bottom-4 right-4 grid h-12 w-12 cursor-pointer place-items-center rounded-full bg-[#FFF9EF] text-xl shadow-lg transition hover:rotate-90 hover:bg-[#862038] hover:text-white"
                      aria-label={`Add ${product.name} to bag`}
                    >
                      +
                    </button>
                  </div>
                  <div className="pt-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-display text-[30px] font-bold leading-none">{product.name}</h3>
                        <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[#862038]">
                          {product.english}
                        </p>
                      </div>
                      <span className="font-display text-xl font-bold">{product.price}</span>
                    </div>
                    <p className="mt-3 text-sm leading-6 text-[#6A554C]">{product.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="story" className="px-5 py-20 md:px-10 md:py-28">
          <div className="mx-auto grid max-w-[1280px] items-center gap-12 lg:grid-cols-2 lg:gap-24">
            <div className="relative">
              <div className="overflow-hidden rounded-[2rem_9rem_2rem_2rem]">
                <img
                  src="https://images.unsplash.com/photo-1749996089724-268703b8c4dc?auto=format&fit=crop&w=1000&q=85"
                  alt="Warm and welcoming bakery interior"
                  className="h-[500px] w-full object-cover sm:h-[620px]"
                />
              </div>
              <div className="absolute -bottom-6 -right-3 rounded-full bg-[#F0B84B] px-7 py-9 text-center shadow-xl md:right-[-35px]">
                <div className="font-display text-3xl font-bold">2018</div>
                <div className="text-[9px] font-bold uppercase tracking-[0.18em]">First oven lit</div>
              </div>
            </div>
            <div className="lg:max-w-lg">
              <div className="eyebrow">The Pechka way</div>
              <h2 className="section-title mt-4">
                A little oven with a <span className="italic text-[#862038]">big heart.</span>
              </h2>
              <p className="mt-7 text-base leading-8 text-[#5D4941]">
                “Печка” means the warm stove at the heart of a traditional Russian
                home — where bread rose, tea brewed and everyone gathered.
              </p>
              <p className="mt-4 text-base leading-8 text-[#5D4941]">
                We give those familiar recipes a fresh life, using local dairy,
                fragrant honey and plenty of time. No shortcuts, no unnecessary
                fuss. Just baking that feels like coming home.
              </p>
              <div className="mt-9 grid grid-cols-3 gap-3 border-y border-[#321E19]/15 py-6">
                <div><strong className="stat">100%</strong><span className="stat-label">Handmade</span></div>
                <div><strong className="stat">Local</strong><span className="stat-label">Ingredients</span></div>
                <div><strong className="stat">Daily</strong><span className="stat-label">Fresh batches</span></div>
              </div>
            </div>
          </div>
        </section>

        <section id="visit" className="bg-[#862038] px-5 py-16 text-[#FFF9EF] md:px-10">
          <div className="mx-auto flex max-w-[1280px] flex-col justify-between gap-10 md:flex-row md:items-center">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.24em] text-[#F0B84B]">Come by for something warm</div>
              <h2 className="font-display mt-3 text-5xl font-medium md:text-6xl">Your table is waiting.</h2>
            </div>
            <div className="flex flex-col gap-2 text-sm leading-6 md:text-right">
              <span>42 Birch Street, Brooklyn</span>
              <span>Tue–Sun · 8am–6pm</span>
              <a href="tel:+17185550189" className="font-bold underline decoration-[#F0B84B] underline-offset-4">(718) 555-0189</a>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#271713] px-5 py-8 text-[#FFF9EF]/70 md:px-10">
        <div className="mx-auto flex max-w-[1280px] flex-col gap-4 text-xs sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 text-[#FFF9EF]"><OvenMark /><span className="font-display text-2xl font-bold">Печка</span></div>
          <p>Russian recipes, baked with love.</p>
          <p>© 2025 Pechka Bakehouse</p>
        </div>
      </footer>
    </div>
  );
}
