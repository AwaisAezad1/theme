import maxmind, { type Reader } from 'maxmind';
import {
  emptyRecord,
  hasData,
  type GeoProvider,
  type GeoRecord,
  type ProviderInfo,
  type ProviderResult,
} from './types.js';
import {
  PROBE_IPS,
  asnNumber,
  continentName,
  countryName,
  fileSignature,
  latitude,
  longitude,
  plausibleDate,
  text,
} from './util.js';

type Logger = { info: (m: string) => void; warn: (m: string) => void; error: (m: string) => void };
type Json = Record<string, unknown>;

function obj(v: unknown): Json | null {
  return v && typeof v === 'object' && !Array.isArray(v) ? (v as Json) : null;
}

/** First non-null of several candidate values. */
function first<T>(...values: Array<T | null | undefined>): T | null {
  for (const v of values) if (v !== null && v !== undefined) return v;
  return null;
}

/**
 * Map any IPinfo record onto GeoRecord. Handles:
 *  - IPinfo Lite (database and API):  country_code, country, continent_code, continent, asn "AS15169", as_name, as_domain
 *  - Classic / paid location data:    city, region, country (ISO code), loc "lat,lon", postal, timezone, org "AS15169 Name"
 *  - Nested "geo" / "as" objects used by newer IPinfo products.
 */
export function normalizeIpinfo(raw: unknown): GeoRecord {
  const r = obj(raw);
  const out = emptyRecord();
  if (!r) return out;

  const geo = obj(r.geo);
  const as = obj(r.as);

  // Country: Lite uses country_code + country (name); classic data uses country (ISO code).
  const isoCode = (c: string | null) => c !== null && /^[A-Za-z]{2}$/.test(c);
  const codeCandidates = [r.country_code, geo?.country_code, geo?.country, r.country].map(text);
  const code = codeCandidates.find(isoCode)?.toUpperCase() ?? null;
  const name = [geo?.country, r.country].map(text).find((c) => c !== null && !isoCode(c)) ?? null;
  out.country_code = code;
  out.country = name ?? countryName(code);

  out.continent_code = text(first(r.continent_code, geo?.continent_code))?.toUpperCase() ?? null;
  const rawContinent = text(first(r.continent, geo?.continent));
  out.continent = rawContinent && rawContinent.length > 2 ? rawContinent : continentName(out.continent_code);

  out.region = text(first(r.region, geo?.region));
  out.city = text(first(r.city, geo?.city));
  out.postal_code = text(first(r.postal, r.postal_code, geo?.postal_code, geo?.postal));
  out.timezone = text(first(r.timezone, geo?.timezone));

  // Coordinates: "lat,lon" string or separate numbers.
  const loc = text(r.loc);
  if (loc && loc.includes(',')) {
    const [la, lo] = loc.split(',');
    out.latitude = latitude(la);
    out.longitude = longitude(lo);
  } else {
    out.latitude = latitude(first(r.latitude, geo?.latitude));
    out.longitude = longitude(first(r.longitude, geo?.longitude));
  }
  if (out.latitude === null || out.longitude === null) {
    out.latitude = null;
    out.longitude = null;
  }

  // Network.
  const org = text(r.org);
  const orgMatch = org ? /^(AS\d+)\s+(.*)$/i.exec(org) : null;
  out.asn = asnNumber(first(r.asn, as?.asn, orgMatch?.[1] ?? null));
  out.organization = text(first(r.as_name, as?.name, orgMatch ? orgMatch[2] : org));
  out.domain = text(first(r.as_domain, as?.domain));
  return out;
}

const CACHE_TTL_MS = 60 * 60 * 1000;
const CACHE_MAX = 5000;
const API_TIMEOUT_MS = 2500;

export class IpinfoProvider implements GeoProvider {
  readonly id = 'ipinfo' as const;
  readonly name = 'IPinfo';
  private reader: Reader<Json> | null = null;
  private signature: string | null = null;
  private warning: string | null = null;
  private cache = new Map<string, { at: number; record: GeoRecord }>();

  constructor(
    private dbPath: string,
    private api: { token: string | null; url: string },
    private log: Logger,
  ) {}

  private get mode(): 'database' | 'api' | 'none' {
    if (this.reader) return 'database';
    if (this.api.token) return 'api';
    return 'none';
  }

  private async open(): Promise<boolean> {
    const signature = await fileSignature(this.dbPath);
    if (signature === null || signature === this.signature) return false;
    try {
      this.reader = await maxmind.open<Json>(this.dbPath);
      this.signature = signature;
      this.log.info(`IPinfo database loaded (${this.dbPath})`);
      return true;
    } catch (err) {
      this.log.error(`IPinfo database could not be opened: ${err instanceof Error ? err.message : err}`);
      return false;
    }
  }

  async init(): Promise<void> {
    await this.open();
    this.selfTest();
    if (!this.reader && this.api.token) this.log.info('IPinfo: using the web API (no local database found).');
  }

  async reloadIfChanged(): Promise<boolean> {
    const changed = await this.open();
    if (changed) this.selfTest();
    return changed;
  }

  private selfTest(): void {
    this.warning = null;
    if (!this.reader) return;
    const resolved = PROBE_IPS.some((ip) => {
      try {
        return this.reader!.get(ip) !== null;
      } catch {
        return false;
      }
    });
    if (!resolved) {
      this.warning = 'The IPinfo database loaded but could not resolve common test addresses.';
      this.log.warn(`IPinfo: ${this.warning}`);
    }
  }

  async lookup(ip: string): Promise<ProviderResult> {
    try {
      if (this.reader) {
        const record = normalizeIpinfo(this.reader.get(ip));
        return hasData(record) ? { status: 'ok', data: record } : { status: 'no_data', data: null };
      }
      if (this.api.token) return await this.lookupApi(ip);
      return { status: 'unavailable', data: null, message: 'IPinfo database is not installed.' };
    } catch (err) {
      return { status: 'error', data: null, message: err instanceof Error ? err.message : 'Lookup failed.' };
    }
  }

  private async lookupApi(ip: string): Promise<ProviderResult> {
    const cached = this.cache.get(ip);
    if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
      return { status: 'ok', data: cached.record };
    }

    const url = new URL(this.api.url.replace('{ip}', encodeURIComponent(ip)));
    url.searchParams.set('token', this.api.token!);

    let res: Response;
    try {
      res = await fetch(url, {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(API_TIMEOUT_MS),
      });
    } catch (err) {
      const timedOut = err instanceof Error && (err.name === 'TimeoutError' || err.name === 'AbortError');
      return { status: 'error', data: null, message: timedOut ? 'IPinfo API timed out.' : 'IPinfo API is unreachable.' };
    }

    if (res.status === 404) return { status: 'no_data', data: null };
    if (res.status === 429) return { status: 'error', data: null, message: 'IPinfo API rate limit reached.' };
    if (res.status === 401 || res.status === 403) {
      return { status: 'error', data: null, message: 'IPinfo API rejected the token.' };
    }
    if (!res.ok) return { status: 'error', data: null, message: `IPinfo API returned HTTP ${res.status}.` };

    const record = normalizeIpinfo(await res.json());
    if (!hasData(record)) return { status: 'no_data', data: null };

    if (this.cache.size >= CACHE_MAX) {
      const oldest = this.cache.keys().next().value;
      if (oldest !== undefined) this.cache.delete(oldest);
    }
    this.cache.set(ip, { at: Date.now(), record });
    return { status: 'ok', data: record };
  }

  info(): ProviderInfo {
    const mode = this.mode;
    const type = this.reader?.metadata.databaseType ?? '';
    const looksLite =
      mode === 'database' ? /lite|country|asn/i.test(type) : mode === 'api' && /\/lite\//i.test(this.api.url);
    return {
      id: this.id,
      name: this.name,
      source:
        mode === 'database'
          ? 'IPinfo database (local)'
          : mode === 'api'
            ? 'IPinfo API'
            : 'IPinfo (not installed)',
      loaded: mode !== 'none',
      database_date: mode === 'database' ? plausibleDate(this.reader?.metadata.buildEpoch) : null,
      note: looksLite ? 'IPinfo Lite covers country and network (ASN) data only; city-level data needs a paid IPinfo plan.' : null,
      warning: this.warning,
    };
  }

  close(): void {
    this.reader = null;
    this.cache.clear();
  }
}
