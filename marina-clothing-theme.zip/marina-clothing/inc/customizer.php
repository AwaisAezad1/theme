<?php
/**
 * Customizer: editable copy & imagery for the Marina design.
 *
 * Appearance → Customize → "Marina Theme".
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Default values for every option.
 */
function marina_option_defaults() {
    return array(
        // Header.
        'topbar_left'         => __( 'Thoughtfully Designed • Made to Last', 'marina-clothing' ),
        'announcement'        => __( 'Free shipping on orders over $200', 'marina-clothing' ),
        'brand_tagline'       => __( 'Wardrobe Essentials', 'marina-clothing' ),

        // Home: hero.
        'hero_eyebrow'        => __( 'The New Season Collection', 'marina-clothing' ),
        'hero_title'          => __( 'Effortless Style &', 'marina-clothing' ),
        'hero_title_accent'   => __( 'Timeless', 'marina-clothing' ),
        'hero_title_end'      => __( 'Essentials', 'marina-clothing' ),
        'hero_text'           => __( 'Discover our latest collection of thoughtfully designed pieces: tailored separates, easy dresses and everyday essentials made for the way you live.', 'marina-clothing' ),
        'hero_image'          => '',
        'hero_btn1_label'     => __( 'Explore The Collection', 'marina-clothing' ),
        'hero_btn1_url'       => '',
        'hero_btn2_label'     => __( 'Shop Trending', 'marina-clothing' ),
        'hero_btn2_url'       => '#trending',
        'hero_badges'         => __( "Premium Fabrics\nLimited Runs\nThoughtful Tailoring", 'marina-clothing' ),

        // Home: spotlight.
        'spotlight_product'   => 0,
        'spotlight_points'    => __( "Premium natural fabrics\nPre-washed for a soft feel\nFinished with care\nEasy to look after", 'marina-clothing' ),

        // Home: manifesto.
        'manifesto_url'       => '',
        'manifesto_image'     => '',

        // Newsletter.
        'newsletter_title'    => __( 'Join The Marina Circle', 'marina-clothing' ),
        'newsletter_text'     => __( 'Be the first to hear about new arrivals, exclusive offers and members-only previews.', 'marina-clothing' ),

        // Product page.
        'product_note_title'  => __( 'Made With Care', 'marina-clothing' ),
        'product_note_text'   => __( 'Every piece is carefully finished and quality-checked before it ships, so it looks and feels right from the very first wear.', 'marina-clothing' ),
        'shipping_text'       => __( "Orders are carefully packed and dispatched within 1–2 business days.\nDomestic orders usually arrive in 2–3 business days. Returns are accepted within 30 days of receipt.", 'marina-clothing' ),

        // Footer.
        'footer_about'        => __( 'Thoughtfully designed clothing and accessories made to last. Quality fabrics, considered details and timeless style for every day.', 'marina-clothing' ),
        'footer_locations'    => __( 'Quality • Comfort • Style', 'marina-clothing' ),
    );
}

/**
 * Get a theme option (falls back to its default).
 */
function marina_opt( $key ) {
    $defaults = marina_option_defaults();
    $default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';

    return get_theme_mod( 'marina_' . $key, $default );
}

/**
 * Multi-line option → array of trimmed lines.
 */
function marina_opt_lines( $key ) {
    return array_values( array_filter( array_map( 'trim', explode( "\n", (string) marina_opt( $key ) ) ) ) );
}

/**
 * Register Customizer panel.
 */
function marina_customize_register( $wp_customize ) {
    $wp_customize->add_panel(
        'marina_panel',
        array(
            'title'    => __( 'Marina Theme', 'marina-clothing' ),
            'priority' => 30,
        )
    );

    $sections = array(
        'marina_header'   => __( 'Header & Announcement', 'marina-clothing' ),
        'marina_hero'     => __( 'Home: Hero', 'marina-clothing' ),
        'marina_home'     => __( 'Home: Spotlight & Story', 'marina-clothing' ),
        'marina_product'  => __( 'Product Page', 'marina-clothing' ),
        'marina_footer'   => __( 'Footer & Newsletter', 'marina-clothing' ),
    );

    foreach ( $sections as $id => $title ) {
        $wp_customize->add_section(
            $id,
            array(
                'title' => $title,
                'panel' => 'marina_panel',
            )
        );
    }

    // key => array( section, label, type ).
    $fields = array(
        'topbar_left'        => array( 'marina_header', __( 'Top bar (left)', 'marina-clothing' ), 'text' ),
        'announcement'       => array( 'marina_header', __( 'Announcement (centre)', 'marina-clothing' ), 'text' ),
        'brand_tagline'      => array( 'marina_header', __( 'Line under the logo', 'marina-clothing' ), 'text' ),

        'hero_eyebrow'       => array( 'marina_hero', __( 'Eyebrow', 'marina-clothing' ), 'text' ),
        'hero_title'         => array( 'marina_hero', __( 'Title (line 1)', 'marina-clothing' ), 'text' ),
        'hero_title_accent'  => array( 'marina_hero', __( 'Title italic accent', 'marina-clothing' ), 'text' ),
        'hero_title_end'     => array( 'marina_hero', __( 'Title ending', 'marina-clothing' ), 'text' ),
        'hero_text'          => array( 'marina_hero', __( 'Text', 'marina-clothing' ), 'textarea' ),
        'hero_image'         => array( 'marina_hero', __( 'Background image', 'marina-clothing' ), 'image' ),
        'hero_btn1_label'    => array( 'marina_hero', __( 'Primary button label', 'marina-clothing' ), 'text' ),
        'hero_btn1_url'      => array( 'marina_hero', __( 'Primary button URL (empty = shop)', 'marina-clothing' ), 'url' ),
        'hero_btn2_label'    => array( 'marina_hero', __( 'Secondary button label', 'marina-clothing' ), 'text' ),
        'hero_btn2_url'      => array( 'marina_hero', __( 'Secondary button URL', 'marina-clothing' ), 'text' ),
        'hero_badges'        => array( 'marina_hero', __( 'Badges (one per line)', 'marina-clothing' ), 'textarea' ),

        'spotlight_product'  => array( 'marina_home', __( 'Spotlight product ID (0 = first featured product)', 'marina-clothing' ), 'number' ),
        'spotlight_points'   => array( 'marina_home', __( 'Spotlight checklist (one per line)', 'marina-clothing' ), 'textarea' ),
        'manifesto_url'      => array( 'marina_home', __( 'Manifesto "Read more" URL', 'marina-clothing' ), 'url' ),
        'manifesto_image'    => array( 'marina_home', __( 'Manifesto image', 'marina-clothing' ), 'image' ),

        'product_note_title' => array( 'marina_product', __( 'Craft note title (below gallery)', 'marina-clothing' ), 'text' ),
        'product_note_text'  => array( 'marina_product', __( 'Craft note text (empty hides it)', 'marina-clothing' ), 'textarea' ),
        'shipping_text'      => array( 'marina_product', __( 'Delivery & returns accordion text', 'marina-clothing' ), 'textarea' ),

        'newsletter_title'   => array( 'marina_footer', __( 'Newsletter title', 'marina-clothing' ), 'text' ),
        'newsletter_text'    => array( 'marina_footer', __( 'Newsletter text', 'marina-clothing' ), 'textarea' ),
        'footer_about'       => array( 'marina_footer', __( 'Footer about text', 'marina-clothing' ), 'textarea' ),
        'footer_locations'   => array( 'marina_footer', __( 'Footer locations line', 'marina-clothing' ), 'text' ),
    );

    $defaults = marina_option_defaults();

    foreach ( $fields as $key => $field ) {
        list( $section, $label, $type ) = $field;

        switch ( $type ) {
            case 'textarea':
                $sanitize = 'sanitize_textarea_field';
                break;
            case 'url':
            case 'image':
                $sanitize = 'esc_url_raw';
                break;
            case 'number':
                $sanitize = 'absint';
                break;
            default:
                $sanitize = 'sanitize_text_field';
        }

        $wp_customize->add_setting(
            'marina_' . $key,
            array(
                'default'           => $defaults[ $key ],
                'sanitize_callback' => $sanitize,
            )
        );

        if ( 'image' === $type ) {
            $wp_customize->add_control(
                new WP_Customize_Image_Control(
                    $wp_customize,
                    'marina_' . $key,
                    array(
                        'label'   => $label,
                        'section' => $section,
                    )
                )
            );
        } else {
            $wp_customize->add_control(
                'marina_' . $key,
                array(
                    'label'   => $label,
                    'section' => $section,
                    'type'    => $type,
                )
            );
        }
    }
}
add_action( 'customize_register', 'marina_customize_register' );
