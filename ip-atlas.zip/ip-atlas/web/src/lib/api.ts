import type { LookupResponse, StatusResponse } from '../types';

export class ApiClientError extends Error {
  constructor(
    message: string,
    public code: string,
    public status: number,
  ) {
    super(message);
    this.name = 'ApiClientError';
  }
}

const REQUEST_TIMEOUT_MS = 15_000;

async function request<T>(path: string, signal?: AbortSignal): Promise<T> {
  // Own timeout (AbortSignal.any / AbortSignal.timeout are missing in some older browsers).
  const ctl = new AbortController();
  let timedOut = false;
  const onAbort = () => ctl.abort();
  if (signal?.aborted) ctl.abort();
  signal?.addEventListener('abort', onAbort, { once: true });
  const timer = setTimeout(() => {
    timedOut = true;
    ctl.abort();
  }, REQUEST_TIMEOUT_MS);

  try {
    let res: Response;
    try {
      res = await fetch(path, { headers: { Accept: 'application/json' }, signal: ctl.signal });
    } catch (err) {
      if (timedOut) throw new ApiClientError('The request timed out. Please try again.', 'timeout', 0);
      if (err instanceof DOMException && err.name === 'AbortError') throw err;
      throw new ApiClientError('Could not reach the server. Check your connection and try again.', 'network_error', 0);
    }

    let body: unknown = null;
    try {
      body = await res.json();
    } catch {
      if (timedOut) throw new ApiClientError('The request timed out. Please try again.', 'timeout', 0);
      // Non-JSON response (for example an HTML error page from a proxy).
    }

    if (!res.ok) {
      const err = (body as { error?: { code?: string; message?: string } } | null)?.error;
      if (err?.message) throw new ApiClientError(err.message, err.code ?? 'error', res.status);
      if (res.status === 429) {
        throw new ApiClientError('Too many requests. Please wait a moment and try again.', 'rate_limited', 429);
      }
      throw new ApiClientError('The service is temporarily unavailable. Please try again shortly.', 'server_error', res.status);
    }
    if (body === null) throw new ApiClientError('The server sent an unexpected response.', 'bad_response', res.status);
    return body as T;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', onAbort);
  }
}

/** Look up an IP address, or the caller's own address when `ip` is empty. */
export function lookupIp(ip: string, signal?: AbortSignal): Promise<LookupResponse> {
  const target = ip.trim();
  return request<LookupResponse>(target ? `/api/v1/ip/${encodeURIComponent(target)}` : '/api/v1/ip', signal);
}

export function fetchStatus(signal?: AbortSignal): Promise<StatusResponse> {
  return request<StatusResponse>('/api/v1/status', signal);
}
