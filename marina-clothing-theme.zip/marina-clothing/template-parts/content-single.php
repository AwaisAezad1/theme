<?php
/**
 * Single post content.
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post-article' ); ?>>
    <header class="article-hero">
        <div class="container container--narrow">
            <?php marina_breadcrumb(); ?>
            <?php marina_post_meta(); ?>
            <?php the_title( '<h1 class="article-hero__title">', '</h1>' ); ?>
            <?php if ( has_excerpt() ) : ?>
                <p class="article-hero__lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
            <?php endif; ?>
            <div class="article-hero__author">
                <?php echo get_avatar( get_the_author_meta( 'ID' ), 40 ); ?>
                <span>
                    <?php
                    /* translators: %s: author */
                    printf( esc_html__( 'By %s', 'marina-clothing' ), '<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>' );
                    ?>
                </span>
            </div>
        </div>
    </header>

    <?php if ( has_post_thumbnail() ) : ?>
        <figure class="container article-cover">
            <?php the_post_thumbnail( 'full' ); ?>
        </figure>
    <?php endif; ?>

    <div class="container container--prose entry-content">
        <?php
        the_content();

        wp_link_pages(
            array(
                'before' => '<nav class="page-links">' . esc_html__( 'Pages:', 'marina-clothing' ),
                'after'  => '</nav>',
            )
        );
        ?>
    </div>

    <footer class="container container--prose article-foot">
        <?php
        $marina_tags = get_the_tag_list( '<div class="chip-row">', '', '</div>' );
        if ( $marina_tags ) {
            echo wp_kses_post( str_replace( 'rel="tag"', 'rel="tag" class="chip"', $marina_tags ) );
        }

        the_post_navigation(
            array(
                'prev_text' => '<span class="post-nav__label">' . marina_icon( 'arrow_back' ) . esc_html__( 'Previous story', 'marina-clothing' ) . '</span><span class="post-nav__title">%title</span>',
                'next_text' => '<span class="post-nav__label">' . esc_html__( 'Next story', 'marina-clothing' ) . marina_icon( 'arrow_forward' ) . '</span><span class="post-nav__title">%title</span>',
            )
        );
        ?>
    </footer>

    <?php if ( comments_open() || get_comments_number() ) : ?>
        <div class="container container--prose">
            <?php comments_template(); ?>
        </div>
    <?php endif; ?>
</article>
