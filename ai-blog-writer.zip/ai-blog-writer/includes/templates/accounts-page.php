<?php
/**
 * "AI Accounts" page - connect each AI with the person's own account.
 *
 * Variables: $settings, $providers, $img_sources, $msg
 */
defined( 'ABSPATH' ) || exit;
?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'AI Accounts', 'ai-blog-writer' ); ?></h1>

	<?php if ( $msg ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div>
	<?php endif; ?>

	<div class="aibw-card">
		<h2><?php esc_html_e( 'How to connect an AI (3 steps)', 'ai-blog-writer' ); ?></h2>
		<ol class="aibw-steps">
			<li><?php esc_html_e( 'Click "Sign up" to create an account, or "Log in" if you already have one - including a paid plan.', 'ai-blog-writer' ); ?></li>
			<li><?php esc_html_e( 'Click "Get API key" and copy the key (a long line of letters and numbers).', 'ai-blog-writer' ); ?></li>
			<li><?php esc_html_e( 'Paste it into the box below, press "Test connection", then "Save".', 'ai-blog-writer' ); ?></li>
		</ol>
		<p class="description"><?php esc_html_e( 'Why a key and not a username and password? AI companies do not let websites sign in with your normal chat login. The key links this plugin to your account, so your plan, credits and limits apply. Chat subscriptions (such as ChatGPT Plus or Claude Pro) are usually billed separately from API usage - check your account\'s billing page. Your keys are stored encrypted and are never shown in the browser.', 'ai-blog-writer' ); ?></p>
	</div>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="aibw_save_accounts">
		<?php wp_nonce_field( 'aibw_save_accounts' ); ?>

		<div class="aibw-card">
			<h2><?php esc_html_e( 'Which AI should be used by default?', 'ai-blog-writer' ); ?></h2>
			<p>
				<select name="default_provider">
					<?php foreach ( $providers as $id => $p ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $settings['default_provider'], $id ); ?>><?php echo esc_html( $p['label'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<p>
				<label>
					<input type="checkbox" name="fallback" value="1" <?php checked( ! empty( $settings['fallback'] ) ); ?>>
					<?php esc_html_e( 'If a paid AI fails (for example you ran out of credit), automatically use the free Groq AI instead.', 'ai-blog-writer' ); ?>
				</label>
			</p>
		</div>

		<div class="aibw-account-grid">
			<?php foreach ( $providers as $id => $p ) :
				$connected = AIBW_Settings::has_key( $id );
				$hint      = AIBW_Settings::key_hint( $id );
				$model     = isset( $settings['models'][ $id ] ) ? $settings['models'][ $id ] : '';
				?>
				<div class="aibw-card aibw-account" data-provider="<?php echo esc_attr( $id ); ?>">
					<h2>
						<?php echo esc_html( $p['label'] ); ?>
						<?php if ( $connected ) : ?>
							<span class="aibw-badge aibw-badge-ok"><?php esc_html_e( 'Connected', 'ai-blog-writer' ); ?> <?php echo esc_html( $hint ); ?></span>
						<?php else : ?>
							<span class="aibw-badge aibw-badge-off"><?php esc_html_e( 'Not connected', 'ai-blog-writer' ); ?></span>
						<?php endif; ?>
					</h2>
					<p class="description"><?php echo esc_html( $p['blurb'] ); ?></p>
					<p class="aibw-links">
						<a class="button" href="<?php echo esc_url( $p['signup'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Sign up', 'ai-blog-writer' ); ?></a>
						<a class="button" href="<?php echo esc_url( $p['login'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Log in', 'ai-blog-writer' ); ?></a>
						<a class="button" href="<?php echo esc_url( $p['keys_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Get API key', 'ai-blog-writer' ); ?></a>
					</p>

					<p>
						<label for="aibw-key-<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'API key', 'ai-blog-writer' ); ?></label>
						<input type="password" id="aibw-key-<?php echo esc_attr( $id ); ?>" name="key[<?php echo esc_attr( $id ); ?>]" autocomplete="off" spellcheck="false"
							placeholder="<?php echo $connected ? esc_attr__( 'Saved - paste a new key to replace it', 'ai-blog-writer' ) : esc_attr__( 'Paste your API key here', 'ai-blog-writer' ); ?>">
					</p>
					<p>
						<label for="aibw-model-<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Model (optional)', 'ai-blog-writer' ); ?></label>
						<input type="text" id="aibw-model-<?php echo esc_attr( $id ); ?>" name="model[<?php echo esc_attr( $id ); ?>]" list="aibw-models-<?php echo esc_attr( $id ); ?>"
							value="<?php echo esc_attr( $model ); ?>" placeholder="<?php echo esc_attr( $p['default_model'] ); ?>" autocomplete="off">
						<datalist id="aibw-models-<?php echo esc_attr( $id ); ?>"></datalist>
						<span class="description"><?php esc_html_e( 'Leave empty to use the recommended model. After a successful test, a list of your available models appears here.', 'ai-blog-writer' ); ?></span>
					</p>
					<p class="aibw-actions">
						<button type="button" class="button aibw-test"><?php esc_html_e( 'Test connection', 'ai-blog-writer' ); ?></button>
						<span class="spinner"></span>
						<span class="aibw-test-result" role="status" aria-live="polite"></span>
					</p>
					<?php if ( $connected ) : ?>
						<p><label class="aibw-remove"><input type="checkbox" name="clear[<?php echo esc_attr( $id ); ?>]" value="1"> <?php esc_html_e( 'Remove the saved key when I press Save', 'ai-blog-writer' ); ?></label></p>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="aibw-card" id="aibw-images">
			<h2><?php esc_html_e( 'Pictures for your blogs (free)', 'ai-blog-writer' ); ?></h2>
			<p class="description"><?php esc_html_e( 'The AI chooses what each picture should show, and real photos are found on a free stock-photo site. When you add a blog, the photos are copied into your Media Library, the cover becomes the featured image, and the photographer is credited under each picture. The AI never makes up image links, so nothing breaks.', 'ai-blog-writer' ); ?></p>
			<p>
				<label for="aibw-image-source"><?php esc_html_e( 'Use photos from', 'ai-blog-writer' ); ?></label>
				<select name="image_source" id="aibw-image-source">
					<?php foreach ( $img_sources as $sid => $src ) : ?>
						<option value="<?php echo esc_attr( $sid ); ?>" <?php selected( AIBW_Images::current_source(), $sid ); ?>><?php echo esc_html( $src['label'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<div class="aibw-account-grid">
				<?php foreach ( $img_sources as $sid => $src ) :
					$img_connected = '' !== AIBW_Images::get_key( $sid );
					?>
					<div class="aibw-card aibw-imgsrc" data-source="<?php echo esc_attr( $sid ); ?>">
						<h2>
							<?php echo esc_html( $src['label'] ); ?>
							<?php if ( $img_connected ) : ?>
								<span class="aibw-badge aibw-badge-ok"><?php esc_html_e( 'Connected', 'ai-blog-writer' ); ?> <?php echo esc_html( AIBW_Images::key_hint( $sid ) ); ?></span>
							<?php else : ?>
								<span class="aibw-badge aibw-badge-off"><?php esc_html_e( 'Not connected', 'ai-blog-writer' ); ?></span>
							<?php endif; ?>
						</h2>
						<p class="description"><?php echo esc_html( $src['blurb'] ); ?></p>
						<p class="aibw-links">
							<a class="button" href="<?php echo esc_url( $src['signup'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Sign up', 'ai-blog-writer' ); ?></a>
							<a class="button" href="<?php echo esc_url( $src['keys_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Get API key', 'ai-blog-writer' ); ?></a>
						</p>
						<p>
							<label for="aibw-imgkey-<?php echo esc_attr( $sid ); ?>"><?php esc_html_e( 'API key', 'ai-blog-writer' ); ?></label>
							<input type="password" id="aibw-imgkey-<?php echo esc_attr( $sid ); ?>" name="img_key[<?php echo esc_attr( $sid ); ?>]" autocomplete="off" spellcheck="false"
								placeholder="<?php echo $img_connected ? esc_attr__( 'Saved - paste a new key to replace it', 'ai-blog-writer' ) : esc_attr__( 'Paste your API key here', 'ai-blog-writer' ); ?>">
						</p>
						<p class="aibw-actions">
							<button type="button" class="button aibw-test"><?php esc_html_e( 'Test connection', 'ai-blog-writer' ); ?></button>
							<span class="spinner"></span>
							<span class="aibw-test-result" role="status" aria-live="polite"></span>
						</p>
						<?php if ( $img_connected ) : ?>
							<p><label class="aibw-remove"><input type="checkbox" name="img_clear[<?php echo esc_attr( $sid ); ?>]" value="1"> <?php esc_html_e( 'Remove the saved key when I press Save', 'ai-blog-writer' ); ?></label></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<?php submit_button( __( 'Save', 'ai-blog-writer' ) ); ?>
	</form>

	<div class="aibw-card">
		<h2><?php esc_html_e( 'External services used', 'ai-blog-writer' ); ?></h2>
		<p><?php esc_html_e( 'When you press "Generate Blog", the topic and your writing options are sent to the AI you chose, together with your API key. Nothing is sent to the plugin authors. See each provider\'s privacy policy:', 'ai-blog-writer' ); ?></p>
		<ul>
			<?php foreach ( $providers as $p ) : ?>
				<li><a href="<?php echo esc_url( $p['privacy'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $p['short'] ); ?></a></li>
			<?php endforeach; ?>
			<?php foreach ( $img_sources as $src ) : ?>
				<li><a href="<?php echo esc_url( $src['privacy'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $src['short'] ); ?></a> <?php esc_html_e( '(pictures: only the short search words and your key are sent)', 'ai-blog-writer' ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>
