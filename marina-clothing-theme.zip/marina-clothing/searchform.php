<?php
/**
 * Search form.
 */

$marina_id = 'search-' . wp_unique_id();
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <label class="screen-reader-text" for="<?php echo esc_attr( $marina_id ); ?>"><?php esc_html_e( 'Search for:', 'marina-clothing' ); ?></label>
    <?php marina_the_icon( 'search' ); ?>
    <input type="search" id="<?php echo esc_attr( $marina_id ); ?>" class="search-field" placeholder="<?php esc_attr_e( 'Search garments, journal, pages…', 'marina-clothing' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" name="s">
    <button type="submit" class="btn btn--primary btn--sm"><?php esc_html_e( 'Search', 'marina-clothing' ); ?></button>
</form>
