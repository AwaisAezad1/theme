<?php
/**
 * 404.
 */

get_header();
?>

<main id="primary" class="site-main">
    <section class="notfound">
        <div class="notfound__media" aria-hidden="true">
            <img src="<?php echo esc_url( marina_image( 'not-found' ) ); ?>" alt="">
        </div>
        <div class="container notfound__inner">
            <span class="eyebrow eyebrow--rule"><?php esc_html_e( 'Error 404 • Page not found', 'marina-clothing' ); ?></span>
            <h1 class="notfound__title"><?php esc_html_e( 'This page has', 'marina-clothing' ); ?> <em><?php esc_html_e( 'moved on.', 'marina-clothing' ); ?></em></h1>
            <p class="notfound__text"><?php esc_html_e( 'The page you were looking for has moved or no longer exists. Let us guide you back to the collection.', 'marina-clothing' ); ?></p>
            <div class="notfound__search"><?php get_search_form(); ?></div>
            <div class="notfound__actions">
                <a class="btn btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php marina_the_icon( 'arrow_back' ); ?><span><?php esc_html_e( 'Back to Home', 'marina-clothing' ); ?></span></a>
                <?php if ( marina_is_woocommerce_active() ) : ?>
                    <a class="btn btn--ghost" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><span><?php esc_html_e( 'Shop The Collection', 'marina-clothing' ); ?></span><?php marina_the_icon( 'arrow_forward' ); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php
    if ( marina_is_woocommerce_active() ) {
        get_template_part( 'template-parts/home/trending' );
    }
    ?>
</main>

<?php
get_footer();
