<?php
/**
 * Theme gallery: main image with hover magnifier, thumbnail carousel,
 * full-screen view and craft note.
 *
 * @var WC_Product $product
 * @var array      $items
 */

defined( 'ABSPATH' ) || exit;

$marina_total = count( $items );
$marina_first = $items[0];
$marina_cats  = get_the_terms( $product->get_id(), 'product_cat' );
$marina_cat   = '';
if ( $marina_cats && ! is_wp_error( $marina_cats ) ) {
    foreach ( $marina_cats as $marina_c ) {
        if ( (int) get_option( 'default_product_cat' ) !== $marina_c->term_id ) {
            $marina_cat = $marina_c->name;
            break;
        }
    }
}
?>
<div class="pgallery" data-gallery="<?php echo esc_attr( wp_json_encode( $items ) ); ?>">
    <div class="pgallery__frame">
        <div class="pgallery__badges">
            <?php if ( $marina_cat ) : ?>
                <span class="badge badge--pill pgallery__badge"><?php echo esc_html( $marina_cat ); ?></span>
            <?php endif; ?>
            <?php if ( $product->is_on_sale() ) : ?>
                <span class="badge badge--pill badge--accent"><?php echo esc_html( marina_sale_label( $product ) ); ?></span>
            <?php elseif ( $product->is_featured() ) : ?>
                <span class="badge badge--pill badge--accent"><?php esc_html_e( 'Signature Cut', 'marina-clothing' ); ?></span>
            <?php endif; ?>
        </div>

        <?php if ( $marina_total > 1 ) : ?>
            <span class="pgallery__counter"><span data-g="current">1</span> / <?php echo esc_html( $marina_total ); ?></span>
        <?php endif; ?>

        <div class="pgallery__stage" data-g="stage" role="button" tabindex="0" aria-label="<?php esc_attr_e( 'Open full screen image', 'marina-clothing' ); ?>">
            <img class="pgallery__main" data-g="main" src="<?php echo esc_url( $marina_first['src'] ); ?>" <?php echo $marina_first['srcset'] ? 'srcset="' . esc_attr( $marina_first['srcset'] ) . '" sizes="(min-width: 1024px) 720px, 100vw"' : ''; ?> alt="<?php echo esc_attr( $marina_first['alt'] ); ?>">
            <span class="pgallery__hint"><?php marina_the_icon( 'zoom_in' ); ?><?php esc_html_e( 'Hover to magnify', 'marina-clothing' ); ?></span>
        </div>

        <span class="pgallery__caption" data-g="caption"<?php echo $marina_first['caption'] ? '' : ' hidden'; ?>><?php echo esc_html( $marina_first['caption'] ); ?></span>

        <button type="button" class="pgallery__fs" data-g="fullscreen">
            <?php marina_the_icon( 'fullscreen' ); ?><span><?php esc_html_e( 'Full Screen', 'marina-clothing' ); ?></span>
        </button>
    </div>

    <?php if ( $marina_total > 1 ) : ?>
        <div class="pgallery__thumbs-wrap">
            <button type="button" class="round-btn pgallery__nav pgallery__nav--prev" data-g="prev" aria-label="<?php esc_attr_e( 'Previous image', 'marina-clothing' ); ?>"><?php marina_the_icon( 'chevron_left' ); ?></button>
            <div class="pgallery__thumbs" data-g="thumbs">
                <?php foreach ( $items as $marina_i => $marina_item ) : ?>
                    <button type="button" class="pgallery__thumb<?php echo 0 === $marina_i ? ' is-active' : ''; ?>" data-index="<?php echo esc_attr( $marina_i ); ?>" aria-label="<?php /* translators: %d: image number */ echo esc_attr( sprintf( __( 'View image %d', 'marina-clothing' ), $marina_i + 1 ) ); ?>">
                        <img src="<?php echo esc_url( $marina_item['thumb'] ); ?>" alt="" loading="lazy">
                        <?php if ( $marina_item['caption'] ) : ?>
                            <span class="pgallery__thumb-label"><?php echo esc_html( wp_trim_words( $marina_item['caption'], 3, '' ) ); ?></span>
                        <?php endif; ?>
                    </button>
                <?php endforeach; ?>
            </div>
            <button type="button" class="round-btn pgallery__nav pgallery__nav--next" data-g="next" aria-label="<?php esc_attr_e( 'Next image', 'marina-clothing' ); ?>"><?php marina_the_icon( 'chevron_right' ); ?></button>
        </div>
    <?php endif; ?>

    <?php if ( marina_opt( 'product_note_text' ) ) : ?>
        <div class="craft-note">
            <?php marina_the_icon( 'history_edu' ); ?>
            <div>
                <p class="craft-note__title"><?php echo esc_html( marina_opt( 'product_note_title' ) ); ?></p>
                <p class="craft-note__text"><?php echo esc_html( marina_opt( 'product_note_text' ) ); ?></p>
            </div>
        </div>
    <?php endif; ?>
</div>
