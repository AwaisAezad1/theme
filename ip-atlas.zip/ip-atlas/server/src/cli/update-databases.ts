/**
 * Downloads / refreshes the three geolocation databases.
 *
 *   npm run db:update                      update whatever is stale and configured
 *   npm run db:update -- --force           ignore freshness checks
 *   npm run db:update -- --only=maxmind    only some providers (maxmind, ipinfo, ip2location)
 *
 * Each download is validated before it replaces the live file, and the swap is atomic, so a failed
 * or partial download can never break a running site. The server notices new files on its own.
 */
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import maxmind from 'maxmind';
import { IP2Location } from 'ip2location-nodejs';
import * as tar from 'tar';
import yauzl from 'yauzl';
import { loadConfig, type Config } from '../config.js';
import type { ProviderId } from '../providers/types.js';

const DAY = 86_400_000;

interface Job {
  id: ProviderId;
  label: string;
  target: string;
  /** Returns a reason when the job cannot run (missing credentials). */
  blocked(): string | null;
  /** True when the installed file is recent enough to skip. */
  isFresh(mtime: Date, now: Date): boolean;
  run(workDir: string): Promise<string>;
}

async function download(url: string, dest: string, headers: Record<string, string> = {}): Promise<void> {
  const res = await fetch(url, { headers, redirect: 'follow', signal: AbortSignal.timeout(20 * 60_000) });
  if (!res.ok || !res.body) {
    if (res.status === 401 || res.status === 403) throw new Error(`HTTP ${res.status}: credentials rejected`);
    if (res.status === 429) throw new Error('HTTP 429: download limit reached, try again tomorrow');
    throw new Error(`HTTP ${res.status} ${res.statusText}`.trim());
  }
  await pipeline(Readable.fromWeb(res.body as never), fs.createWriteStream(dest));
}

async function readHead(file: string, bytes: number): Promise<Buffer> {
  const fh = await fsp.open(file, 'r');
  try {
    const buf = Buffer.alloc(bytes);
    const { bytesRead } = await fh.read(buf, 0, bytes, 0);
    return buf.subarray(0, bytesRead);
  } finally {
    await fh.close();
  }
}

async function findFile(dir: string, match: (name: string) => boolean): Promise<string | null> {
  for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const found = await findFile(full, match);
      if (found) return found;
    } else if (match(entry.name)) {
      return full;
    }
  }
  return null;
}

/** Atomically put a validated file in place (same-filesystem rename, with a copy fallback). */
async function install(src: string, target: string): Promise<void> {
  await fsp.mkdir(path.dirname(target), { recursive: true });
  try {
    await fsp.rename(src, target);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'EXDEV') throw err;
    const staged = `${target}.new-${process.pid}`;
    await fsp.copyFile(src, staged);
    await fsp.rename(staged, target);
  }
}

async function validateMmdb(file: string, expectType: RegExp | null): Promise<void> {
  const reader = await maxmind.open(file);
  const type = reader.metadata.databaseType;
  if (expectType && !expectType.test(type)) throw new Error(`unexpected database type "${type}"`);
  if (reader.get('8.8.8.8') === null && reader.get('1.1.1.1') === null) {
    throw new Error('database does not resolve common test addresses');
  }
}

function maxmindJob(config: Config, edition: 'GeoLite2-City' | 'GeoLite2-ASN', target: string, type: RegExp): Job {
  return {
    id: 'maxmind',
    label: edition,
    target,
    blocked: () => (config.maxmind.licenseKey ? null : 'MAXMIND_LICENSE_KEY is not set'),
    isFresh: (mtime, now) => now.getTime() - mtime.getTime() < 3 * DAY,
    async run(work) {
      const { accountId, licenseKey } = config.maxmind;
      const headers: Record<string, string> = {};
      let url: string;
      if (config.maxmind.downloadUrl) {
        url = config.maxmind.downloadUrl.replace('{edition}', edition).replace('{license_key}', encodeURIComponent(licenseKey!));
      } else if (accountId) {
        url = `https://download.maxmind.com/geoip/databases/${edition}/download?suffix=tar.gz`;
      } else {
        url = `https://download.maxmind.com/app/geoip_download?edition_id=${edition}&license_key=${encodeURIComponent(licenseKey!)}&suffix=tar.gz`;
      }
      if (accountId) headers.Authorization = `Basic ${Buffer.from(`${accountId}:${licenseKey}`).toString('base64')}`;
      const archive = path.join(work, `${edition}.tar.gz`);
      await download(url, archive, headers);
      const head = await readHead(archive, 2);
      if (head[0] !== 0x1f || head[1] !== 0x8b) throw new Error('download is not a gzip archive');
      const out = path.join(work, 'extract');
      await fsp.mkdir(out);
      await tar.x({ file: archive, cwd: out, filter: (p) => p.endsWith('.mmdb') });
      const mmdb = await findFile(out, (n) => n === `${edition}.mmdb`);
      if (!mmdb) throw new Error(`${edition}.mmdb not found in the archive`);
      await validateMmdb(mmdb, type);
      await install(mmdb, this.target);
      return 'updated';
    },
  };
}

function ipinfoJob(config: Config): Job {
  return {
    id: 'ipinfo',
    label: 'IPinfo database',
    target: config.paths.ipinfo,
    blocked: () => (config.ipinfo.token ? null : 'IPINFO_TOKEN is not set'),
    isFresh: (mtime, now) => now.getTime() - mtime.getTime() < 1 * DAY,
    async run(work) {
      const template = config.ipinfo.downloadUrl ?? 'https://ipinfo.io/data/ipinfo_lite.mmdb?token={token}';
      const url = template.replace('{token}', encodeURIComponent(config.ipinfo.token!));
      const file = path.join(work, 'ipinfo.mmdb');
      await download(url, file);
      await validateMmdb(file, null);
      await install(file, this.target);
      return 'updated';
    },
  };
}

function unzipLargestBin(zipPath: string, dest: string): Promise<void> {
  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, (err, zip) => {
      if (err || !zip) return reject(err ?? new Error('could not open zip'));
      let best: yauzl.Entry | null = null;
      zip.on('entry', (entry: yauzl.Entry) => {
        if (/\.bin$/i.test(entry.fileName) && (!best || entry.uncompressedSize > best.uncompressedSize)) best = entry;
        zip.readEntry();
      });
      zip.on('error', reject);
      zip.on('end', () => {
        if (!best) return reject(new Error('no .BIN file inside the zip'));
        const chosen: yauzl.Entry = best;
        // Re-open to stream the chosen entry (the file name inside the archive is never used as an output path).
        yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, (e2, z2) => {
          if (e2 || !z2) return reject(e2 ?? new Error('could not reopen zip'));
          z2.on('entry', (entry: yauzl.Entry) => {
            if (entry.fileName !== chosen.fileName) return z2.readEntry();
            z2.openReadStream(entry, (e3, stream) => {
              if (e3 || !stream) return reject(e3 ?? new Error('could not read zip entry'));
              pipeline(stream, fs.createWriteStream(dest)).then(() => resolve(), reject);
            });
          });
          z2.on('error', reject);
          z2.readEntry();
        });
      });
      zip.readEntry();
    });
  });
}

function ip2locationJob(config: Config): Job {
  return {
    id: 'ip2location',
    label: `IP2Location ${config.ip2location.downloadPackage}`,
    target: config.paths.ip2location,
    blocked: () => (config.ip2location.token ? null : 'IP2LOCATION_TOKEN is not set'),
    // IP2Location publishes monthly and disables accounts that download too often: at most once per calendar month.
    isFresh: (mtime, now) =>
      (mtime.getUTCFullYear() === now.getUTCFullYear() && mtime.getUTCMonth() === now.getUTCMonth()) ||
      now.getUTCDate() < 2,
    async run(work) {
      const template =
        config.ip2location.downloadUrl ?? 'https://www.ip2location.com/download/?token={token}&file={package}';
      const url = template
        .replace('{token}', encodeURIComponent(config.ip2location.token!))
        .replace('{package}', encodeURIComponent(config.ip2location.downloadPackage));
      const zip = path.join(work, 'ip2location.zip');
      await download(url, zip);
      const head = await readHead(zip, 4);
      if (!(head[0] === 0x50 && head[1] === 0x4b)) {
        // IP2Location answers errors with HTTP 200 and a short text body.
        const text = (await readHead(zip, 200)).toString('utf8').replace(/\s+/g, ' ').trim();
        throw new Error(`IP2Location refused the download: ${text || 'empty response'}`);
      }
      const bin = path.join(work, 'ip2location.BIN');
      await unzipLargestBin(zip, bin);
      const db = new IP2Location();
      try {
        db.open(bin);
        const probe = db.getAll('8.8.8.8');
        if (db.getPackageVersion() <= 0 || !/^[A-Z]{2}$/.test(String(probe.countryShort))) {
          throw new Error('BIN file failed the 8.8.8.8 self-test');
        }
      } finally {
        db.close();
      }
      await install(bin, this.target);
      return 'updated';
    },
  };
}

async function main(): Promise<void> {
  const config = loadConfig();
  const args = process.argv.slice(2);
  const force = args.includes('--force');
  const onlyArg = args.find((a) => a.startsWith('--only='))?.slice('--only='.length);
  const only = onlyArg ? new Set(onlyArg.split(',').map((s) => s.trim())) : null;
  if (only) {
    const unknown = [...only].filter((id) => !['maxmind', 'ipinfo', 'ip2location'].includes(id));
    if (unknown.length) throw new Error(`Unknown provider in --only: ${unknown.join(', ')}`);
  }

  const jobs: Job[] = [
    maxmindJob(config, 'GeoLite2-City', config.paths.maxmindCity, /city/i),
    maxmindJob(config, 'GeoLite2-ASN', config.paths.maxmindAsn, /asn/i),
    ipinfoJob(config),
    ip2locationJob(config),
  ].filter((j) => !only || only.has(j.id));

  await fsp.mkdir(config.dataDir, { recursive: true });
  let failed = 0;

  for (const job of jobs) {
    const tag = `[${job.id}] ${job.label}`;
    const reason = job.blocked();
    if (reason) {
      console.log(`${tag}: skipped (${reason})`);
      continue;
    }
    const stat = await fsp.stat(job.target).catch(() => null);
    if (stat && !force && job.isFresh(stat.mtime, new Date())) {
      console.log(`${tag}: up to date (use --force to download anyway)`);
      continue;
    }
    const work = await fsp.mkdtemp(path.join(config.dataDir, '.tmp-'));
    try {
      console.log(`${tag}: downloading...`);
      const result = await job.run(work);
      console.log(`${tag}: ${result}`);
    } catch (err) {
      failed++;
      console.error(`${tag}: FAILED - ${err instanceof Error ? err.message : err}`);
    } finally {
      await fsp.rm(work, { recursive: true, force: true });
    }
  }

  if (failed > 0) process.exit(1);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
