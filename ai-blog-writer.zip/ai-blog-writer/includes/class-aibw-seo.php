<?php
defined( 'ABSPATH' ) || exit;

/**
 * On-page checks and SEO plugin metadata. Scores are rule checks, not ranking predictions.
 */
class AIBW_SEO {

	public static function active_plugin() {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			return 'rankmath';
		}
		return '';
	}

	public static function slug_from_title( $title ) {
		$slug = sanitize_title( $title );
		return '' !== $slug ? $slug : 'draft';
	}

	/**
	 * @return array{fields:array,warnings:array,internal:array}
	 */
	public static function review( $article, $keyword = '' ) {
		$title   = isset( $article['title'] ) ? $article['title'] : '';
		$content = isset( $article['content'] ) ? $article['content'] : '';
		$seo_t   = ! empty( $article['seo_title'] ) ? $article['seo_title'] : $title;
		$desc    = ! empty( $article['meta_description'] ) ? $article['meta_description'] : wp_trim_words( wp_strip_all_tags( $content ), 24, '' );
		$focus   = ! empty( $article['focus_keyword'] ) ? $article['focus_keyword'] : $keyword;
		$slug    = self::slug_from_title( ! empty( $article['slug'] ) ? $article['slug'] : $title );
		$warnings = array();

		if ( '' === trim( $seo_t ) ) {
			$warnings[] = __( 'SEO title is empty.', 'ai-blog-writer' );
		} elseif ( mb_strlen( $seo_t ) > 70 ) {
			$warnings[] = __( 'SEO title is longer than 70 characters.', 'ai-blog-writer' );
		}
		if ( '' === trim( $desc ) ) {
			$warnings[] = __( 'Meta description is empty.', 'ai-blog-writer' );
		} elseif ( mb_strlen( $desc ) > 170 ) {
			$warnings[] = __( 'Meta description is longer than 170 characters.', 'ai-blog-writer' );
		}
		if ( ! preg_match( '/<h2\b/i', $content ) ) {
			$warnings[] = __( 'The article has no H2 headings.', 'ai-blog-writer' );
		}
		if ( preg_match( '/<h[23][^>]*>\s*<\/h[23]>/i', $content ) ) {
			$warnings[] = __( 'An empty heading was found.', 'ai-blog-writer' );
		}
		if ( $focus ) {
			$plain = strtolower( wp_strip_all_tags( $content ) );
			$count = substr_count( $plain, strtolower( $focus ) );
			$words = max( 1, str_word_count( $plain ) );
			if ( ( $count / $words ) > 0.03 ) {
				$warnings[] = __( 'The focus keyword is repeated often enough that it may read unnaturally. This is a frequency check only.', 'ai-blog-writer' );
			}
		}
		if ( preg_match( '/<a\b[^>]*href=["\']\s*["\']/i', $content ) ) {
			$warnings[] = __( 'A link has an empty address.', 'ai-blog-writer' );
		}
		if ( preg_match( '/<img\b(?![^>]*\balt=)[^>]*>/i', $content ) ) {
			$warnings[] = __( 'An image is missing alt text.', 'ai-blog-writer' );
		}

		$internal = self::internal_candidates( $title . ' ' . $focus, 0 );
		return array(
			'fields'   => array(
				'seo_title'        => sanitize_text_field( $seo_t ),
				'meta_description' => sanitize_text_field( $desc ),
				'focus_keyword'    => sanitize_text_field( $focus ),
				'slug'             => $slug,
				'excerpt'          => sanitize_text_field( wp_trim_words( wp_strip_all_tags( $content ), 40, '' ) ),
			),
			'warnings' => $warnings,
			'internal' => $internal,
		);
	}

	public static function internal_candidates( $text, $exclude_id = 0 ) {
		$words = array_filter( preg_split( '/\s+/', strtolower( wp_strip_all_tags( $text ) ) ), function ( $w ) {
			return strlen( $w ) > 4;
		} );
		$words = array_slice( array_unique( $words ), 0, 6 );
		if ( ! $words ) {
			return array();
		}
		$q = new WP_Query(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				's'              => implode( ' ', array_slice( $words, 0, 3 ) ),
				'posts_per_page' => 5,
				'post__not_in'   => $exclude_id ? array( (int) $exclude_id ) : array(),
			)
		);
		$out = array();
		foreach ( $q->posts as $post ) {
			if ( (int) $post->ID === (int) $exclude_id ) {
				continue;
			}
			$out[] = array(
				'id'    => (int) $post->ID,
				'title' => $post->post_title,
				'url'   => get_permalink( $post ),
			);
		}
		wp_reset_postdata();
		return $out;
	}

	public static function insert_internal_links( $content, $links, $self_id = 0 ) {
		if ( ! $links || false !== strpos( $content, 'aibw-internal' ) ) {
			return $content;
		}
		$items = '';
		foreach ( array_slice( $links, 0, 3 ) as $link ) {
			if ( empty( $link['url'] ) || (int) $link['id'] === (int) $self_id ) {
				continue;
			}
			$status = get_post_status( $link['id'] );
			if ( 'publish' !== $status ) {
				continue;
			}
			$items .= '<li><a class="aibw-internal" href="' . esc_url( $link['url'] ) . '">' . esc_html( $link['title'] ) . '</a></li>';
		}
		if ( '' === $items ) {
			return $content;
		}
		return $content . '<h2>' . esc_html__( 'Related reading', 'ai-blog-writer' ) . '</h2><ul>' . $items . '</ul>';
	}

	/**
	 * Write SEO fields without touching unrelated keys.
	 */
	public static function apply( $post_id, $fields ) {
		update_post_meta( $post_id, '_aibw_seo', $fields );
		$plugin = self::active_plugin();
		if ( 'yoast' === $plugin ) {
			update_post_meta( $post_id, '_yoast_wpseo_title', $fields['seo_title'] );
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', $fields['meta_description'] );
			if ( ! empty( $fields['focus_keyword'] ) ) {
				update_post_meta( $post_id, '_yoast_wpseo_focuskw', $fields['focus_keyword'] );
			}
		} elseif ( 'rankmath' === $plugin ) {
			update_post_meta( $post_id, 'rank_math_title', $fields['seo_title'] );
			update_post_meta( $post_id, 'rank_math_description', $fields['meta_description'] );
			if ( ! empty( $fields['focus_keyword'] ) ) {
				update_post_meta( $post_id, 'rank_math_focus_keyword', $fields['focus_keyword'] );
			}
		}
		return $plugin;
	}
}
