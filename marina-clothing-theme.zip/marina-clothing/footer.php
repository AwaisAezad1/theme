<?php
/**
 * Footer.
 */
?>

<footer class="site-footer">
    <div class="container">
        <div class="site-footer__grid">

            <div class="site-footer__about">
                <div>
                    <p class="site-footer__brand"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
                    <p class="site-footer__text"><?php echo esc_html( marina_opt( 'footer_about' ) ); ?></p>
                </div>
                <div class="site-footer__certs">
                    <span><?php marina_the_icon( 'verified' ); ?> <?php esc_html_e( 'Quality Guaranteed', 'marina-clothing' ); ?></span>
                    <span><?php marina_the_icon( 'lock' ); ?> <?php esc_html_e( 'Secure Checkout', 'marina-clothing' ); ?></span>
                </div>
            </div>

            <nav class="site-footer__col" aria-label="<?php esc_attr_e( 'Collections', 'marina-clothing' ); ?>">
                <p class="site-footer__heading"><?php echo esc_html( marina_menu_name( 'footer', __( 'Collections', 'marina-clothing' ) ) ); ?></p>
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'footer',
                        'container'      => false,
                        'menu_class'     => 'footer-links',
                        'depth'          => 1,
                        'fallback_cb'    => 'marina_footer_collections_fallback',
                    )
                );
                ?>
            </nav>

            <nav class="site-footer__col" aria-label="<?php esc_attr_e( 'Concierge', 'marina-clothing' ); ?>">
                <p class="site-footer__heading"><?php echo esc_html( marina_menu_name( 'footer-concierge', __( 'Concierge', 'marina-clothing' ) ) ); ?></p>
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'footer-concierge',
                        'container'      => false,
                        'menu_class'     => 'footer-links',
                        'depth'          => 1,
                        'fallback_cb'    => 'marina_footer_concierge_fallback',
                    )
                );
                ?>
            </nav>

            <div class="site-footer__dispatch">
                <p class="site-footer__dispatch-title"><?php esc_html_e( 'The Marina Newsletter', 'marina-clothing' ); ?></p>
                <p class="site-footer__small"><?php esc_html_e( 'New arrivals, style notes and members-only offers, straight to your inbox.', 'marina-clothing' ); ?></p>
                <?php marina_newsletter_form( 'compact' ); ?>
                <p class="site-footer__fineprint"><?php esc_html_e( 'By subscribing you accept our Privacy Policy. Dispatches are strictly seasonal.', 'marina-clothing' ); ?></p>
            </div>
        </div>

        <div class="site-footer__bottom">
            <div class="site-footer__legal">
                <span>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'marina-clothing' ); ?></span>
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'footer-legal',
                        'container'      => false,
                        'menu_class'     => 'footer-legal',
                        'depth'          => 1,
                        'fallback_cb'    => 'marina_footer_legal_fallback',
                    )
                );
                ?>
            </div>
            <span class="site-footer__locations"><?php echo esc_html( marina_opt( 'footer_locations' ) ); ?></span>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
