<?php
defined( 'ABSPATH' ) || exit;

/**
 * The AI services the plugin can talk to.
 *
 * Note: none of these companies lets a website sign in with a person's normal
 * chat login. Each one issues an "API key" from the person's own account, so
 * "connecting an account" means creating/logging in to that account and pasting
 * the key. Paid plan limits and billing then apply to that key.
 */
class AIBW_Providers {

	public static function all() {
		return array(
			'groq'       => array(
				'label'         => 'Groq (Free)',
				'short'         => 'Groq',
				'tier'          => 'free',
				'default_model' => 'openai/gpt-oss-120b',
				'signup'        => 'https://console.groq.com/',
				'login'         => 'https://console.groq.com/',
				'keys_url'      => 'https://console.groq.com/keys',
				'privacy'       => 'https://groq.com/privacy-policy/',
				'endpoint'      => 'https://api.groq.com/openai/v1/chat/completions',
				'blurb'         => 'Free to start - no credit card needed. A good default.',
			),
			'openai'     => array(
				'label'         => 'ChatGPT (OpenAI)',
				'short'         => 'ChatGPT',
				'tier'          => 'paid',
				'default_model' => 'gpt-4o-mini',
				'signup'        => 'https://platform.openai.com/signup',
				'login'         => 'https://platform.openai.com/login',
				'keys_url'      => 'https://platform.openai.com/api-keys',
				'privacy'       => 'https://openai.com/policies/privacy-policy',
				'endpoint'      => 'https://api.openai.com/v1/chat/completions',
				'blurb'         => 'Pay-as-you-go OpenAI account.',
			),
			'claude'     => array(
				'label'         => 'Claude (Anthropic)',
				'short'         => 'Claude',
				'tier'          => 'paid',
				'default_model' => 'claude-sonnet-5-5',
				'signup'        => 'https://console.anthropic.com/',
				'login'         => 'https://console.anthropic.com/login',
				'keys_url'      => 'https://console.anthropic.com/settings/keys',
				'privacy'       => 'https://www.anthropic.com/privacy',
				'endpoint'      => 'https://api.anthropic.com/v1/messages',
				'blurb'         => 'Natural, well-structured writing.',
			),
			'gemini'     => array(
				'label'         => 'Gemini (Google)',
				'short'         => 'Gemini',
				'tier'          => 'paid',
				'default_model' => 'gemini-2.5-flash',
				'signup'        => 'https://aistudio.google.com/',
				'login'         => 'https://aistudio.google.com/',
				'keys_url'      => 'https://aistudio.google.com/app/apikey',
				'privacy'       => 'https://policies.google.com/privacy',
				'endpoint'      => 'https://generativelanguage.googleapis.com/v1beta/models/',
				'blurb'         => 'Google AI Studio has a free tier with limits.',
			),
			'perplexity' => array(
				'label'         => 'Perplexity',
				'short'         => 'Perplexity',
				'tier'          => 'paid',
				'default_model' => 'sonar',
				'signup'        => 'https://www.perplexity.ai/account/api',
				'login'         => 'https://www.perplexity.ai/account/api',
				'keys_url'      => 'https://www.perplexity.ai/account/api/keys',
				'privacy'       => 'https://www.perplexity.ai/hub/legal/privacy-policy',
				'endpoint'      => 'https://api.perplexity.ai/chat/completions',
				'blurb'         => 'Searches the web, so it is good for current topics.',
			),
		);
	}

	public static function get( $id ) {
		$all = self::all();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	public static function label( $id ) {
		$p = self::get( $id );
		return $p ? $p['label'] : $id;
	}

	public static function default_model( $id ) {
		$p = self::get( $id );
		return $p ? $p['default_model'] : '';
	}

	/* ------------------------------------------------------------------ */
	/* HTTP                                                                */
	/* ------------------------------------------------------------------ */

	private static function http( $method, $url, $headers, $body, $label ) {
		$args = array(
			'method'  => $method,
			'timeout' => 150,
			'headers' => $headers,
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}
		$res = wp_remote_request( $url, $args );

		if ( is_wp_error( $res ) ) {
			$msg = $res->get_error_message();
			if ( false !== stripos( $msg, 'timed out' ) || false !== stripos( $msg, 'cURL error 28' ) ) {
				$msg .= ' ' . __( '(The AI took too long, or your host blocks outgoing connections. Try a shorter blog length.)', 'inkwell-ai-blog-writer' );
			}
			return new WP_Error( 'aibw_http', $label . ': ' . $msg );
		}

		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( $code < 200 || $code >= 300 ) {
			$msg = '';
			if ( isset( $data['error']['message'] ) ) {
				$msg = $data['error']['message'];
			} elseif ( isset( $data['error'] ) && is_string( $data['error'] ) ) {
				$msg = $data['error'];
			} elseif ( isset( $data['message'] ) && is_string( $data['message'] ) ) {
				$msg = $data['message'];
			}
			$msg  = '' !== $msg ? $msg : 'HTTP ' . $code;
			$hint = '';
			if ( 401 === $code || 403 === $code ) {
				$hint = ' ' . __( 'Your API key was rejected. Check it on the AI Accounts page.', 'inkwell-ai-blog-writer' );
			} elseif ( 429 === $code ) {
				$hint = ' ' . __( 'Rate limit reached, or this account is out of credit/quota.', 'inkwell-ai-blog-writer' );
			} elseif ( 404 === $code ) {
				$hint = ' ' . __( 'Model not found. Pick another model on the AI Accounts page.', 'inkwell-ai-blog-writer' );
			}
			return new WP_Error( 'aibw_api', $label . ': ' . $msg . $hint );
		}

		return is_array( $data ) ? $data : array();
	}

	/* ------------------------------------------------------------------ */
	/* Text generation                                                     */
	/* ------------------------------------------------------------------ */

	/**
	 * Send a prompt to one provider.
	 *
	 * @return string|WP_Error Generated text.
	 */
	public static function request( $id, $prompt, $key, $model = '', $max_tokens = 8192 ) {
		$p = self::get( $id );
		if ( ! $p ) {
			return new WP_Error( 'aibw_provider', __( 'Unknown AI provider.', 'inkwell-ai-blog-writer' ) );
		}
		if ( '' === $key ) {
			/* translators: %s: AI name */
			return new WP_Error( 'aibw_nokey', sprintf( __( '%s is not connected yet. Add its API key on the AI Accounts page.', 'inkwell-ai-blog-writer' ), $p['label'] ) );
		}
		$model = '' !== $model ? $model : $p['default_model'];

		switch ( $id ) {
			case 'claude':
				return self::request_claude( $p, $key, $model, $prompt, $max_tokens );
			case 'gemini':
				return self::request_gemini( $p, $key, $model, $prompt );
			default:
				return self::request_openai_compatible( $p, $key, $model, $prompt );
		}
	}

	private static function request_openai_compatible( $p, $key, $model, $prompt ) {
		$data = self::http(
			'POST',
			$p['endpoint'],
			array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $key,
			),
			array(
				'model'    => $model,
				'messages' => array(
					array(
						'role'    => 'system',
						'content' => 'You are an expert blog writer.',
					),
					array(
						'role'    => 'user',
						'content' => $prompt,
					),
				),
			),
			$p['short']
		);
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$text = isset( $data['choices'][0]['message']['content'] ) ? (string) $data['choices'][0]['message']['content'] : '';
		if ( '' === trim( $text ) ) {
			return new WP_Error( 'aibw_empty', $p['short'] . ': ' . __( 'the AI returned an empty answer.', 'inkwell-ai-blog-writer' ) );
		}
		return $text;
	}

	private static function request_claude( $p, $key, $model, $prompt, $max_tokens ) {
		$data = self::http(
			'POST',
			$p['endpoint'],
			array(
				'Content-Type'      => 'application/json',
				'x-api-key'         => $key,
				'anthropic-version' => '2023-06-01',
			),
			array(
				'model'      => $model,
				'max_tokens' => (int) $max_tokens,
				'system'     => 'You are an expert blog writer.',
				'messages'   => array(
					array(
						'role'    => 'user',
						'content' => $prompt,
					),
				),
			),
			$p['short']
		);
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$text = '';
		if ( ! empty( $data['content'] ) && is_array( $data['content'] ) ) {
			foreach ( $data['content'] as $block ) {
				if ( isset( $block['type'], $block['text'] ) && 'text' === $block['type'] ) {
					$text .= $block['text'];
				}
			}
		}
		if ( '' === trim( $text ) ) {
			return new WP_Error( 'aibw_empty', $p['short'] . ': ' . __( 'the AI returned an empty answer.', 'inkwell-ai-blog-writer' ) );
		}
		return $text;
	}

	private static function request_gemini( $p, $key, $model, $prompt ) {
		$data = self::http(
			'POST',
			$p['endpoint'] . rawurlencode( $model ) . ':generateContent',
			array(
				'Content-Type'   => 'application/json',
				'x-goog-api-key' => $key,
			),
			array(
				'systemInstruction' => array( 'parts' => array( array( 'text' => 'You are an expert blog writer.' ) ) ),
				'contents'          => array( array( 'parts' => array( array( 'text' => $prompt ) ) ) ),
			),
			$p['short']
		);
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$text = '';
		if ( ! empty( $data['candidates'][0]['content']['parts'] ) ) {
			foreach ( $data['candidates'][0]['content']['parts'] as $part ) {
				if ( isset( $part['text'] ) ) {
					$text .= $part['text'];
				}
			}
		}
		if ( '' === trim( $text ) ) {
			return new WP_Error( 'aibw_empty', $p['short'] . ': ' . __( 'the AI returned an empty answer (it may have been blocked by safety filters).', 'inkwell-ai-blog-writer' ) );
		}
		return $text;
	}

	/* ------------------------------------------------------------------ */
	/* Model lists (so people pick a model instead of typing its name)     */
	/* ------------------------------------------------------------------ */

	/**
	 * Get a list of models for a provider.
	 *
	 * @return string[] Model IDs; empty array if the list cannot be fetched.
	 */
	public static function list_models( $id, $key ) {
		$p = self::get( $id );
		if ( ! $p || '' === $key ) {
			return array();
		}

		if ( 'perplexity' === $id ) {
			return array( 'sonar', 'sonar-pro' );
		}

		$models = array();

		if ( 'claude' === $id ) {
			$data = self::http(
				'GET',
				'https://api.anthropic.com/v1/models?limit=100',
				array(
					'x-api-key'         => $key,
					'anthropic-version' => '2023-06-01',
				),
				null,
				$p['short']
			);
			if ( ! is_wp_error( $data ) && ! empty( $data['data'] ) ) {
				foreach ( $data['data'] as $m ) {
					if ( ! empty( $m['id'] ) ) {
						$models[] = $m['id'];
					}
				}
			}
		} elseif ( 'gemini' === $id ) {
			$data = self::http( 'GET', 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=100', array( 'x-goog-api-key' => $key ), null, $p['short'] );
			if ( ! is_wp_error( $data ) && ! empty( $data['models'] ) ) {
				foreach ( $data['models'] as $m ) {
					$methods = isset( $m['supportedGenerationMethods'] ) ? (array) $m['supportedGenerationMethods'] : array();
					if ( ! empty( $m['name'] ) && in_array( 'generateContent', $methods, true ) ) {
						$models[] = preg_replace( '#^models/#', '', $m['name'] );
					}
				}
			}
		} else { // openai, groq.
			$url  = 'openai' === $id ? 'https://api.openai.com/v1/models' : 'https://api.groq.com/openai/v1/models';
			$data = self::http( 'GET', $url, array( 'Authorization' => 'Bearer ' . $key ), null, $p['short'] );
			if ( ! is_wp_error( $data ) && ! empty( $data['data'] ) ) {
				foreach ( $data['data'] as $m ) {
					if ( ! empty( $m['id'] ) ) {
						$models[] = $m['id'];
					}
				}
			}
		}

		// Keep only chat/text models.
		$models = array_filter(
			$models,
			function ( $m ) {
				return ! preg_match( '/embed|whisper|tts|audio|realtime|transcribe|moderation|image|vision-preview|guard|dall|imagen|veo|aqa|robotics/i', $m );
			}
		);
		sort( $models );
		return array_slice( array_values( array_unique( $models ) ), 0, 80 );
	}

	/**
	 * Tiny request used by the "Test connection" button.
	 *
	 * @return true|WP_Error
	 */
	public static function test( $id, $key, $model = '' ) {
		$res = self::request( $id, 'Reply with exactly: OK', $key, $model, 32 );
		return is_wp_error( $res ) ? $res : true;
	}
}
