# WordPress Developer Starter Theme

A reusable classic WordPress theme boilerplate for WordPress and WooCommerce development.

## Structure

```text
wp-developer-starter/
├── assets/
│   ├── css/
│   │   ├── admin.css
│   │   └── custom.css
│   └── js/
│       ├── admin.js
│       └── main.js
├── inc/
│   ├── ajax.php
│   ├── enqueue.php
│   ├── helpers.php
│   ├── setup.php
│   └── woocommerce.php
├── languages/
├── template-parts/
│   ├── content-page.php
│   └── content.php
├── 404.php
├── archive.php
├── comments.php
├── footer.php
├── functions.php
├── header.php
├── index.php
├── page.php
├── search.php
├── single.php
├── style.css
└── README.md
```

## Start a new project

1. Copy this folder.
2. Rename it to your project/theme slug.
3. Change the theme metadata in `style.css`.
4. Change `WDS_*` constants and function prefixes to your project prefix.
5. Change the text domain from `wp-developer-starter`.
6. Add your project-specific code.
7. Zip the theme folder when you need to install it.

## Recommended prefix

Use a unique prefix based on the project.

Example:

```text
myshop_
```

Instead of generic functions such as:

```php
function setup() {}
```

use:

```php
function myshop_setup() {}
```

This reduces collisions with WordPress, plugins and other themes.

## WooCommerce

WooCommerce support is automatically loaded when WooCommerce is active.

Add WooCommerce-specific hooks and filters to:

```text
inc/woocommerce.php
```

For larger WooCommerce projects, you can later split this into:

```text
inc/woocommerce/
├── setup.php
├── hooks.php
├── cart.php
├── checkout.php
└── products.php
```

## AJAX

AJAX registration lives in:

```text
inc/ajax.php
```

The frontend receives:

```javascript
wdsData.ajaxUrl
wdsData.nonce
```

and includes a small helper:

```javascript
wdsAjax('action_name', {
    key: 'value'
});
```

## Good next additions

Depending on the project, add:

```text
front-page.php
sidebar.php
taxonomy.php
author.php
page-templates/
inc/custom-post-types.php
inc/customizer.php
inc/rest-api.php
inc/woocommerce/
```

## Important

This is a starter boilerplate, not a finished production theme. Review and adapt security, accessibility, performance and functionality for each project.
