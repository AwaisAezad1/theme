import { afterEach, describe, expect, it, vi } from 'vitest';
import { ApiClientError, lookupIp } from './api';
import { jsonResponse, londonResponse } from '../test/fixtures';

afterEach(() => vi.restoreAllMocks());

describe('lookupIp', () => {
  it('requests the caller IP when the query is empty', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(jsonResponse(londonResponse()));
    await lookupIp('  ');
    expect(fetchMock.mock.calls[0]![0]).toBe('/api/v1/ip');
  });

  it('URL-encodes explicit addresses (IPv6 colons)', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(jsonResponse(londonResponse()));
    await lookupIp('2001:4860:4860::8888');
    expect(fetchMock.mock.calls[0]![0]).toBe('/api/v1/ip/2001%3A4860%3A4860%3A%3A8888');
  });

  it('surfaces the server error message', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(jsonResponse({ error: { code: 'invalid_ip', message: 'Enter a valid IP.', status: 400 } }, 400));
    await expect(lookupIp('x')).rejects.toMatchObject({ message: 'Enter a valid IP.', code: 'invalid_ip', status: 400 });
  });

  it('gives friendly messages for proxy errors, 429 and network failures', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(new Response('<html>Bad gateway</html>', { status: 502 }));
    await expect(lookupIp('')).rejects.toMatchObject({ code: 'server_error' });
    vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(new Response('', { status: 429 }));
    await expect(lookupIp('')).rejects.toMatchObject({ code: 'rate_limited' });
    vi.spyOn(globalThis, 'fetch').mockRejectedValueOnce(new TypeError('Failed to fetch'));
    const err = await lookupIp('').catch((e) => e);
    expect(err).toBeInstanceOf(ApiClientError);
    expect(err.code).toBe('network_error');
  });

  it('rethrows aborts untouched', async () => {
    vi.spyOn(globalThis, 'fetch').mockRejectedValueOnce(new DOMException('aborted', 'AbortError'));
    await expect(lookupIp('')).rejects.toMatchObject({ name: 'AbortError' });
  });

  it('times out a hung request after 15 seconds', async () => {
    vi.useFakeTimers();
    try {
      vi.spyOn(globalThis, 'fetch').mockImplementation(
        (_url, init) =>
          new Promise((_resolve, reject) => {
            init?.signal?.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')));
          }),
      );
      const pending = lookupIp('').catch((e) => e);
      await vi.advanceTimersByTimeAsync(15_001);
      const err = await pending;
      expect(err).toMatchObject({ code: 'timeout' });
    } finally {
      vi.useRealTimers();
    }
  });
});
