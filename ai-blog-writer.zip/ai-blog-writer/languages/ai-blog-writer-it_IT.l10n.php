<?php
if (!defined('ABSPATH')) {
	exit();
}
return array(
	'project-id-version'=>'AI Blog Writer',
	'report-msgid-bugs-to'=>'',
	'pot-creation-date'=>'2026-10-19 09:46+0000',
	'po-revision-date'=>'2026-10-19 09:47+0000',
	'last-translator'=>'',
	'language-team'=>'Italian',
	'language'=>'it_IT',
	'plural-forms'=>'nplurals=2; plural=n != 1;',
	'mime-version'=>'1.0',
	'content-type'=>'text/plain; charset=UTF-8',
	'content-transfer-encoding'=>'8bit',
	'x-generator'=>'Loco https://localise.biz/',
	'x-loco-version'=>'2.8.9; wp-7.1.3; php-8.2.12',
	'x-domain'=>'ai-blog-writer',
	'messages'=>array(),
);
