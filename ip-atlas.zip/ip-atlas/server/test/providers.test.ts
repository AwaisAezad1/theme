import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { describe, it } from 'node:test';
import { Ip2LocationProvider, ip2locationDate, normalizeIp2Location } from '../src/providers/ip2location.js';
import { normalizeIpinfo } from '../src/providers/ipinfo.js';
import { MaxmindProvider } from '../src/providers/maxmind.js';
import { FIXTURES, LONDON_DB11, NA, fakeIp2Location, silent } from './helpers.js';

describe('MaxMind provider (official MaxMind test databases)', () => {
  const provider = new MaxmindProvider(
    path.join(FIXTURES, 'GeoIP2-City-Test.mmdb'),
    path.join(FIXTURES, 'GeoLite2-ASN-Test.mmdb'),
    silent,
  );

  it('maps city data', async () => {
    await provider.init();
    const r = await provider.lookup('81.2.69.142');
    assert.equal(r.status, 'ok');
    assert.equal(r.data?.city, 'London');
    assert.equal(r.data?.country_code, 'GB');
    assert.equal(r.data?.continent_code, 'EU');
    assert.equal(r.data?.timezone, 'Europe/London');
    assert.equal(typeof r.data?.latitude, 'number');
    assert.equal(typeof r.data?.longitude, 'number');
  });

  it('merges ASN data and supports IPv6', async () => {
    const asn = await provider.lookup('2600:1000::1');
    assert.equal(asn.data?.asn, 237);
    assert.equal(asn.data?.organization, 'Merit Network Inc.');
    const v6 = await provider.lookup('2a02:ff00::1');
    assert.equal(v6.status, 'ok');
    assert.equal(v6.data?.country_code, 'IT');
  });

  it('reports no_data for an address that is not in the database', async () => {
    const r = await provider.lookup('8.8.8.8');
    assert.equal(r.status, 'no_data');
    assert.equal(r.data, null);
  });

  it('reports unavailable when nothing is installed', async () => {
    const p = new MaxmindProvider('/nope/a.mmdb', '/nope/b.mmdb', silent);
    await p.init();
    assert.equal((await p.lookup('81.2.69.142')).status, 'unavailable');
    assert.equal(p.info().loaded, false);
  });

  it('survives a corrupt file without crashing', async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ipa-'));
    const bad = path.join(dir, 'bad.mmdb');
    fs.writeFileSync(bad, 'this is not a database');
    const p = new MaxmindProvider(bad, '/nope.mmdb', silent);
    await p.init();
    assert.equal(p.info().loaded, false);
    assert.equal((await p.lookup('81.2.69.142')).status, 'unavailable');
  });

  it('hot-reloads when the file is replaced', async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ipa-'));
    const file = path.join(dir, 'city.mmdb');
    const p = new MaxmindProvider(file, '/nope.mmdb', silent);
    await p.init();
    assert.equal(p.info().loaded, false);
    fs.copyFileSync(path.join(FIXTURES, 'GeoIP2-City-Test.mmdb'), file);
    assert.equal(await p.reloadIfChanged(), true);
    assert.equal((await p.lookup('81.2.69.142')).data?.city, 'London');
    assert.equal(await p.reloadIfChanged(), false);
  });
});

describe('normalizeIpinfo', () => {
  it('maps IPinfo Lite records', () => {
    const r = normalizeIpinfo({
      asn: 'AS15169',
      as_name: 'Google LLC',
      as_domain: 'google.com',
      country_code: 'US',
      country: 'United States',
      continent_code: 'NA',
      continent: 'North America',
    });
    assert.equal(r.country_code, 'US');
    assert.equal(r.country, 'United States');
    assert.equal(r.continent, 'North America');
    assert.equal(r.asn, 15169);
    assert.equal(r.organization, 'Google LLC');
    assert.equal(r.domain, 'google.com');
    assert.equal(r.city, null);
    assert.equal(r.latitude, null);
  });

  it('maps classic city-level records', () => {
    const r = normalizeIpinfo({
      ip: '8.8.8.8',
      city: 'Mountain View',
      region: 'California',
      country: 'US',
      loc: '37.4056,-122.0775',
      org: 'AS15169 Google LLC',
      postal: '94043',
      timezone: 'America/Los_Angeles',
    });
    assert.equal(r.country_code, 'US');
    assert.equal(r.country, 'United States');
    assert.equal(r.city, 'Mountain View');
    assert.equal(r.latitude, 37.4056);
    assert.equal(r.longitude, -122.0775);
    assert.equal(r.asn, 15169);
    assert.equal(r.organization, 'Google LLC');
    assert.equal(r.postal_code, '94043');
    assert.equal(r.timezone, 'America/Los_Angeles');
  });

  it('maps nested geo / as objects', () => {
    const r = normalizeIpinfo({
      geo: { city: 'Lahore', region: 'Punjab', country: 'Pakistan', country_code: 'PK', latitude: 31.5, longitude: 74.3 },
      as: { asn: 'AS17557', name: 'Pakistan Telecommunication', domain: 'ptcl.com.pk' },
    });
    assert.equal(r.country_code, 'PK');
    assert.equal(r.country, 'Pakistan');
    assert.equal(r.city, 'Lahore');
    assert.equal(r.latitude, 31.5);
    assert.equal(r.asn, 17557);
  });

  it('is safe on junk', () => {
    for (const junk of [null, undefined, 'x', 5, [], {}]) {
      const r = normalizeIpinfo(junk);
      assert.equal(r.country_code, null);
      assert.equal(r.asn, null);
    }
    assert.equal(normalizeIpinfo({ loc: '999,999' }).latitude, null);
    assert.equal(normalizeIpinfo({ loc: 'garbage' }).latitude, null);
  });
});

describe('normalizeIp2Location', () => {
  it('maps a DB11 record and drops "not applicable" placeholders', () => {
    const r = normalizeIp2Location(LONDON_DB11);
    assert.equal(r.country_code, 'GB');
    assert.equal(r.region, 'England');
    assert.equal(r.city, 'London');
    assert.equal(r.postal_code, 'EC1A');
    assert.equal(r.latitude, 51.50853);
    assert.equal(r.utc_offset, '+00:00');
    assert.equal(r.timezone, null);
    assert.equal(r.isp, null);
    assert.equal(r.asn, null);
    assert.equal(r.organization, null);
  });

  it('treats sentinel strings and 0,0 coordinates as missing', () => {
    const r = normalizeIp2Location({
      countryShort: '-',
      countryLong: '-',
      region: '-',
      city: '-',
      latitude: 0,
      longitude: 0,
      zipCode: '-',
      timeZone: '-',
    });
    assert.equal(r.country_code, null);
    assert.equal(r.latitude, null);
    assert.equal(r.longitude, null);
    const bad = normalizeIp2Location({ countryShort: 'INVALID_IP_ADDRESS', city: 'IPV6_NOT_SUPPORTED', region: NA });
    assert.equal(bad.country_code, null);
    assert.equal(bad.city, null);
    assert.equal(bad.region, null);
  });

  it('parses database dates', () => {
    assert.equal(ip2locationDate('2026.10.1'), '2026-10-01');
    assert.equal(ip2locationDate('2026.12.31'), '2026-12-31');
    assert.equal(ip2locationDate('garbage'), null);
    assert.equal(ip2locationDate('2026.13.1'), null);
  });
});

describe('Ip2LocationProvider (stubbed library)', () => {
  const file = path.join(os.tmpdir(), `ipa-ip2-${process.pid}.BIN`);
  fs.writeFileSync(file, 'x');

  it('returns normalised data and metadata', async () => {
    const p = new Ip2LocationProvider(file, silent, fakeIp2Location(LONDON_DB11));
    await p.init();
    const r = await p.lookup('81.2.69.142');
    assert.equal(r.status, 'ok');
    assert.equal(r.data?.city, 'London');
    assert.equal(p.info().database_date, '2026-10-01');
    assert.equal(p.info().loaded, true);
    assert.equal(p.info().warning, null);
  });

  it('flags a database that cannot resolve anything', async () => {
    const p = new Ip2LocationProvider(file, silent, fakeIp2Location({ countryShort: 'INVALID_IP_ADDRESS' }));
    await p.init();
    assert.equal((await p.lookup('8.8.8.8')).status, 'no_data');
    assert.match(p.info().warning ?? '', /could not resolve/);
  });

  it('rejects files the library cannot read', async () => {
    const p = new Ip2LocationProvider(file, silent, () => ({
      open() {},
      close: () => 0,
      getAll: () => ({}),
      getPackageVersion: () => 0,
      getDatabaseVersion: () => '',
    }));
    await p.init();
    assert.equal(p.info().loaded, false);
    assert.equal((await p.lookup('8.8.8.8')).status, 'unavailable');
  });

  it('is unavailable when the file is missing', async () => {
    const p = new Ip2LocationProvider('/nope.BIN', silent, fakeIp2Location(LONDON_DB11));
    await p.init();
    assert.equal((await p.lookup('8.8.8.8')).status, 'unavailable');
  });
});
