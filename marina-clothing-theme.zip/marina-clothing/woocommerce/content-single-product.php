<?php
/**
 * Single product layout: editorial gallery + sticky purchasing console.
 *
 * Override of woocommerce/templates/content-single-product.php
 * All standard hooks still fire, so extensions keep working.
 *
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
    echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    return;
}
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'single-product-layout', $product ); ?>>

    <div class="container product-topbar">
        <?php woocommerce_breadcrumb(); ?>
        <div class="product-topbar__meta">
            <?php if ( $product->get_sku() ) : ?>
                <?php /* translators: %s: SKU */ ?>
                <span class="product-topbar__ref"><span class="dot"></span><?php echo esc_html( sprintf( __( 'Ref: %s', 'marina-clothing' ), $product->get_sku() ) ); ?></span>
                <span class="product-topbar__sep">|</span>
            <?php endif; ?>
            <span><?php echo $product->is_in_stock() ? esc_html__( 'Ready to dispatch', 'marina-clothing' ) : esc_html__( 'Currently sold out', 'marina-clothing' ); ?></span>
        </div>
    </div>

    <section class="container product-main">
        <div class="product-main__gallery">
            <?php
            /**
             * Hook: woocommerce_before_single_product_summary.
             *
             * @hooked marina_single_gallery - 20
             */
            do_action( 'woocommerce_before_single_product_summary' );
            ?>
        </div>

        <div class="summary entry-summary psummary">
            <?php
            /**
             * Hook: woocommerce_single_product_summary.
             *
             * @hooked marina_single_heading - 5
             * @hooked woocommerce_template_single_excerpt - 20
             * @hooked woocommerce_template_single_add_to_cart - 30
             * @hooked marina_single_trust - 35
             * @hooked marina_single_accordions - 45
             * @hooked woocommerce_template_single_sharing - 50
             * @hooked WC_Structured_Data::generate_product_data() - 60
             */
            do_action( 'woocommerce_single_product_summary' );
            ?>
        </div>
    </section>

    <?php
    /**
     * Hook: woocommerce_after_single_product_summary.
     *
     * @hooked marina_complete_the_look - 15
     * @hooked marina_single_reviews - 20
     */
    do_action( 'woocommerce_after_single_product_summary' );
    ?>
</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
