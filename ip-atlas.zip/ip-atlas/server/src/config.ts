import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

/** Project root: server/src (dev) and server/dist (prod) are both two levels below it. */
export const PROJECT_ROOT = path.resolve(here, '..', '..');

// Load <root>/.env if present. Real environment variables always win.
const envFile = path.join(PROJECT_ROOT, '.env');
if (fs.existsSync(envFile)) {
  try {
    process.loadEnvFile(envFile);
  } catch (err) {
    console.error(`Could not read ${envFile}:`, err instanceof Error ? err.message : err);
  }
}

export interface Config {
  nodeEnv: string;
  isProduction: boolean;
  host: string;
  port: number;
  logLevel: string;
  logRequests: boolean;
  webDist: string;
  dataDir: string;
  trustProxy: string;
  clientIpHeader: string | null;
  devClientIp: string | null;
  apiKeys: string[];
  rateLimitAnonymous: number;
  rateLimitKeyed: number;
  rateLimitWindow: string;
  dbReloadIntervalMin: number;
  paths: {
    maxmindCity: string;
    maxmindAsn: string;
    ipinfo: string;
    ip2location: string;
  };
  ipinfo: {
    token: string | null;
    apiUrl: string;
    downloadUrl: string | null;
  };
  maxmind: { accountId: string | null; licenseKey: string | null; downloadUrl: string | null };
  ip2location: { token: string | null; downloadPackage: string; downloadUrl: string | null };
}

function str(env: NodeJS.ProcessEnv, name: string): string | null {
  const v = env[name]?.trim();
  return v ? v : null;
}

function int(env: NodeJS.ProcessEnv, name: string, fallback: number, min: number, max: number): number {
  const raw = str(env, name);
  if (raw === null) return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new Error(`Invalid ${name}="${raw}": expected an integer between ${min} and ${max}.`);
  }
  return n;
}

function bool(env: NodeJS.ProcessEnv, name: string, fallback: boolean): boolean {
  const raw = str(env, name);
  if (raw === null) return fallback;
  if (/^(1|true|yes|on)$/i.test(raw)) return true;
  if (/^(0|false|no|off)$/i.test(raw)) return false;
  throw new Error(`Invalid ${name}="${raw}": expected true or false.`);
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const nodeEnv = str(env, 'NODE_ENV') ?? 'development';
  const dataDir = path.resolve(PROJECT_ROOT, str(env, 'DATA_DIR') ?? 'data');
  const at = (name: string, file: string) => path.resolve(dataDir, str(env, name) ?? file);

  const header = str(env, 'CLIENT_IP_HEADER')?.toLowerCase() ?? null;
  if (header && !/^[a-z0-9-]+$/.test(header)) {
    throw new Error(`Invalid CLIENT_IP_HEADER="${header}": expected a plain header name such as cf-connecting-ip.`);
  }

  const rateLimitWindow = str(env, 'RATE_LIMIT_WINDOW') ?? '1 minute';
  if (!/^\d+\s*(second|minute|hour)s?$/i.test(rateLimitWindow)) {
    throw new Error(`Invalid RATE_LIMIT_WINDOW="${rateLimitWindow}": use e.g. "1 minute" or "30 seconds".`);
  }

  return {
    nodeEnv,
    isProduction: nodeEnv === 'production',
    host: str(env, 'HOST') ?? '0.0.0.0',
    port: int(env, 'PORT', 3000, 1, 65535),
    logLevel: str(env, 'LOG_LEVEL') ?? 'info',
    logRequests: bool(env, 'LOG_REQUESTS', false),
    webDist: path.resolve(PROJECT_ROOT, str(env, 'WEB_DIST') ?? 'web/dist'),
    dataDir,
    trustProxy: str(env, 'TRUST_PROXY') ?? 'loopback,linklocal,uniquelocal',
    clientIpHeader: header,
    devClientIp: str(env, 'DEV_CLIENT_IP'),
    apiKeys: (str(env, 'API_KEYS') ?? '')
      .split(',')
      .map((k) => k.trim())
      .filter(Boolean),
    rateLimitAnonymous: int(env, 'RATE_LIMIT_ANONYMOUS', 60, 1, 1_000_000),
    rateLimitKeyed: int(env, 'RATE_LIMIT_KEYED', 600, 1, 1_000_000),
    rateLimitWindow,
    dbReloadIntervalMin: int(env, 'DB_RELOAD_INTERVAL_MIN', 60, 1, 10_080),
    paths: {
      maxmindCity: at('MAXMIND_CITY_DB', 'GeoLite2-City.mmdb'),
      maxmindAsn: at('MAXMIND_ASN_DB', 'GeoLite2-ASN.mmdb'),
      ipinfo: at('IPINFO_DB', 'ipinfo_lite.mmdb'),
      ip2location: at('IP2LOCATION_DB', 'IP2LOCATION-LITE-DB11.IPV6.BIN'),
    },
    ipinfo: {
      token: str(env, 'IPINFO_TOKEN'),
      apiUrl: str(env, 'IPINFO_API_URL') ?? 'https://api.ipinfo.io/lite/{ip}',
      downloadUrl: str(env, 'IPINFO_DOWNLOAD_URL'),
    },
    maxmind: {
      accountId: str(env, 'MAXMIND_ACCOUNT_ID'),
      licenseKey: str(env, 'MAXMIND_LICENSE_KEY'),
      downloadUrl: str(env, 'MAXMIND_DOWNLOAD_URL'),
    },
    ip2location: {
      token: str(env, 'IP2LOCATION_TOKEN'),
      downloadPackage: str(env, 'IP2LOCATION_PACKAGE') ?? 'DB11LITEBINIPV6',
      downloadUrl: str(env, 'IP2LOCATION_DOWNLOAD_URL'),
    },
  };
}
