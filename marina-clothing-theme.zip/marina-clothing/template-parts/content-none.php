<?php
/**
 * Nothing found.
 */
?>
<div class="empty-state">
    <?php marina_the_icon( 'explore' ); ?>
    <h2 class="empty-state__title"><?php esc_html_e( 'Nothing found', 'marina-clothing' ); ?></h2>
    <p><?php esc_html_e( 'We could not find what you were looking for. Try another search or explore the collection.', 'marina-clothing' ); ?></p>
    <?php if ( marina_is_woocommerce_active() ) : ?>
        <a class="btn btn--primary" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Shop The Collection', 'marina-clothing' ); ?></a>
    <?php endif; ?>
</div>
