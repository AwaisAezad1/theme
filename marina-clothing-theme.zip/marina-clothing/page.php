<?php
/**
 * Pages (including WooCommerce cart, checkout and account pages).
 */

get_header();
?>

<main id="primary" class="site-main">
    <?php
    while ( have_posts() ) {
        the_post();
        get_template_part( 'template-parts/content', 'page' );
    }
    ?>
</main>

<?php
get_footer();
