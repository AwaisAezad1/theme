<?php
/**
 * Home: "Masterpiece Capsule" spotlight on one product.
 */

$marina_product = null;
$marina_id      = absint( marina_opt( 'spotlight_product' ) );

if ( $marina_id ) {
    $marina_product = wc_get_product( $marina_id );
}

if ( ! $marina_product || ! $marina_product->is_visible() ) {
    $marina_list    = marina_showcase_products( 1 );
    $marina_product = $marina_list ? $marina_list[0] : null;
}

if ( ! $marina_product ) {
    return;
}

$marina_img = wp_get_attachment_image_url( $marina_product->get_image_id(), 'large' );
if ( ! $marina_img ) {
    $marina_img = marina_image( 'spotlight' );
}

$marina_desc   = wp_strip_all_tags( $marina_product->get_short_description() ? $marina_product->get_short_description() : $marina_product->get_description() );
$marina_colors = marina_product_colors( $marina_product );
$marina_sizes  = array();

foreach ( $marina_product->get_attributes() as $marina_attr ) {
    if ( preg_match( '/size/i', $marina_attr->get_name() ) ) {
        $marina_sizes = $marina_attr->is_taxonomy()
            ? wc_get_product_terms( $marina_product->get_id(), $marina_attr->get_name(), array( 'fields' => 'names' ) )
            : $marina_attr->get_options();
        break;
    }
}
$marina_count = $marina_product->get_review_count();
?>
<section class="section spotlight">
    <div class="container">
        <div class="spotlight__card">
            <div class="spotlight__media">
                <img src="<?php echo esc_url( $marina_img ); ?>" alt="<?php echo esc_attr( $marina_product->get_name() ); ?>" loading="lazy">
                <span class="badge spotlight__badge"><?php esc_html_e( 'Signature Piece • Best Seller', 'marina-clothing' ); ?></span>
            </div>

            <div class="spotlight__body">
                <div class="spotlight__top">
                    <span class="eyebrow"><?php esc_html_e( 'Masterpiece Capsule', 'marina-clothing' ); ?></span>
                    <?php if ( $marina_count ) : ?>
                        <span class="rating-inline">
                            <?php marina_the_icon( 'star', 'icon--fill' ); ?>
                            <strong><?php echo esc_html( number_format_i18n( (float) $marina_product->get_average_rating(), 1 ) ); ?> / 5.0</strong>
                            <?php /* translators: %s: reviews */ ?>
                            <span><?php echo esc_html( sprintf( _n( '(%s review)', '(%s reviews)', $marina_count, 'marina-clothing' ), $marina_count ) ); ?></span>
                        </span>
                    <?php endif; ?>
                </div>

                <div>
                    <h2 class="spotlight__title"><a href="<?php echo esc_url( $marina_product->get_permalink() ); ?>"><?php echo esc_html( $marina_product->get_name() ); ?></a></h2>
                    <div class="spotlight__price price"><?php echo $marina_product->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                </div>

                <?php if ( $marina_desc ) : ?>
                    <p class="spotlight__desc"><?php echo esc_html( wp_trim_words( $marina_desc, 45 ) ); ?></p>
                <?php endif; ?>

                <?php $marina_points = marina_opt_lines( 'spotlight_points' ); ?>
                <?php if ( $marina_points ) : ?>
                    <ul class="checklist">
                        <?php foreach ( $marina_points as $marina_point ) : ?>
                            <li><?php marina_the_icon( 'check_circle' ); ?><span><?php echo esc_html( $marina_point ); ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <?php if ( $marina_colors ) : ?>
                    <div class="spotlight__option">
                        <div class="spotlight__option-head">
                            <span><?php esc_html_e( 'Colour', 'marina-clothing' ); ?>: <?php echo esc_html( $marina_colors[0]['name'] ); ?></span>
                            <?php /* translators: %d: number of shades */ ?>
                            <span class="muted"><?php echo esc_html( sprintf( _n( '%d shade available', '%d shades available', count( $marina_colors ), 'marina-clothing' ), count( $marina_colors ) ) ); ?></span>
                        </div>
                        <div class="swatch-row">
                            <?php foreach ( array_slice( $marina_colors, 0, 6 ) as $marina_ci => $marina_color ) : ?>
                                <span class="swatch<?php echo 0 === $marina_ci ? ' is-active' : ''; ?>" style="<?php echo $marina_color['hex'] ? 'background:' . esc_attr( $marina_color['hex'] ) : ''; ?>" title="<?php echo esc_attr( $marina_color['name'] ); ?>"></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ( $marina_sizes ) : ?>
                    <div class="spotlight__option">
                        <div class="spotlight__option-head">
                            <span><?php esc_html_e( 'Available Sizes', 'marina-clothing' ); ?></span>
                        </div>
                        <div class="size-row">
                            <?php foreach ( $marina_sizes as $marina_size ) : ?>
                                <a class="size-pill" href="<?php echo esc_url( $marina_product->get_permalink() ); ?>"><?php echo esc_html( $marina_size ); ?></a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="spotlight__cta">
                    <?php marina_add_to_cart_button( $marina_product, 'btn btn--primary btn--block', true ); ?>
                    <?php marina_wishlist_button( $marina_product, 'wishlist-btn--square' ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
