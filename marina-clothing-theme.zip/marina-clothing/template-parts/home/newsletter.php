<?php
/**
 * Newsletter banner ("The Marina Circle"). Also used on the 404 page.
 */
?>
<section class="section newsletter-section">
    <div class="container">
        <div class="newsletter-banner">
            <span class="newsletter-banner__glow" aria-hidden="true"></span>
            <div class="newsletter-banner__copy">
                <span class="eyebrow"><?php marina_the_icon( 'stars' ); ?><?php esc_html_e( 'Private Members Concierge', 'marina-clothing' ); ?></span>
                <h2 class="newsletter-banner__title"><?php echo esc_html( marina_opt( 'newsletter_title' ) ); ?></h2>
                <p class="newsletter-banner__text"><?php echo esc_html( marina_opt( 'newsletter_text' ) ); ?></p>
            </div>
            <div class="newsletter-banner__form">
                <?php marina_newsletter_form( 'banner' ); ?>
                <p class="newsletter-banner__note"><?php marina_the_icon( 'lock' ); ?><?php esc_html_e( 'Unconditional discretion. Strictly quarterly dispatches.', 'marina-clothing' ); ?></p>
            </div>
        </div>
    </div>
</section>
