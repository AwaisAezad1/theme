<?php
/**
 * Theme helper functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Get a theme asset URL.
 */
function marina_asset( $path = '' ) {
    return MARINA_URI . '/assets/' . ltrim( $path, '/' );
}

/**
 * URL of one of the bundled editorial images (assets/images/*.jpg).
 */
function marina_image( $name ) {
    $file = MARINA_DIR . '/assets/images/' . $name . '.jpg';
    $url  = marina_asset( 'images/' . $name . '.jpg' );

    return file_exists( $file ) ? add_query_arg( 'v', filemtime( $file ), $url ) : $url;
}

/**
 * Check whether WooCommerce is active.
 */
function marina_is_woocommerce_active() {
    return class_exists( 'WooCommerce' );
}

/**
 * Material Symbols icon markup.
 *
 * Every icon name used must also be listed in marina_icon_names() so that the
 * subsetted icon font contains its glyph.
 */
function marina_icon( $name, $class = '' ) {
    return sprintf(
        '<span class="icon %1$s" aria-hidden="true">%2$s</span>',
        esc_attr( $class ),
        esc_html( $name )
    );
}

/**
 * Echo an icon.
 */
function marina_the_icon( $name, $class = '' ) {
    echo marina_icon( $name, $class ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Icon names used across the theme (keeps the Google icon font request tiny).
 */
function marina_icon_names() {
    $icons = array(
        'add', 'add_shopping_cart', 'arrow_back', 'arrow_forward', 'auto_awesome', 'calendar_today',
        'check', 'check_circle', 'checkroom', 'chevron_left', 'chevron_right', 'close', 'eco',
        'expand_more', 'favorite', 'fullscreen', 'history_edu', 'inventory_2', 'keyboard_arrow_down',
        'language', 'local_shipping', 'lock', 'mail', 'menu', 'north_east', 'person', 'precision_manufacturing',
        'published_with_changes', 'remove', 'search', 'shopping_bag', 'star', 'stars', 'straighten',
        'temp_preferences_custom', 'verified', 'zoom_in', 'chat_bubble', 'delete', 'sell', 'schedule',
        'tune', 'grid_view', 'explore', 'edit',
    );

    $icons = array_unique( apply_filters( 'marina_icon_names', $icons ) );
    sort( $icons );

    return $icons;
}

/**
 * Best-effort colour for a swatch, from an attribute term name.
 */
function marina_color_from_name( $name ) {
    $map = array(
        'terracotta' => '#8c4e32',
        'rust'       => '#8c4e32',
        'navy'       => '#1a242f',
        'blue'       => '#3b5b7a',
        'sand'       => '#e5dfd3',
        'beige'      => '#e5dfd3',
        'oat'        => '#ebe8e3',
        'cream'      => '#f6f3ee',
        'white'      => '#faf7f2',
        'salt'       => '#faf7f2',
        'sage'       => '#7d8f79',
        'olive'      => '#3c4b3a',
        'green'      => '#4f6b4a',
        'black'      => '#1c1c19',
        'grey'       => '#9a9ca0',
        'gray'       => '#9a9ca0',
        'red'        => '#a33a2c',
        'pink'       => '#e8b4a8',
        'yellow'     => '#e2c26b',
        'orange'     => '#d98b4f',
        'brown'      => '#6b4a32',
        'purple'     => '#6d5677',
    );

    $needle = strtolower( $name );

    foreach ( $map as $key => $hex ) {
        if ( false !== strpos( $needle, $key ) ) {
            return $hex;
        }
    }

    if ( preg_match( '/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i', $needle ) ) {
        return '#' . ltrim( $needle, '#' );
    }

    return '';
}
