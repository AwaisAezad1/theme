import type { Config } from '../config.js';
import { Ip2LocationProvider } from './ip2location.js';
import { IpinfoProvider } from './ipinfo.js';
import { MaxmindProvider } from './maxmind.js';
import {
  PROVIDER_IDS,
  type GeoProvider,
  type ProviderId,
  type ProviderInfo,
  type ProviderResult,
} from './types.js';

export type Logger = { info: (m: string) => void; warn: (m: string) => void; error: (m: string) => void };

export class ProviderRegistry {
  private providers: Map<ProviderId, GeoProvider>;
  private timer: NodeJS.Timeout | null = null;

  constructor(providers: GeoProvider[], private log: Logger) {
    this.providers = new Map(providers.map((p) => [p.id, p]));
  }

  static fromConfig(config: Config, log: Logger): ProviderRegistry {
    return new ProviderRegistry(
      [
        new MaxmindProvider(config.paths.maxmindCity, config.paths.maxmindAsn, log),
        new IpinfoProvider(
          config.paths.ipinfo,
          { token: config.ipinfo.token, url: config.ipinfo.apiUrl },
          log,
        ),
        new Ip2LocationProvider(config.paths.ip2location, log),
      ],
      log,
    );
  }

  async init(): Promise<void> {
    await Promise.all([...this.providers.values()].map((p) => p.init()));
  }

  /** Periodically pick up database files replaced by the update script. */
  startAutoReload(intervalMin: number): void {
    this.stopAutoReload();
    this.timer = setInterval(() => {
      void this.reload();
    }, intervalMin * 60_000);
    this.timer.unref();
  }

  stopAutoReload(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  async reload(): Promise<void> {
    for (const p of this.providers.values()) {
      try {
        await p.reloadIfChanged();
      } catch (err) {
        this.log.error(`Reloading ${p.id} failed: ${err instanceof Error ? err.message : err}`);
      }
    }
  }

  /** Look the IP up in the requested providers (default: all) concurrently. Never throws. */
  async lookup(ip: string, only?: readonly ProviderId[]): Promise<Record<ProviderId, ProviderResult | null>> {
    const wanted = new Set<ProviderId>(only && only.length ? only : PROVIDER_IDS);
    const out = { maxmind: null, ipinfo: null, ip2location: null } as Record<ProviderId, ProviderResult | null>;
    await Promise.all(
      PROVIDER_IDS.map(async (id) => {
        if (!wanted.has(id)) return;
        const provider = this.providers.get(id);
        if (!provider) {
          out[id] = { status: 'unavailable', data: null, message: 'Provider is not configured.' };
          return;
        }
        try {
          out[id] = await provider.lookup(ip);
        } catch (err) {
          out[id] = { status: 'error', data: null, message: err instanceof Error ? err.message : 'Lookup failed.' };
        }
      }),
    );
    return out;
  }

  info(): ProviderInfo[] {
    return PROVIDER_IDS.map((id) => this.providers.get(id)?.info()).filter((i): i is ProviderInfo => !!i);
  }

  close(): void {
    this.stopAutoReload();
    for (const p of this.providers.values()) p.close();
  }
}
