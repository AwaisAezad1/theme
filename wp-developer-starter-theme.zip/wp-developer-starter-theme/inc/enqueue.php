<?php
/**
 * Styles and scripts.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function wds_enqueue_assets() {
    wp_enqueue_style(
        'wds-style',
        get_stylesheet_uri(),
        array(),
        WDS_VERSION
    );

    wp_enqueue_style(
        'wds-custom',
        WDS_URI . '/assets/css/custom.css',
        array( 'wds-style' ),
        WDS_VERSION
    );

    wp_enqueue_script(
        'wds-main',
        WDS_URI . '/assets/js/main.js',
        array(),
        WDS_VERSION,
        true
    );

    /*
     * AJAX configuration available to main.js.
     */
    wp_localize_script(
        'wds-main',
        'wdsData',
        array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'wds_nonce' ),
            'homeUrl' => home_url( '/' ),
        )
    );
}
add_action( 'wp_enqueue_scripts', 'wds_enqueue_assets' );

/**
 * Admin-only assets.
 *
 * Add admin CSS/JS here when your project needs it.
 */
function wds_admin_assets() {
    // wp_enqueue_style(
    //     'wds-admin',
    //     WDS_URI . '/assets/css/admin.css',
    //     array(),
    //     WDS_VERSION
    // );
}
add_action( 'admin_enqueue_scripts', 'wds_admin_assets' );
