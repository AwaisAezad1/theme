import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import App from './App';
import { blank, jsonResponse, londonResponse, statusResponse } from './test/fixtures';
import type { LookupResponse } from './types';

type Handler = (url: string) => Response | Promise<Response>;
function mockFetch(handler: Handler) {
  return vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
    const url = String(input);
    if (url === '/api/v1/status') return jsonResponse(statusResponse);
    return handler(url);
  });
}

beforeEach(() => window.history.replaceState(null, '', '/'));
afterEach(() => vi.restoreAllMocks());

describe('App', () => {
  it('shows the visitor IP on load with all provider columns', async () => {
    mockFetch(() => jsonResponse(londonResponse()));
    render(<App />);
    expect(await screen.findByRole('heading', { name: '81.2.69.142' })).toBeInTheDocument();
    expect(screen.getByText('Your IP address')).toBeInTheDocument();
    expect(screen.getByText('London, England, United Kingdom')).toBeInTheDocument();
    const table = screen.getByRole('table');
    expect(within(table).getByText('MaxMind')).toBeInTheDocument();
    expect(within(table).getByText('IPinfo')).toBeInTheDocument();
    expect(within(table).getByText('IP2Location')).toBeInTheDocument();
    expect(within(table).getAllByText('Database not installed').length).toBeGreaterThan(0);
    expect(screen.getByText('All 3 providers agree on the country')).toBeInTheDocument();
  });

  it('never shows made-up data while loading', async () => {
    mockFetch(() => new Promise<Response>(() => undefined));
    render(<App />);
    expect(screen.getByLabelText('Loading results')).toBeInTheDocument();
    expect(screen.queryByText('8.8.8.8')).not.toBeInTheDocument();
  });

  it('looks up a typed address and updates the URL', async () => {
    const fetchMock = mockFetch((url) => jsonResponse(londonResponse({ ip: url.includes('8.8.8.8') ? '8.8.8.8' : '81.2.69.142' })));
    render(<App />);
    await screen.findByRole('heading', { name: '81.2.69.142' });
    const user = userEvent.setup();
    await user.type(screen.getByLabelText('IP address'), ' 8.8.8.8 ');
    await user.click(screen.getByRole('button', { name: 'Look up' }));
    expect(await screen.findByRole('heading', { name: '8.8.8.8' })).toBeInTheDocument();
    expect(screen.getByText('IP address', { selector: 'p' })).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledWith('/api/v1/ip/8.8.8.8', expect.anything());
    expect(window.location.search).toBe('?ip=8.8.8.8');
  });

  it('starts from ?ip= in the address bar', async () => {
    window.history.replaceState(null, '', '/?ip=1.1.1.1');
    const fetchMock = mockFetch(() => jsonResponse(londonResponse({ ip: '1.1.1.1' })));
    render(<App />);
    await screen.findByRole('heading', { name: '1.1.1.1' });
    expect(screen.getByLabelText('IP address')).toHaveValue('1.1.1.1');
    expect(fetchMock).toHaveBeenCalledWith('/api/v1/ip/1.1.1.1', expect.anything());
  });

  it('shows validation errors from the API and keeps the previous result', async () => {
    mockFetch((url) =>
      url.includes('bad')
        ? jsonResponse({ error: { code: 'invalid_ip', message: 'Enter a valid IPv4 or IPv6 address.', status: 400 } }, 400)
        : jsonResponse(londonResponse()),
    );
    render(<App />);
    await screen.findByRole('heading', { name: '81.2.69.142' });
    const user = userEvent.setup();
    await user.type(screen.getByLabelText('IP address'), 'bad');
    await user.click(screen.getByRole('button', { name: 'Look up' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Enter a valid IPv4 or IPv6 address.');
    expect(screen.getByRole('heading', { name: '81.2.69.142' })).toBeInTheDocument();
  });

  it('explains private addresses instead of showing empty data', async () => {
    const priv: LookupResponse = {
      ...londonResponse({ ip: '192.168.1.1', is_public: false, range: 'private', summary: null }),
      notice: '192.168.1.1 is a private address, so it has no public geolocation data.',
      providers: { maxmind: { status: 'skipped', data: null }, ipinfo: { status: 'skipped', data: null }, ip2location: { status: 'skipped', data: null } },
    };
    mockFetch(() => jsonResponse(priv));
    render(<App />);
    expect(await screen.findByText(/is a private address/)).toBeInTheDocument();
    expect(screen.queryByRole('table')).not.toBeInTheDocument();
  });

  it('flags providers that disagree', async () => {
    const data = londonResponse();
    data.providers.ipinfo = { status: 'ok', data: { ...blank, country_code: 'FR', country: 'France' } };
    data.summary!.country_agreement = { matching: 1, total: 2 };
    mockFetch(() => jsonResponse(data));
    render(<App />);
    expect(await screen.findByText('1 of 2 providers agree on the country')).toBeInTheDocument();
    expect(within(screen.getByRole('table')).getByText('differs')).toBeInTheDocument();
  });

  it('shows a fallback message when the first lookup fails', async () => {
    mockFetch(() => new Response('oops', { status: 502 }));
    render(<App />);
    await waitFor(() => expect(screen.getByText(/couldn’t load your IP details/)).toBeInTheDocument());
    expect(screen.getByRole('alert')).toHaveTextContent(/temporarily unavailable/);
  });

  it('ignores a slow earlier response that finishes after a newer one (race)', async () => {
    let releaseFirst: (r: Response) => void = () => undefined;
    let calls = 0;
    mockFetch((url) => {
      calls++;
      if (calls === 1) return new Promise<Response>((resolve) => { releaseFirst = resolve; });
      return jsonResponse(londonResponse({ ip: url.includes('9.9.9.9') ? '9.9.9.9' : '0.0.0.0' }));
    });
    render(<App />);
    const user = userEvent.setup();
    // The first (slow) lookup is still pending; submitting with Enter must supersede it.
    await user.type(screen.getByLabelText('IP address'), '9.9.9.9{Enter}');
    expect(await screen.findByRole('heading', { name: '9.9.9.9' })).toBeInTheDocument();
    releaseFirst(jsonResponse(londonResponse({ ip: '81.2.69.142' })));
    await new Promise((r) => setTimeout(r, 50));
    expect(screen.getByRole('heading', { name: '9.9.9.9' })).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: '81.2.69.142' })).not.toBeInTheDocument();
  });

  it('renders the API docs with the current origin and live rate limit', async () => {
    mockFetch(() => jsonResponse(londonResponse()));
    render(<App />);
    await screen.findByRole('heading', { name: '81.2.69.142' });
    expect(await screen.findByText(/60 requests per minute per IP address/)).toBeInTheDocument();
    expect(screen.getByRole('tabpanel')).toHaveTextContent(`${window.location.origin}/api/v1/ip/8.8.8.8`);
    await userEvent.setup().click(screen.getByRole('tab', { name: 'Python' }));
    expect(screen.getByRole('tabpanel')).toHaveTextContent('import requests');
  });
});
