<?php
/**
 * Product card used in every product loop (shop, categories, home, search).
 *
 * Override of woocommerce/templates/content-product.php
 *
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
    return;
}

$marina_badge   = marina_product_badge( $product );
$marina_colors  = marina_product_colors( $product );
$marina_gallery = $product->get_gallery_image_ids();
$marina_alt_img = $marina_gallery ? wp_get_attachment_image( $marina_gallery[0], 'woocommerce_thumbnail', false, array( 'class' => 'product-card__img product-card__img--alt', 'alt' => '', 'loading' => 'lazy' ) ) : '';
?>
<li <?php wc_product_class( 'product-card', $product ); ?> data-cats="<?php echo esc_attr( marina_product_cat_slugs( $product ) ); ?>">
    <div class="product-card__media">
        <a class="product-card__link" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
            <?php
            echo $product->get_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                'woocommerce_thumbnail',
                array(
                    'class'   => 'product-card__img',
                    'loading' => 'lazy',
                )
            );
            echo $marina_alt_img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            ?>
        </a>

        <?php if ( $marina_badge ) : ?>
            <span class="badge product-card__badge <?php echo esc_attr( $marina_badge[1] ); ?>"><?php echo esc_html( $marina_badge[0] ); ?></span>
        <?php endif; ?>

        <?php marina_wishlist_button( $product, 'product-card__wish' ); ?>

        <div class="product-card__quick">
            <?php marina_add_to_cart_button( $product, 'product-card__quick-btn', true ); ?>
        </div>
    </div>

    <div class="product-card__body">
        <div>
            <?php marina_rating_inline( $product ); ?>
            <h3 class="product-card__title woocommerce-loop-product__title">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h3>
            <?php $marina_sub = marina_product_subtitle( $product ); ?>
            <?php if ( $marina_sub ) : ?>
                <p class="product-card__sub"><?php echo esc_html( $marina_sub ); ?></p>
            <?php endif; ?>
        </div>

        <div class="product-card__foot">
            <span class="price product-card__price"><?php echo $product->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
            <?php if ( $marina_colors ) : ?>
                <span class="swatch-dots" aria-label="<?php echo esc_attr( implode( ', ', wp_list_pluck( $marina_colors, 'name' ) ) ); ?>">
                    <?php foreach ( array_slice( $marina_colors, 0, 4 ) as $marina_i => $marina_color ) : ?>
                        <span class="swatch-dot<?php echo 0 === $marina_i ? ' is-active' : ''; ?>" style="<?php echo $marina_color['hex'] ? 'background:' . esc_attr( $marina_color['hex'] ) : ''; ?>"></span>
                    <?php endforeach; ?>
                </span>
            <?php endif; ?>
        </div>
    </div>
</li>
