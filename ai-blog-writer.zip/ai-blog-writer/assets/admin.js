(function () {
  'use strict';

  var cfg = window.AIBW || {};
  var t = cfg.i18n || {};

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function post(action, data) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('nonce', cfg.nonce);
    Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(cfg.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function (r) { return r.text(); })
      .then(function (txt) {
        try { return JSON.parse(txt); } catch (e) { throw new Error(t.badResponse); }
      });
  }

  /* ---------------------------------------------------------------- */
  /* Write a Blog page                                                */
  /* ---------------------------------------------------------------- */
  function initWriter() {
    var topicEl = $('#aibw-topic');
    var genBtn = $('#aibw-generate');
    var result = $('#aibw-result');
    var done = $('#aibw-done');
    var state = { provider: '', topic: '' };

    function setStatus(id, msg, isError) {
      var el = $(id);
      if (!el) { return; }
      el.textContent = msg || '';
      el.className = 'aibw-status' + (isError ? ' is-error' : '');
    }

    function busy(on) {
      $$('#aibw-generate, #aibw-publish, #aibw-draft, #aibw-regenerate').forEach(function (b) { b.disabled = on; });
      $$('#aibw-spinner, #aibw-spinner2').forEach(function (s) { s.classList.toggle('is-active', on); });
    }

    // Highlight the chosen AI card.
    $$('input[name="aibw_provider"]').forEach(function (radio) {
      radio.addEventListener('change', function () {
        $$('.aibw-provider').forEach(function (l) { l.classList.remove('is-selected'); });
        if (radio.checked) { radio.closest('.aibw-provider').classList.add('is-selected'); }
      });
    });

    function generate() {
      var topic = topicEl.value.trim();
      var chosen = $('input[name="aibw_provider"]:checked');
      setStatus('#aibw-status', '');
      setStatus('#aibw-status2', '');
      if (topic.length < 3) { setStatus('#aibw-status', t.needTopic, true); topicEl.focus(); return; }
      if (!chosen) { setStatus('#aibw-status', 'Please choose an AI that is connected.', true); return; }

      busy(true);
      setStatus('#aibw-status', t.writing);
      setStatus('#aibw-status2', t.writing);
      done.hidden = true;

      post('aibw_generate', {
        topic: topic,
        provider: chosen.value,
        tone: $('#aibw-tone').value,
        length: $('#aibw-length').value,
        language: $('#aibw-language').value,
        notes: $('#aibw-notes').value
      }).then(function (res) {
        busy(false);
        if (!res.success) {
          var m = (res.data && res.data.message) || 'Something went wrong.';
          setStatus('#aibw-status', m, true);
          setStatus('#aibw-status2', m, true);
          return;
        }
        var d = res.data;
        state.provider = d.provider;
        state.topic = topic;
        $('#aibw-title').value = d.title;
        $('#aibw-content').innerHTML = d.content; // Already sanitised on the server.
        $('#aibw-by-name').textContent = d.provider_label;
        var notice = $('#aibw-notice');
        if (d.notice) { $('p', notice).textContent = d.notice; notice.hidden = false; } else { notice.hidden = true; }
        setStatus('#aibw-status', '');
        setStatus('#aibw-status2', '');
        result.hidden = false;
        result.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }).catch(function (err) {
        busy(false);
        setStatus('#aibw-status', err.message, true);
        setStatus('#aibw-status2', err.message, true);
      });
    }

    function publish(status) {
      var title = $('#aibw-title').value.trim();
      var content = $('#aibw-content').innerHTML.trim();
      setStatus('#aibw-status2', '');
      if (!title) { setStatus('#aibw-status2', t.needTitle, true); return; }
      if (!$('#aibw-content').textContent.trim()) { setStatus('#aibw-status2', t.needContent, true); return; }

      busy(true);
      setStatus('#aibw-status2', t.saving);
      var sticky = $('#aibw-sticky');

      post('aibw_publish', {
        status: status,
        title: title,
        content: content,
        topic: state.topic,
        provider: state.provider,
        sticky: sticky && sticky.checked ? '1' : '',
        category: $('#aibw-category').value
      }).then(function (res) {
        if (!res.success) {
          busy(false);
          setStatus('#aibw-status2', (res.data && res.data.message) || 'Something went wrong.', true);
          return;
        }
        var d = res.data;
        $('#aibw-done-msg').textContent = d.message;
        $('#aibw-done-view').href = d.view_url;
        $('#aibw-done-home').href = d.home_url;
        $('#aibw-done-home').hidden = d.status !== 'publish';
        $('#aibw-done-edit').href = d.edit_url;
        result.hidden = true;
        done.hidden = false;
        busy(false);
        done.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }).catch(function (err) {
        busy(false);
        setStatus('#aibw-status2', err.message, true);
      });
    }

    genBtn.addEventListener('click', generate);
    $('#aibw-regenerate').addEventListener('click', generate);
    var pub = $('#aibw-publish');
    if (pub) { pub.addEventListener('click', function () { publish('publish'); }); }
    $('#aibw-draft').addEventListener('click', function () { publish('draft'); });

    $('#aibw-another').addEventListener('click', function () {
      topicEl.value = '';
      done.hidden = true;
      result.hidden = true;
      window.scrollTo({ top: 0, behavior: 'smooth' });
      topicEl.focus();
    });
  }

  /* ---------------------------------------------------------------- */
  /* AI Accounts page                                                 */
  /* ---------------------------------------------------------------- */
  function initAccounts() {
    $$('.aibw-account').forEach(function (card) {
      var id = card.getAttribute('data-provider');
      var btn = $('.aibw-test', card);
      var spin = $('.spinner', card);
      var out = $('.aibw-test-result', card);
      var keyEl = $('input[type="password"]', card);
      var modelEl = $('input[list]', card);
      var list = $('datalist', card);

      btn.addEventListener('click', function () {
        out.textContent = t.testing;
        out.className = 'aibw-test-result';
        spin.classList.add('is-active');
        btn.disabled = true;

        post('aibw_test', { provider: id, key: keyEl.value, model: modelEl.value })
          .then(function (res) {
            spin.classList.remove('is-active');
            btn.disabled = false;
            if (!res.success) {
              out.textContent = (res.data && res.data.message) || 'Failed.';
              out.className = 'aibw-test-result is-error';
              return;
            }
            out.textContent = res.data.message;
            out.className = 'aibw-test-result is-ok';
            list.innerHTML = '';
            (res.data.models || []).forEach(function (m) {
              var o = document.createElement('option');
              o.value = m;
              list.appendChild(o);
            });
          })
          .catch(function (err) {
            spin.classList.remove('is-active');
            btn.disabled = false;
            out.textContent = err.message;
            out.className = 'aibw-test-result is-error';
          });
      });
    });
  }

  if ($('#aibw-form')) { initWriter(); }
  if ($('.aibw-account')) { initAccounts(); }
})();
