<?php
/**
 * Display single product reviews (comments) — Marina "Customer Reviews" layout.
 *
 * Override of woocommerce/templates/single-product-reviews.php
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-reviews.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 11.2.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! comments_open() ) {
	return;
}

$marina_count   = $product->get_review_count();
$marina_average = (float) $product->get_average_rating();
$marina_counts  = $product->get_rating_counts();
$marina_total   = array_sum( $marina_counts );
?>
<div id="reviews" class="woocommerce-Reviews review-ledger">
	<aside class="review-ledger__summary">
		<span class="eyebrow"><?php esc_html_e( 'What Our Customers Say', 'marina-clothing' ); ?></span>
		<h2 class="review-ledger__title woocommerce-Reviews-title"><?php esc_html_e( 'Customer Reviews', 'marina-clothing' ); ?></h2>

		<?php if ( $marina_count && wc_review_ratings_enabled() ) : ?>
			<div class="review-ledger__score">
				<span class="review-ledger__avg"><?php echo esc_html( number_format_i18n( $marina_average, 1 ) ); ?></span>
				<div>
					<?php marina_stars( $marina_average ); ?>
					<?php /* translators: %s: number of reviews */ ?>
					<p class="review-ledger__based"><?php echo esc_html( sprintf( _n( 'Based on %s client review', 'Based on %s client reviews', $marina_count, 'marina-clothing' ), number_format_i18n( $marina_count ) ) ); ?></p>
				</div>
			</div>

			<ul class="rating-bars">
				<?php for ( $marina_star = 5; $marina_star >= 1; $marina_star-- ) : ?>
					<?php
					$marina_n   = isset( $marina_counts[ $marina_star ] ) ? (int) $marina_counts[ $marina_star ] : 0;
					$marina_pct = $marina_total ? round( $marina_n / $marina_total * 100 ) : 0;
					?>
					<li>
						<span class="rating-bars__label"><?php echo esc_html( $marina_star ); ?>&#9733;</span>
						<span class="rating-bars__track"><span style="width:<?php echo esc_attr( $marina_pct ); ?>%"></span></span>
						<span class="rating-bars__n"><?php echo esc_html( $marina_n ); ?></span>
					</li>
				<?php endfor; ?>
			</ul>
		<?php else : ?>
			<p class="review-ledger__based"><?php esc_html_e( 'No reviews yet — share how this piece wears for you.', 'marina-clothing' ); ?></p>
		<?php endif; ?>

		<?php if ( have_comments() ) : ?>
			<button type="button" class="btn btn--primary btn--block" data-review-toggle aria-controls="review_form_wrapper" aria-expanded="false"><?php esc_html_e( 'Write A Review', 'marina-clothing' ); ?></button>
		<?php endif; ?>
	</aside>

	<div class="review-ledger__main">
	<?php if ( get_option( 'woocommerce_review_rating_verification_required' ) === 'no' || wc_customer_bought_product( '', get_current_user_id(), $product->get_id() ) ) : ?>
			<div id="review_form_wrapper" class="review-form-card" <?php echo have_comments() ? 'hidden' : ''; ?>>
				<div id="review_form">
					<?php
					$commenter    = wp_get_current_commenter();
					$comment_form = array(
						/* translators: %s is product title */
						'title_reply'         => have_comments() ? esc_html__( 'Add a review', 'woocommerce' ) : sprintf( esc_html__( 'Be the first to review &ldquo;%s&rdquo;', 'woocommerce' ), get_the_title() ),
						/* translators: %s is product title */
						'title_reply_to'      => esc_html__( 'Leave a Reply to %s', 'woocommerce' ),
						'title_reply_before'  => '<span id="reply-title" class="comment-reply-title" role="heading" aria-level="3">',
						'title_reply_after'   => '</span>',
						'comment_notes_after' => '',
						'label_submit'        => esc_html__( 'Submit Review', 'marina-clothing' ),
						'logged_in_as'        => '',
						'comment_field'       => '',
					);

					$name_email_required = (bool) get_option( 'require_name_email', 1 );
					$fields              = array(
						'author' => array(
							'label'        => __( 'Name', 'woocommerce' ),
							'type'         => 'text',
							'value'        => $commenter['comment_author'],
							'required'     => $name_email_required,
							'autocomplete' => 'name',
						),
						'email'  => array(
							'label'        => __( 'Email', 'woocommerce' ),
							'type'         => 'email',
							'value'        => $commenter['comment_author_email'],
							'required'     => $name_email_required,
							'autocomplete' => 'email',
						),
					);

					$comment_form['fields'] = array();

					foreach ( $fields as $key => $field ) {
						$field_html  = '<p class="comment-form-' . esc_attr( $key ) . '">';
						$field_html .= '<label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] );

						if ( $field['required'] ) {
							$field_html .= '&nbsp;<span class="required">*</span>';
						}

						$field_html .= '</label><input id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" type="' . esc_attr( $field['type'] ) . '" autocomplete="' . esc_attr( $field['autocomplete'] ) . '" value="' . esc_attr( $field['value'] ) . '" size="30" ' . ( $field['required'] ? 'required' : '' ) . ' /></p>';

						$comment_form['fields'][ $key ] = $field_html;
					}

					$account_page_url = wc_get_page_permalink( 'myaccount' );
					if ( $account_page_url ) {
						/* translators: %s opening and closing link tags respectively */
						$comment_form['must_log_in'] = '<p class="must-log-in">' . sprintf( esc_html__( 'You must be %1$slogged in%2$s to post a review.', 'woocommerce' ), '<a href="' . esc_url( $account_page_url ) . '">', '</a>' ) . '</p>';
					}

					if ( wc_review_ratings_enabled() ) {
						$comment_form['comment_field'] = '<div class="comment-form-rating"><label for="rating" id="comment-form-rating-label">' . esc_html__( 'Your rating', 'woocommerce' ) . ( wc_review_ratings_required() ? '&nbsp;<span class="required">*</span>' : '' ) . '</label><select name="rating" id="rating" required>
							<option value="">' . esc_html__( 'Rate&hellip;', 'woocommerce' ) . '</option>
							<option value="5">' . esc_html__( 'Perfect', 'woocommerce' ) . '</option>
							<option value="4">' . esc_html__( 'Good', 'woocommerce' ) . '</option>
							<option value="3">' . esc_html__( 'Average', 'woocommerce' ) . '</option>
							<option value="2">' . esc_html__( 'Not that bad', 'woocommerce' ) . '</option>
							<option value="1">' . esc_html__( 'Very poor', 'woocommerce' ) . '</option>
						</select></div>';
					}

					$comment_form['comment_field'] .= '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Your review', 'woocommerce' ) . '&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>';

					comment_form( apply_filters( 'woocommerce_product_review_comment_form_args', $comment_form ) );
					?>
				</div>
			</div>
		<?php else : ?>
			<p class="woocommerce-verification-required"><?php esc_html_e( 'Only logged in customers who have purchased this product may leave a review.', 'woocommerce' ); ?></p>
		<?php endif; ?>


		<div id="comments">
		<?php if ( have_comments() ) : ?>
				<ol class="commentlist">
					<?php wp_list_comments( apply_filters( 'woocommerce_product_review_list_args', array( 'callback' => 'woocommerce_comments' ) ) ); ?>
				</ol>

				<?php
				if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
					echo '<nav class="woocommerce-pagination">';
					paginate_comments_links(
						apply_filters(
							'woocommerce_comment_pagination_args',
							array(
								'prev_text' => is_rtl() ? '&rarr;' : '&larr;',
								'next_text' => is_rtl() ? '&larr;' : '&rarr;',
								'type'      => 'list',
							)
						)
					);
					echo '</nav>';
				endif;
				?>
			<?php else : ?>
				<p class="woocommerce-noreviews"><?php esc_html_e( 'There are no reviews yet.', 'woocommerce' ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</div>
