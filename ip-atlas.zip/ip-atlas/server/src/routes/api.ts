import { createHash } from 'node:crypto';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import type { Config } from '../config.js';
import { parseIp, type ParsedIp } from '../lib/ip.js';
import type { ProviderRegistry } from '../providers/registry.js';
import { PROVIDER_IDS, type ProviderId } from '../providers/types.js';
import { lookupIp, type StatusResponse } from '../services/lookup.js';

export interface ApiDeps {
  config: Config;
  registry: ProviderRegistry;
  isTrustedProxy: (address: string | undefined) => boolean;
}

declare module 'fastify' {
  interface FastifyRequest {
    /** Set when the request carried a valid API key (a hash, never the key itself). */
    apiKeyId: string | null;
  }
}

export class ApiError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string,
  ) {
    super(message);
  }
}

const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');

function headerValue(req: FastifyRequest, name: string): string | null {
  const v = req.headers[name];
  const s = Array.isArray(v) ? v[0] : v;
  return s?.trim() ? s.trim() : null;
}

export async function apiRoutes(app: FastifyInstance, deps: ApiDeps): Promise<void> {
  const { config, registry, isTrustedProxy } = deps;
  const validKeyHashes = new Set(config.apiKeys.map(sha256));
  const startedAt = Date.now();

  /** The visitor's IP as seen by the server, honouring trusted proxies. */
  function clientIp(req: FastifyRequest): ParsedIp | null {
    if (config.devClientIp && !config.isProduction) return parseIp(config.devClientIp);

    // A CDN header such as CF-Connecting-IP is only believed when the connection itself comes from a trusted proxy.
    if (config.clientIpHeader && isTrustedProxy(req.socket.remoteAddress)) {
      const raw = headerValue(req, config.clientIpHeader);
      const parsed = raw ? parseIp(raw.split(',')[0] ?? '') : null;
      if (parsed) return parsed;
    }
    return parseIp(req.ip);
  }

  await app.register(cors, {
    origin: '*',
    methods: ['GET', 'HEAD', 'OPTIONS'],
    allowedHeaders: ['Authorization', 'X-API-Key', 'Content-Type'],
    exposedHeaders: ['X-RateLimit-Limit', 'X-RateLimit-Remaining', 'X-RateLimit-Reset', 'Retry-After'],
    maxAge: 86400,
  });

  app.decorateRequest('apiKeyId', null);

  // Optional API key: only checked when the site owner configured API_KEYS.
  app.addHook('onRequest', async (req) => {
    req.apiKeyId = null;
    if (validKeyHashes.size === 0) return;
    const auth = headerValue(req, 'authorization');
    const bearer = auth && /^Bearer\s+(.+)$/i.exec(auth)?.[1];
    const provided = bearer || headerValue(req, 'x-api-key');
    if (!provided) return;
    const hash = sha256(provided.trim());
    if (!validKeyHashes.has(hash)) {
      throw new ApiError(401, 'invalid_api_key', 'The API key is not valid.');
    }
    req.apiKeyId = hash.slice(0, 16);
  });

  await app.register(rateLimit, {
    global: true,
    timeWindow: config.rateLimitWindow,
    max: (req) => (req.apiKeyId ? config.rateLimitKeyed : config.rateLimitAnonymous),
    keyGenerator: (req) => (req.apiKeyId ? `key:${req.apiKeyId}` : `ip:${clientIp(req)?.ip ?? req.ip}`),
    errorResponseBuilder: (_req, ctx) =>
      new ApiError(429, 'rate_limited', `Rate limit exceeded. Try again in ${ctx.after}.`),
  });

  app.addHook('onSend', async (_req, reply) => {
    reply.header('X-Robots-Tag', 'noindex');
  });

  const send = (req: FastifyRequest, reply: FastifyReply, payload: unknown, cache: string) => {
    reply.header('Cache-Control', cache);
    const pretty = (req.query as { pretty?: string }).pretty;
    if (pretty !== undefined && pretty !== '0' && pretty !== 'false') {
      return reply.type('application/json; charset=utf-8').send(JSON.stringify(payload, null, 2) + '\n');
    }
    return reply.send(payload);
  };

  function requestedProviders(req: FastifyRequest): ProviderId[] | undefined {
    const raw = (req.query as { providers?: unknown }).providers;
    if (raw === undefined || raw === '') return undefined;
    if (typeof raw !== 'string') throw new ApiError(400, 'invalid_providers', 'providers must be a comma separated list.');
    const ids = [...new Set(raw.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean))];
    const bad = ids.filter((id) => !(PROVIDER_IDS as readonly string[]).includes(id));
    if (bad.length || ids.length === 0) {
      throw new ApiError(
        400,
        'invalid_providers',
        `Unknown provider "${bad[0] ?? raw}". Valid values: ${PROVIDER_IDS.join(', ')}.`,
      );
    }
    return ids as ProviderId[];
  }

  // --- Lookup the caller's own IP ---------------------------------------
  app.get('/api/v1/ip', async (req, reply) => {
    const only = requestedProviders(req);
    const me = clientIp(req);
    if (!me) throw new ApiError(500, 'client_ip_unavailable', 'Could not determine the client IP address.');
    return send(req, reply, await lookupIp(registry, me, only), 'no-store');
  });

  // --- Lookup any IP ------------------------------------------------------
  app.get<{ Params: { ip: string } }>('/api/v1/ip/:ip', async (req, reply) => {
    const only = requestedProviders(req);
    const parsed = parseIp(req.params.ip);
    if (!parsed) {
      throw new ApiError(400, 'invalid_ip', 'Enter a valid IPv4 or IPv6 address, for example 8.8.8.8 or 2001:4860:4860::8888.');
    }
    return send(req, reply, await lookupIp(registry, parsed, only), 'public, max-age=300');
  });

  // --- Database status ------------------------------------------------------
  app.get('/api/v1/status', async (req, reply) => {
    const providers = registry.info();
    const body: StatusResponse = {
      status: providers.some((p) => p.loaded) ? 'ok' : 'degraded',
      uptime_seconds: Math.round((Date.now() - startedAt) / 1000),
      rate_limit: {
        anonymous: config.rateLimitAnonymous,
        with_api_key: config.rateLimitKeyed,
        window: config.rateLimitWindow,
      },
      providers,
    };
    return send(req, reply, body, 'no-store');
  });

  // --- Plain text: curl <domain>/ip --------------------------------------------
  app.get('/ip', async (req, reply) => {
    const me = clientIp(req);
    if (!me) throw new ApiError(500, 'client_ip_unavailable', 'Could not determine the client IP address.');
    return reply.header('Cache-Control', 'no-store').type('text/plain; charset=utf-8').send(`${me.ip}\n`);
  });
}
