# Getting the data (one-time setup)

You need free accounts with the three providers. Each gives you a credential that goes in `.env`.
After that, `npm run db:update` downloads everything and keeps it fresh.

## 1. MaxMind GeoLite2 (country, region, city, coordinates, timezone, ASN)

1. Create a free account at <https://www.maxmind.com/en/geolite2/signup> and accept the GeoLite2 EULA.
2. In your account go to **Manage license keys → Generate new license key**.
3. Put these in `.env`:
   ```
   MAXMIND_ACCOUNT_ID=123456
   MAXMIND_LICENSE_KEY=xxxxxxxxxxxxxxxx
   ```
The updater downloads `GeoLite2-City` and `GeoLite2-ASN`.

## 2. IPinfo (country + network)

1. Create a free account at <https://ipinfo.io/signup> and copy your access token.
2. In `.env`: `IPINFO_TOKEN=xxxxxxxxxxxx`

The free **IPinfo Lite** database contains country, continent and network (ASN, organization, domain). It has no city data; the site tells visitors this.
If you have a paid plan with city-level data, set `IPINFO_DOWNLOAD_URL` (see `.env.example`).

If you prefer not to store a database, leave the file out and keep only `IPINFO_TOKEN`: the server then calls the IPinfo web API instead (cached for an hour, 2.5 second timeout). Be aware of your plan's request quota in that mode.

## 3. IP2Location LITE (country, region, city, postal code, coordinates, UTC offset)

1. Create a free account at <https://lite.ip2location.com/sign-up> and confirm your email.
2. Copy your **download token** from the account page.
3. In `.env`: `IP2LOCATION_TOKEN=xxxxxxxx` (the default `IP2LOCATION_PACKAGE=DB11LITEBINIPV6` covers IPv4 and IPv6 with city data).

IP2Location only publishes monthly updates and may disable accounts that download too often; the updater therefore downloads at most once per calendar month.

## 4. Download and verify

```bash
npm run db:update
npm run db:check
```

`db:check` prints each provider's state and looks up `8.8.8.8`, `1.1.1.1` and an IPv6 address in each of them.
If a provider is `NOT INSTALLED` or shows a warning, fix that before going live.

Run `db:update` daily from cron or a systemd timer (examples in `deploy/`). The running server picks up new files automatically within `DB_RELOAD_INTERVAL_MIN` minutes, no restart needed.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `credentials rejected` for MaxMind | Check account ID and license key; the key must be active |
| `HTTP 429` from MaxMind | Daily download limit reached, try tomorrow |
| `IP2Location refused the download: ...` | The message comes straight from IP2Location (bad token, unconfirmed email, or monthly limit) |
| Site shows "Database not installed" for a provider | Run `npm run db:check`, then `npm run db:update` |
| Your own IP shows as private / loopback | You are on localhost, or the proxy is not forwarding the visitor IP: see `TRUST_PROXY` in docs/DEPLOYMENT.md |
