<?php
/**
 * Comments template.
 */

if ( post_password_required() ) {
    return;
}
?>

<section id="comments" class="comments-area">

    <?php if ( have_comments() ) : ?>

        <span class="eyebrow"><?php esc_html_e( 'Conversation', 'marina-clothing' ); ?></span>
        <h2 class="comments-title">
            <?php
            printf(
                esc_html(
                    /* translators: %s: comment count */
                    _n(
                        '%s Comment',
                        '%s Comments',
                        get_comments_number(),
                        'marina-clothing'
                    )
                ),
                esc_html( number_format_i18n( get_comments_number() ) )
            );
            ?>
        </h2>

        <ol class="comment-list">
            <?php
            wp_list_comments(
                array(
                    'style'       => 'ol',
                    'callback'    => 'marina_comment_callback',
                    'avatar_size' => 44,
                )
            );
            ?>
        </ol>

        <?php the_comments_navigation(); ?>

    <?php endif; ?>

    <?php if ( ! comments_open() && get_comments_number() ) : ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'marina-clothing' ); ?></p>
    <?php endif; ?>

    <?php
    comment_form(
        array(
            'class_container'    => 'comment-respond form-card',
            'title_reply_before' => '<h3 id="reply-title" class="comment-reply-title">',
            'title_reply_after'  => '</h3>',
            'class_submit'       => 'btn btn--primary',
        )
    );
    ?>

</section>
