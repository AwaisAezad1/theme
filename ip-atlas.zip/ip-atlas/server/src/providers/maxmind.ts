import maxmind, { type AsnResponse, type CityResponse, type Reader } from 'maxmind';
import {
  emptyRecord,
  hasData,
  type GeoProvider,
  type GeoRecord,
  type ProviderInfo,
  type ProviderResult,
} from './types.js';
import { PROBE_IPS, asnNumber, fileSignature, latitude, longitude, plausibleDate, text } from './util.js';

interface Handle<T extends CityResponse | AsnResponse> {
  path: string;
  reader: Reader<T> | null;
  signature: string | null;
}

type Logger = { info: (m: string) => void; warn: (m: string) => void; error: (m: string) => void };

/** Pick the English name, falling back to any available translation. */
function name(names: object | undefined): string | null {
  if (!names) return null;
  const map = names as Record<string, string | undefined>;
  return text(map.en) ?? text(Object.values(map)[0]);
}

export function normalizeMaxmindCity(city: CityResponse | null): Partial<GeoRecord> {
  if (!city) return {};
  const country = city.country ?? city.registered_country;
  return {
    country_code: text(country?.iso_code)?.toUpperCase() ?? null,
    country: name(country?.names),
    continent_code: text(city.continent?.code),
    continent: name(city.continent?.names),
    region: name(city.subdivisions?.[0]?.names),
    city: name(city.city?.names),
    postal_code: text(city.postal?.code),
    latitude: latitude(city.location?.latitude),
    longitude: longitude(city.location?.longitude),
    accuracy_radius_km:
      typeof city.location?.accuracy_radius === 'number' ? city.location.accuracy_radius : null,
    timezone: text(city.location?.time_zone),
  };
}

export function normalizeMaxmindAsn(asn: AsnResponse | null): Partial<GeoRecord> {
  if (!asn) return {};
  return {
    asn: asnNumber(asn.autonomous_system_number),
    organization: text(asn.autonomous_system_organization),
  };
}

export class MaxmindProvider implements GeoProvider {
  readonly id = 'maxmind' as const;
  readonly name = 'MaxMind';
  private city: Handle<CityResponse>;
  private asn: Handle<AsnResponse>;
  private warning: string | null = null;

  constructor(
    cityPath: string,
    asnPath: string,
    private log: Logger,
  ) {
    this.city = { path: cityPath, reader: null, signature: null };
    this.asn = { path: asnPath, reader: null, signature: null };
  }

  private async open<T extends CityResponse | AsnResponse>(handle: Handle<T>, label: string): Promise<boolean> {
    const signature = await fileSignature(handle.path);
    // Missing file: keep serving whatever is already loaded (if anything).
    if (signature === null || signature === handle.signature) return false;
    try {
      handle.reader = await maxmind.open<T>(handle.path);
      handle.signature = signature;
      this.log.info(`MaxMind ${label} database loaded (${handle.path})`);
      return true;
    } catch (err) {
      this.log.error(`MaxMind ${label} database could not be opened: ${err instanceof Error ? err.message : err}`);
      return false;
    }
  }

  async init(): Promise<void> {
    await this.open(this.city, 'City');
    await this.open(this.asn, 'ASN');
    this.selfTest();
  }

  async reloadIfChanged(): Promise<boolean> {
    const a = await this.open(this.city, 'City');
    const b = await this.open(this.asn, 'ASN');
    if (a || b) this.selfTest();
    return a || b;
  }

  private selfTest(): void {
    this.warning = null;
    if (this.city.reader) {
      const resolved = PROBE_IPS.some((ip) => {
        try {
          return this.city.reader!.get(ip) !== null;
        } catch {
          return false;
        }
      });
      if (!resolved) {
        this.warning = 'The City database loaded but could not resolve common test addresses. Check that it is a real GeoLite2 file.';
        this.log.warn(`MaxMind: ${this.warning}`);
      }
    }
  }

  async lookup(ip: string): Promise<ProviderResult> {
    if (!this.city.reader && !this.asn.reader) {
      return { status: 'unavailable', data: null, message: 'MaxMind database is not installed.' };
    }
    try {
      const record: GeoRecord = { ...emptyRecord() };
      if (this.city.reader) Object.assign(record, normalizeMaxmindCity(this.city.reader.get(ip)));
      if (this.asn.reader) Object.assign(record, normalizeMaxmindAsn(this.asn.reader.get(ip)));
      return hasData(record) ? { status: 'ok', data: record } : { status: 'no_data', data: null };
    } catch (err) {
      return { status: 'error', data: null, message: err instanceof Error ? err.message : 'Lookup failed.' };
    }
  }

  info(): ProviderInfo {
    const parts: string[] = [];
    if (this.city.reader) parts.push('City');
    if (this.asn.reader) parts.push('ASN');
    const dates = [this.city.reader, this.asn.reader]
      .map((r) => plausibleDate(r?.metadata.buildEpoch))
      .filter((d): d is string => d !== null)
      .sort();
    const type = this.city.reader?.metadata.databaseType ?? '';
    const isLite = /geolite/i.test(type);
    return {
      id: this.id,
      name: this.name,
      source: parts.length
        ? `${isLite || !type ? 'GeoLite2' : 'GeoIP2'} ${parts.join(' + ')} (local database)`
        : 'GeoLite2 (not installed)',
      loaded: parts.length > 0,
      database_date: dates.length ? dates[dates.length - 1]! : null,
      note: null,
      warning: this.warning,
    };
  }

  close(): void {
    this.city.reader = null;
    this.asn.reader = null;
  }
}
