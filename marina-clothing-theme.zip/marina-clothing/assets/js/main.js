/**
 * Marina Clothing — front-end behaviour.
 *
 * Vanilla JS; jQuery is only used to listen to WooCommerce's jQuery events
 * (added_to_cart, found_variation, …) when WooCommerce is active.
 */

(function () {
    'use strict';

    var data = window.marinaData || {};
    var i18n = data.i18n || {};
    var $ = window.jQuery;

    var qs = function (sel, ctx) { return (ctx || document).querySelector(sel); };
    var qsa = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

    /* ------------------------------------------------------------------
     * Toast
     * ---------------------------------------------------------------- */
    var toastEl;
    var toastTimer;
    function toast(message, icon) {
        if (!toastEl) {
            toastEl = document.createElement('div');
            toastEl.className = 'toast';
            toastEl.setAttribute('role', 'status');
            document.body.appendChild(toastEl);
        }
        toastEl.innerHTML = '<span class="icon" aria-hidden="true">' + (icon || 'check_circle') + '</span><span></span>';
        toastEl.lastChild.textContent = message;
        // Force reflow so the transition replays.
        void toastEl.offsetWidth;
        toastEl.classList.add('is-visible');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { toastEl.classList.remove('is-visible'); }, 2600);
    }

    /* ------------------------------------------------------------------
     * Header: scrolled state + height variable
     * ---------------------------------------------------------------- */
    function initHeader() {
        var header = qs('.site-header');
        if (!header) { return; }

        var setHeight = function () {
            document.documentElement.style.setProperty('--header-h', header.offsetHeight + 'px');
        };
        setHeight();
        window.addEventListener('resize', setHeight);

        var onScroll = function () {
            header.classList.toggle('is-scrolled', window.scrollY > 8);
        };
        onScroll();
        window.addEventListener('scroll', onScroll, { passive: true });

        var searchToggle = qs('[data-search-toggle]');
        var mobileSearch = qs('[data-mobile-search]');
        if (searchToggle && mobileSearch) {
            searchToggle.addEventListener('click', function () {
                mobileSearch.hidden = !mobileSearch.hidden;
                setHeight();
                if (!mobileSearch.hidden) {
                    var input = qs('input[type="search"]', mobileSearch);
                    if (input) { input.focus(); }
                }
            });
        }
    }

    /* ------------------------------------------------------------------
     * Drawers
     * ---------------------------------------------------------------- */
    var overlay;
    var activeDrawer = null;
    var lastFocus = null;

    function openDrawer(id) {
        var drawer = document.getElementById(id);
        if (!drawer) { return false; }
        if (activeDrawer && activeDrawer !== drawer) { closeDrawer(true); }

        lastFocus = document.activeElement;
        activeDrawer = drawer;
        overlay.hidden = false;
        requestAnimationFrame(function () { overlay.classList.add('is-visible'); });
        drawer.classList.add('is-open');
        drawer.setAttribute('aria-hidden', 'false');
        document.body.classList.add('has-open-overlay');
        qsa('[data-drawer-open="' + id + '"]').forEach(function (btn) { btn.setAttribute('aria-expanded', 'true'); });

        if (id === 'wishlist-drawer') { renderWishlist(); }

        setTimeout(function () { drawer.focus(); }, 50);
        return true;
    }

    function closeDrawer(keepOverlay) {
        if (!activeDrawer) { return; }
        var id = activeDrawer.id;
        activeDrawer.classList.remove('is-open');
        activeDrawer.setAttribute('aria-hidden', 'true');
        qsa('[data-drawer-open="' + id + '"]').forEach(function (btn) { btn.setAttribute('aria-expanded', 'false'); });
        activeDrawer = null;

        if (!keepOverlay) {
            overlay.classList.remove('is-visible');
            setTimeout(function () { if (!activeDrawer) { overlay.hidden = true; } }, 300);
            document.body.classList.remove('has-open-overlay');
            if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
        }
    }

    function initDrawers() {
        overlay = qs('[data-drawer-overlay]');
        if (!overlay) { return; }

        document.addEventListener('click', function (e) {
            var opener = e.target.closest('[data-drawer-open]');
            if (opener) {
                var target = opener.getAttribute('data-drawer-open');
                // On cart/checkout the bag icon is a plain link to the cart.
                if (target === 'cart-drawer' && data.noDrawer) { return; }
                if (openDrawer(target)) { e.preventDefault(); }
                return;
            }
            if (e.target.closest('[data-drawer-close]') || e.target === overlay) {
                closeDrawer();
            }
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && activeDrawer) { closeDrawer(); }
        });
    }

    /* ------------------------------------------------------------------
     * WooCommerce cart events
     * ---------------------------------------------------------------- */
    function bump(el) {
        if (!el) { return; }
        el.classList.remove('is-bumped');
        void el.offsetWidth;
        el.classList.add('is-bumped');
    }

    function initCartEvents() {
        if (!$) { return; }

        $(document.body).on('added_to_cart', function (e, fragments, hash, $button) {
            setTimeout(function () { bump(qs('[data-cart-count]')); }, 50);

            if ($button && $button.length) {
                var btn = $button[0];
                var label = btn.querySelector('span:last-child');
                if (label) {
                    var original = label.textContent;
                    label.textContent = i18n.added || 'Added';
                    setTimeout(function () { label.textContent = original; btn.classList.remove('added'); }, 2000);
                }
            }

            if (!data.noDrawer && qs('#cart-drawer')) {
                openDrawer('cart-drawer');
            } else {
                toast(i18n.addedToBag || 'Added to your bag', 'shopping_bag');
            }
        });

        // After a classic (non-AJAX) add to cart on the product page, reveal the bag.
        if (document.body.classList.contains('single-product') && !data.noDrawer) {
            var msg = qs('.woocommerce-notices-wrapper .woocommerce-message');
            if (msg && qs('.wc-forward', msg)) {
                setTimeout(function () { openDrawer('cart-drawer'); }, 400);
            }
        }
    }

    /* ------------------------------------------------------------------
     * Wishlist (localStorage)
     * ---------------------------------------------------------------- */
    var WL_KEY = 'marina_wishlist';

    function getWishlist() {
        try {
            var list = JSON.parse(window.localStorage.getItem(WL_KEY) || '[]');
            return Array.isArray(list) ? list : [];
        } catch (err) {
            return [];
        }
    }

    function saveWishlist(list) {
        try { window.localStorage.setItem(WL_KEY, JSON.stringify(list)); } catch (err) { /* storage unavailable */ }
        syncWishlistUI();
    }

    function syncWishlistUI() {
        var list = getWishlist();
        var ids = list.map(function (item) { return String(item.id); });

        qsa('[data-wishlist]').forEach(function (btn) {
            var item;
            try { item = JSON.parse(btn.getAttribute('data-wishlist')); } catch (err) { return; }
            btn.setAttribute('aria-pressed', ids.indexOf(String(item.id)) > -1 ? 'true' : 'false');
        });

        qsa('[data-wishlist-count]').forEach(function (el) {
            el.textContent = list.length;
            el.hidden = list.length === 0;
        });

        if (activeDrawer && activeDrawer.id === 'wishlist-drawer') { renderWishlist(); }
    }

    function renderWishlist() {
        var ul = qs('[data-wishlist-list]');
        if (!ul) { return; }
        var list = getWishlist();
        ul.innerHTML = '';

        if (!list.length) {
            var empty = document.createElement('li');
            empty.className = 'wishlist-list__empty';
            empty.textContent = i18n.wishlistEmpty || '';
            ul.appendChild(empty);
            return;
        }

        list.forEach(function (item) {
            var li = document.createElement('li');

            var imgLink = document.createElement('a');
            imgLink.href = item.url;
            var img = document.createElement('img');
            img.src = item.img;
            img.alt = '';
            imgLink.appendChild(img);

            var info = document.createElement('div');
            var name = document.createElement('a');
            name.href = item.url;
            name.className = 'wishlist-list__name';
            name.textContent = item.name;
            var price = document.createElement('span');
            price.className = 'wishlist-list__price';
            price.textContent = item.price || '';
            info.appendChild(name);
            info.appendChild(price);

            var remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'icon-btn';
            remove.setAttribute('aria-label', (i18n.remove || 'Remove') + ' ' + item.name);
            remove.innerHTML = '<span class="icon" aria-hidden="true">delete</span>';
            remove.addEventListener('click', function () {
                saveWishlist(getWishlist().filter(function (x) { return String(x.id) !== String(item.id); }));
            });

            li.appendChild(imgLink);
            li.appendChild(info);
            li.appendChild(remove);
            ul.appendChild(li);
        });
    }

    function initWishlist() {
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('[data-wishlist]');
            if (!btn) { return; }
            e.preventDefault();
            e.stopPropagation();

            var item;
            try { item = JSON.parse(btn.getAttribute('data-wishlist')); } catch (err) { return; }

            var list = getWishlist();
            var exists = list.some(function (x) { return String(x.id) === String(item.id); });

            if (exists) {
                list = list.filter(function (x) { return String(x.id) !== String(item.id); });
            } else {
                list.unshift(item);
                bump(qs('[data-wishlist-count]'));
                toast(item.name, 'favorite');
            }
            saveWishlist(list);
        });

        syncWishlistUI();
        window.addEventListener('storage', function (e) { if (e.key === WL_KEY) { syncWishlistUI(); } });
    }

    /* ------------------------------------------------------------------
     * Filter chips (trending grid)
     * ---------------------------------------------------------------- */
    function initFilterChips() {
        qsa('[data-filter-group]').forEach(function (group) {
            var chips = qsa('[data-filter]', group);
            var cards = qsa('.product-card', group);

            chips.forEach(function (chip) {
                chip.addEventListener('click', function () {
                    var val = chip.getAttribute('data-filter');
                    chips.forEach(function (c) {
                        var on = c === chip;
                        c.classList.toggle('is-active', on);
                        c.setAttribute('aria-pressed', on ? 'true' : 'false');
                    });
                    cards.forEach(function (card) {
                        var cats = (card.getAttribute('data-cats') || '').split(' ');
                        var show = val === 'all' || cats.indexOf(val) > -1;
                        card.classList.toggle('is-filtered-out', !show);
                        if (show) {
                            card.classList.remove('is-entering');
                            void card.offsetWidth;
                            card.classList.add('is-entering');
                        }
                    });
                });
            });
        });
    }

    /* ------------------------------------------------------------------
     * Walk-in closet
     * ---------------------------------------------------------------- */
    function initCloset() {
        var closet = qs('[data-closet]');
        if (!closet) { return; }

        var scroller = qs('[data-closet-scroller]', closet);
        var inspector = qs('[data-inspector]', closet);
        var buttons = qsa('[data-garment]', closet);
        var field = function (name) { return qs('[data-i="' + name + '"]', inspector); };

        qsa('[data-closet-scroll]', closet).forEach(function (btn) {
            btn.addEventListener('click', function () {
                scroller.scrollBy({ left: 260 * parseInt(btn.getAttribute('data-closet-scroll'), 10), behavior: 'smooth' });
            });
        });

        buttons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var item;
                try { item = JSON.parse(btn.getAttribute('data-garment')); } catch (err) { return; }

                buttons.forEach(function (b) {
                    b.classList.toggle('is-active', b === btn);
                    b.setAttribute('aria-pressed', b === btn ? 'true' : 'false');
                });

                field('img').src = item.img;
                field('badge').textContent = item.badge;
                field('sub').textContent = item.sub;
                field('title').textContent = item.title;
                field('fabric').textContent = item.fabric;
                field('price').textContent = item.price;
                field('url').href = item.url;

                var cart = field('cart');
                cart.href = item.cart;
                cart.setAttribute('data-product_id', item.id);
                cart.classList.toggle('ajax_add_to_cart', !!item.ajax);
                if ($) { $(cart).data('product_id', item.id); }
                field('cart-label').textContent = item.ajax ? cart.getAttribute('data-label-ajax') : cart.getAttribute('data-label-link');

                inspector.classList.remove('is-swapping');
                void inspector.offsetWidth;
                inspector.classList.add('is-swapping');
            });
        });

        var filters = qsa('[data-closet-filter]', closet);
        filters.forEach(function (tab) {
            tab.addEventListener('click', function () {
                var val = tab.getAttribute('data-closet-filter');
                filters.forEach(function (t) {
                    t.classList.toggle('is-active', t === tab);
                    t.setAttribute('aria-pressed', t === tab ? 'true' : 'false');
                });
                qsa('.garment', closet).forEach(function (g) {
                    var cats = (g.getAttribute('data-cats') || '').split(' ');
                    g.hidden = !(val === 'all' || cats.indexOf(val) > -1);
                });
                scroller.scrollTo({ left: 0, behavior: 'smooth' });
            });
        });
    }

    /* ------------------------------------------------------------------
     * Newsletter
     * ---------------------------------------------------------------- */
    function initNewsletter() {
        if (/[?&]subscribed=1/.test(window.location.search)) {
            setTimeout(function () { toast(i18n.subscribed || 'Subscribed', 'mail'); }, 300);
        }

        qsa('[data-newsletter]').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                if (!window.fetch || !data.ajaxUrl) { return; }
                e.preventDefault();

                var status = qs('.newsletter-form__status', form);
                var btn = qs('button[type="submit"]', form);
                var body = new FormData(form);
                body.set('action', 'marina_newsletter');

                btn.disabled = true;
                status.classList.remove('is-error');

                fetch(data.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        var ok = res && res.success;
                        status.textContent = (res && res.data && res.data.message) || (ok ? i18n.subscribed : i18n.error);
                        status.classList.toggle('is-error', !ok);
                        if (ok) { form.reset(); }
                    })
                    .catch(function () {
                        status.textContent = i18n.error || 'Error';
                        status.classList.add('is-error');
                    })
                    .then(function () { btn.disabled = false; });
            });
        });
    }

    /* ------------------------------------------------------------------
     * Quantity steppers
     * ---------------------------------------------------------------- */
    function enhanceQuantities(ctx) {
        qsa('.quantity', ctx).forEach(function (wrap) {
            var input = qs('input.qty[type="number"]', wrap);
            if (!input || wrap.getAttribute('data-stepper')) { return; }
            wrap.setAttribute('data-stepper', '1');

            var make = function (dir) {
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'qty-btn';
                b.setAttribute('aria-label', dir > 0 ? '+' : '−');
                b.innerHTML = '<span class="icon" aria-hidden="true">' + (dir > 0 ? 'add' : 'remove') + '</span>';
                b.addEventListener('click', function () {
                    var step = parseFloat(input.step) || 1;
                    var min = input.min !== '' ? parseFloat(input.min) : 0;
                    var max = input.max !== '' ? parseFloat(input.max) : Infinity;
                    var val = (parseFloat(input.value) || 0) + dir * step;
                    input.value = Math.max(min, Math.min(max, val));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                    if ($) { $(input).trigger('change'); }
                });
                return b;
            };

            wrap.insertBefore(make(-1), input);
            wrap.appendChild(make(1));
        });
    }

    /* ------------------------------------------------------------------
     * Product gallery
     * ---------------------------------------------------------------- */
    function initGallery() {
        var gallery = qs('.pgallery');
        if (!gallery) { return; }

        var items;
        try { items = JSON.parse(gallery.getAttribute('data-gallery')) || []; } catch (err) { items = []; }

        var g = function (name) { return qs('[data-g="' + name + '"]', gallery); };
        var stage = g('stage');
        var main = g('main');
        var caption = g('caption');
        var counter = g('current');
        var thumbs = qsa('.pgallery__thumb', gallery);
        var index = 0;
        var override = null; // variation image

        function show(i) {
            if (!items.length) { return; }
            index = (i + items.length) % items.length;
            override = null;
            var item = items[index];

            main.style.opacity = '0.3';
            setTimeout(function () {
                main.src = item.src;
                if (item.srcset) { main.srcset = item.srcset; } else { main.removeAttribute('srcset'); }
                main.alt = item.alt || '';
                main.style.opacity = '1';
            }, 120);

            if (caption) {
                caption.textContent = item.caption || '';
                caption.hidden = !item.caption;
            }
            if (counter) { counter.textContent = index + 1; }

            thumbs.forEach(function (t, n) {
                t.classList.toggle('is-active', n === index);
                if (n === index && t.parentNode.scrollTo) {
                    t.parentNode.scrollTo({ left: t.offsetLeft - t.parentNode.clientWidth / 2 + t.clientWidth / 2, behavior: 'smooth' });
                }
            });
        }

        thumbs.forEach(function (t) {
            t.addEventListener('click', function () { show(parseInt(t.getAttribute('data-index'), 10)); });
        });

        var prev = g('prev');
        var next = g('next');
        if (prev) { prev.addEventListener('click', function () { show(index - 1); }); }
        if (next) { next.addEventListener('click', function () { show(index + 1); }); }

        // Hover magnifier (pointer devices only).
        if (window.matchMedia('(hover: hover)').matches) {
            stage.addEventListener('mousemove', function (e) {
                var r = stage.getBoundingClientRect();
                main.style.transformOrigin = ((e.clientX - r.left) / r.width * 100) + '% ' + ((e.clientY - r.top) / r.height * 100) + '%';
                main.style.transform = 'scale(2.2)';
            });
            stage.addEventListener('mouseleave', function () {
                main.style.transform = 'scale(1)';
                main.style.transformOrigin = 'center';
            });
        }

        // Swipe on touch devices.
        var startX = null;
        stage.addEventListener('touchstart', function (e) { startX = e.touches[0].clientX; }, { passive: true });
        stage.addEventListener('touchend', function (e) {
            if (startX === null) { return; }
            var dx = e.changedTouches[0].clientX - startX;
            if (Math.abs(dx) > 40) { show(index + (dx < 0 ? 1 : -1)); }
            startX = null;
        });

        // Full-screen viewer.
        var dialog = qs('[data-zoom-dialog]');
        var zoomImg = dialog ? qs('[data-zoom-img]', dialog) : null;
        var zoomCap = dialog ? qs('[data-zoom-caption]', dialog) : null;

        function renderZoom() {
            var item = override || items[index];
            if (!item) { return; }
            zoomImg.src = item.full || item.src;
            zoomImg.alt = item.alt || '';
            zoomCap.textContent = item.caption || '';
        }

        function openZoom() {
            if (!dialog || !dialog.showModal) { return; }
            renderZoom();
            qsa('[data-zoom-step]', dialog).forEach(function (b) { b.hidden = items.length < 2 || !!override; });
            dialog.showModal();
        }

        stage.addEventListener('click', openZoom);
        stage.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openZoom(); }
            if (e.key === 'ArrowRight') { show(index + 1); }
            if (e.key === 'ArrowLeft') { show(index - 1); }
        });
        var fs = g('fullscreen');
        if (fs) { fs.addEventListener('click', function (e) { e.stopPropagation(); openZoom(); }); }

        if (dialog) {
            dialog.addEventListener('click', function (e) {
                if (e.target === dialog || e.target.closest('[data-dialog-close]')) { dialog.close(); }
                var step = e.target.closest('[data-zoom-step]');
                if (step) {
                    show(index + parseInt(step.getAttribute('data-zoom-step'), 10));
                    renderZoom();
                }
            });
            dialog.addEventListener('keydown', function (e) {
                if (override) { return; }
                if (e.key === 'ArrowRight') { show(index + 1); renderZoom(); }
                if (e.key === 'ArrowLeft') { show(index - 1); renderZoom(); }
            });
        }

        // Variation images.
        if ($) {
            $('form.variations_form').on('found_variation', function (e, variation) {
                if (!variation || !variation.image || !variation.image.src) { return; }
                override = {
                    src: variation.image.src,
                    full: variation.image.full_src,
                    alt: variation.image.alt,
                    caption: variation.image.caption
                };
                main.src = variation.image.src;
                if (variation.image.srcset) { main.srcset = variation.image.srcset; } else { main.removeAttribute('srcset'); }
                thumbs.forEach(function (t) { t.classList.remove('is-active'); });
            }).on('reset_image', function () {
                if (override) { show(index); }
            });
        }
    }

    /* ------------------------------------------------------------------
     * Variation swatches & size guide
     * ---------------------------------------------------------------- */
    var COLORS = {
        terracotta: '#8c4e32', rust: '#8c4e32', navy: '#1a242f', blue: '#3b5b7a', sand: '#e5dfd3',
        beige: '#e5dfd3', oat: '#ebe8e3', cream: '#f6f3ee', white: '#faf7f2', salt: '#faf7f2',
        sage: '#7d8f79', olive: '#3c4b3a', green: '#4f6b4a', black: '#1c1c19', grey: '#9a9ca0',
        gray: '#9a9ca0', red: '#a33a2c', pink: '#e8b4a8', yellow: '#e2c26b', orange: '#d98b4f',
        brown: '#6b4a32', purple: '#6d5677'
    };

    function colorFor(text) {
        var t = (text || '').toLowerCase();
        for (var key in COLORS) {
            if (Object.prototype.hasOwnProperty.call(COLORS, key) && t.indexOf(key) > -1) { return COLORS[key]; }
        }
        return '';
    }

    function initSwatches() {
        var form = qs('form.variations_form');
        if (!form || !$) { return; }

        var sizeDialog = qs('[data-size-guide]');

        qsa('.variations select', form).forEach(function (select) {
            var row = select.closest('tr');
            var label = row ? qs('th.label label', row) : null;
            var attrName = (select.getAttribute('data-attribute_name') || select.name || '') + ' ' + (label ? label.textContent : '');
            var isColor = /colou?r/i.test(attrName);
            var isSize = /size/i.test(attrName);

            var chosen = document.createElement('span');
            chosen.className = 'variation-label__chosen';
            if (label) {
                var wrapLabel = document.createElement('span');
                while (label.firstChild) { wrapLabel.appendChild(label.firstChild); }
                wrapLabel.appendChild(chosen);
                label.appendChild(wrapLabel);

                if (isSize && sizeDialog && sizeDialog.showModal) {
                    var guide = document.createElement('button');
                    guide.type = 'button';
                    guide.className = 'size-guide-link';
                    guide.innerHTML = '<span class="icon" aria-hidden="true">straighten</span><span></span>';
                    guide.lastChild.textContent = qs('#size-guide-title') ? qs('#size-guide-title').textContent : 'Size guide';
                    guide.addEventListener('click', function (e) { e.preventDefault(); sizeDialog.showModal(); });
                    label.appendChild(guide);
                }
            }

            var wrap = document.createElement('div');
            wrap.className = 'marina-options' + (isSize ? ' marina-options--size' : '');
            wrap.setAttribute('role', 'radiogroup');
            if (label) { wrap.setAttribute('aria-label', label.textContent.trim()); }

            function build() {
                wrap.innerHTML = '';
                qsa('option', select).forEach(function (opt) {
                    if (!opt.value) { return; }
                    var b = document.createElement('button');
                    b.type = 'button';
                    b.setAttribute('role', 'radio');
                    b.setAttribute('data-value', opt.value);
                    b.setAttribute('aria-label', opt.textContent);
                    b.title = opt.textContent;

                    var hex = isColor ? colorFor(opt.value + ' ' + opt.textContent) : '';
                    if (hex) {
                        b.className = 'marina-opt marina-opt--swatch';
                        b.style.setProperty('--swatch', hex);
                        b.innerHTML = '<span class="icon" aria-hidden="true">check</span>';
                    } else {
                        b.className = 'marina-opt';
                        b.textContent = opt.textContent;
                    }

                    if (opt.disabled || !opt.classList.contains('enabled') && form.querySelector('.variations select option.enabled')) {
                        b.classList.add('is-unavailable');
                    }

                    b.addEventListener('click', function () {
                        var newVal = select.value === opt.value ? '' : opt.value;
                        $(select).val(newVal).trigger('change');
                    });
                    wrap.appendChild(b);
                });
                sync();
            }

            function sync() {
                qsa('.marina-opt', wrap).forEach(function (b) {
                    var on = b.getAttribute('data-value') === select.value;
                    b.classList.toggle('is-selected', on);
                    b.setAttribute('aria-checked', on ? 'true' : 'false');
                });
                var opt = select.options[select.selectedIndex];
                chosen.textContent = select.value && opt ? opt.textContent : '';
            }

            select.classList.add('is-enhanced');
            select.setAttribute('tabindex', '-1');
            select.parentNode.insertBefore(wrap, select);
            build();

            $(select).on('change', sync);
            $(form).on('woocommerce_update_variation_values', build);
        });
    }

    /* ------------------------------------------------------------------
     * Reviews toggle, dialogs, buy bar
     * ---------------------------------------------------------------- */
    function initProductExtras() {
        var toggle = qs('[data-review-toggle]');
        var formWrap = document.getElementById('review_form_wrapper');
        if (toggle && formWrap) {
            toggle.addEventListener('click', function () {
                formWrap.hidden = !formWrap.hidden;
                toggle.setAttribute('aria-expanded', formWrap.hidden ? 'false' : 'true');
                if (!formWrap.hidden) {
                    formWrap.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            });
            // Re-open the form when returning with a validation error or anchor.
            if (window.location.hash === '#review_form' || window.location.hash === '#respond') {
                formWrap.hidden = false;
            }
        }

        qsa('dialog.modal').forEach(function (dialog) {
            dialog.addEventListener('click', function (e) {
                if (e.target === dialog || e.target.closest('[data-dialog-close]')) { dialog.close(); }
            });
        });

        var bar = qs('[data-buy-bar]');
        var target = qs('.psummary form.cart') || qs('.psummary');
        if (bar && target && 'IntersectionObserver' in window) {
            var io = new IntersectionObserver(function (entries) {
                var hidden = !entries[0].isIntersecting && entries[0].boundingClientRect.top < 0;
                bar.classList.toggle('is-visible', hidden);
                bar.setAttribute('aria-hidden', hidden ? 'false' : 'true');
                qs('[data-buy-bar-go]', bar).tabIndex = hidden ? 0 : -1;
            }, {
                // Treat the area under the sticky header as out of view.
                rootMargin: '-' + ((qs('.site-header') || {}).offsetHeight || 0) + 'px 0px 0px 0px'
            });
            io.observe(target);
            qs('[data-buy-bar-go]', bar).addEventListener('click', function () {
                target.scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
        }

        // Smooth jump to reviews.
        qsa('a[href="#reviews"]').forEach(function (a) {
            a.addEventListener('click', function (e) {
                var el = document.getElementById('reviews');
                if (el) { e.preventDefault(); el.scrollIntoView({ behavior: 'smooth' }); }
            });
        });
    }

    /* ------------------------------------------------------------------
     * Boot
     * ---------------------------------------------------------------- */
    document.addEventListener('DOMContentLoaded', function () {
        initHeader();
        initDrawers();
        initCartEvents();
        initWishlist();
        initFilterChips();
        initCloset();
        initNewsletter();
        enhanceQuantities(document);
        initGallery();
        initSwatches();
        initProductExtras();

        if ($) {
            $(document.body).on('updated_cart_totals updated_wc_div wc_fragments_refreshed', function () {
                enhanceQuantities(document);
            });
        }
    });

    /**
     * Small admin-ajax helper.
     *
     * marinaAjax('action_name', { key: 'value' }).then(function (response) { … });
     */
    window.marinaAjax = function (action, payload) {
        var formData = new FormData();

        formData.append('action', action);
        formData.append('nonce', data.nonce);

        Object.keys(payload || {}).forEach(function (key) {
            formData.append(key, payload[key]);
        });

        return fetch(data.ajaxUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        }).then(function (response) {
            return response.json();
        });
    };
})();
