<?php
/**
 * Footer.
 */
?>

<footer class="site-footer">
    <div class="container">

        <?php
        wp_nav_menu(
            array(
                'theme_location' => 'footer',
                'fallback_cb'    => false,
            )
        );
        ?>

        <p>
            &copy; <?php echo esc_html( wp_date( 'Y' ) ); ?>
            <?php bloginfo( 'name' ); ?>
        </p>

    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
