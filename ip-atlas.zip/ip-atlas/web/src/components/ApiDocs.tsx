import { useMemo, useState } from 'react';
import { CONTACT_EMAIL } from '../config';
import type { StatusResponse } from '../types';
import { copyText } from '../lib/format';
import { Icon } from './Icons';

type Tab = 'curl' | 'javascript' | 'python' | 'response';
const TABS: Array<{ id: Tab; label: string }> = [
  { id: 'curl', label: 'cURL' },
  { id: 'javascript', label: 'JavaScript' },
  { id: 'python', label: 'Python' },
  { id: 'response', label: 'Response' },
];

const SAMPLE_RESPONSE = `{
  "ip": "81.2.69.142",
  "version": 4,
  "is_public": true,
  "summary": {
    "country_code": "GB",
    "country": "United Kingdom",
    "region": "England",
    "city": "London",
    "latitude": 51.5142,
    "longitude": -0.0931,
    "timezone": { "id": "Europe/London", "utc_offset": "+01:00" },
    "asn": 5089,
    "organization": "Virgin Media Limited",
    "country_agreement": { "matching": 3, "total": 3 }
  },
  "providers": {
    "maxmind":     { "status": "ok", "data": { "city": "London", "...": "..." } },
    "ipinfo":      { "status": "ok", "data": { "country_code": "GB", "...": "..." } },
    "ip2location": { "status": "ok", "data": { "city": "London", "...": "..." } }
  }
}`;

export default function ApiDocs({ status }: { status: StatusResponse | null }) {
  const [tab, setTab] = useState<Tab>('curl');
  const [copied, setCopied] = useState(false);
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://your-domain.com';

  const snippets: Record<Tab, string> = useMemo(
    () => ({
      curl: `# Look up any IP address\ncurl "${origin}/api/v1/ip/8.8.8.8"\n\n# Look up the caller's own IP\ncurl "${origin}/api/v1/ip"\n\n# Only some providers\ncurl "${origin}/api/v1/ip/8.8.8.8?providers=maxmind,ipinfo"\n\n# Just your IP as plain text\ncurl "${origin}/ip"`,
      javascript: `const res = await fetch("${origin}/api/v1/ip/8.8.8.8");\nif (!res.ok) throw new Error((await res.json()).error.message);\nconst data = await res.json();\n\nconsole.log(data.summary.city, data.summary.country);\nconsole.log(data.providers.maxmind.data);`,
      python: `import requests\n\nres = requests.get("${origin}/api/v1/ip/8.8.8.8", timeout=10)\nres.raise_for_status()\ndata = res.json()\n\nprint(data["summary"]["city"], data["summary"]["country"])`,
      response: SAMPLE_RESPONSE,
    }),
    [origin],
  );

  async function copy() {
    if (await copyText(snippets[tab])) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    }
  }

  const rl = status?.rate_limit;
  const limitText = rl ? `${rl.anonymous} requests per ${rl.window.replace(/^1\s+/, '')} per IP address` : 'Fair-use rate limits apply';

  return (
    <section id="api" className="border-t border-white/[0.06] bg-[#081522]">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-[0.82fr_1.18fr] lg:px-8 lg:py-24">
        <div className="min-w-0">
          <p className="section-label">Developer API</p>
          <h2 className="mt-3 text-3xl font-semibold leading-tight tracking-[-0.03em] text-white sm:text-4xl">Build IP intelligence into your product.</h2>
          <p className="mt-5 max-w-md leading-7 text-slate-400">
            A simple JSON REST API. No signup needed for light use. Every response includes a merged summary plus the raw record from each provider.
          </p>
          <ul className="mt-8 space-y-3 text-sm">
            {[
              ['GET', '/api/v1/ip', 'Your own IP'],
              ['GET', '/api/v1/ip/{ip}', 'Any IPv4 or IPv6'],
              ['GET', '/api/v1/status', 'Database status'],
              ['GET', '/ip', 'Plain-text IP'],
            ].map(([method, path, desc]) => (
              <li key={path} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-white/[0.07] bg-white/[0.02] px-4 py-3">
                <span className="rounded bg-cyan-300/10 px-1.5 py-0.5 font-mono text-[11px] font-medium text-cyan-300">{method}</span>
                <code className="text-slate-200">{path}</code>
                <span className="text-slate-500 sm:ml-auto">{desc}</span>
              </li>
            ))}
          </ul>
          <dl className="mt-8 space-y-4 text-sm leading-6">
            <div>
              <dt className="font-semibold text-slate-200">Query parameters</dt>
              <dd className="text-slate-400"><code className="text-cyan-200">providers</code> – comma list of maxmind, ipinfo, ip2location · <code className="text-cyan-200">pretty=1</code> – indented JSON</dd>
            </div>
            <div>
              <dt className="font-semibold text-slate-200">Rate limit</dt>
              <dd className="text-slate-400">
                {limitText}. Over the limit you get HTTP 429 with a <code className="text-cyan-200">Retry-After</code> header.
                {CONTACT_EMAIL && (<> Need more? <a className="text-cyan-300 underline" href={`mailto:${CONTACT_EMAIL}`}>Get in touch</a>.</>)}
              </dd>
            </div>
            <div>
              <dt className="font-semibold text-slate-200">Errors</dt>
              <dd className="text-slate-400">Always JSON: <code className="text-cyan-200">{'{"error":{"code","message","status"}}'}</code></dd>
            </div>
          </dl>
        </div>

        <div className="code-window min-w-0 self-start">
          <div className="flex items-center justify-between border-b border-white/[0.07] px-3 sm:px-5">
            <div role="tablist" aria-label="Code examples" className="flex overflow-x-auto">
              {TABS.map((t) => (
                <button key={t.id} role="tab" type="button" aria-selected={tab === t.id} onClick={() => setTab(t.id)} className={`code-tab ${tab === t.id ? 'active' : ''}`}>
                  {t.label}
                </button>
              ))}
            </div>
            <button type="button" onClick={copy} className="ml-2 flex shrink-0 items-center gap-1.5 rounded-md px-2 py-1.5 text-[11px] font-semibold text-slate-400 hover:text-white">
              <Icon name={copied ? 'check' : 'copy'} className="h-3.5 w-3.5" /> {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre role="tabpanel" className="max-h-[460px] overflow-auto p-5 text-[12.5px] leading-6 text-slate-300 sm:p-6"><code>{snippets[tab]}</code></pre>
        </div>
      </div>
    </section>
  );
}
