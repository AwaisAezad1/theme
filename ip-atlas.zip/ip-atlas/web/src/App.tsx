import { useEffect, useRef, useState } from 'react';
import ApiDocs from './components/ApiDocs';
import Footer from './components/Footer';
import Header from './components/Header';
import Hero from './components/Hero';
import Results, { ResultSkeleton } from './components/Results';
import Sources from './components/Sources';
import { fetchStatus } from './lib/api';
import { useLookup } from './lib/useLookup';
import type { StatusResponse } from './types';

function readQueryParam(): string {
  try {
    return new URLSearchParams(window.location.search).get('ip')?.trim().slice(0, 60) ?? '';
  } catch {
    return '';
  }
}

/** Keep the address bar shareable (?ip=...) without adding history entries. */
function syncUrl(query: string) {
  try {
    const url = new URL(window.location.href);
    if (query) url.searchParams.set('ip', query);
    else url.searchParams.delete('ip');
    window.history.replaceState(null, '', url);
  } catch {
    /* ignore */
  }
}

export default function App() {
  const { loading, data, error, query, run } = useLookup();
  const [input, setInput] = useState(readQueryParam);
  const [status, setStatus] = useState<StatusResponse | null>(null);
  const resultsRef = useRef<HTMLElement>(null);
  const scrollPending = useRef(false);

  useEffect(() => {
    void run(readQueryParam());
    const ctl = new AbortController();
    fetchStatus(ctl.signal).then(setStatus).catch(() => undefined);
    return () => ctl.abort();
  }, [run]);

  // After a lookup the visitor started, bring the results into view (they can sit below the fold).
  useEffect(() => {
    if (loading || !scrollPending.current) return;
    scrollPending.current = false;
    const el = resultsRef.current;
    if (error || !el || !data) return; // stay put so the error message under the search box stays visible
    if (el.getBoundingClientRect().top > window.innerHeight * 0.6) {
      const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    }
  }, [loading, data, error]);

  function lookup(q: string) {
    syncUrl(q);
    scrollPending.current = true;
    void run(q);
  }

  function useMyIp() {
    setInput('');
    lookup('');
  }

  return (
    <div className="min-h-screen bg-[#07111f] text-slate-300">
      <Header />
      <main>
        <Hero value={input} onChange={setInput} onSubmit={lookup} onUseMyIp={useMyIp} loading={loading} error={error} />
        <section ref={resultsRef} className="mx-auto max-w-7xl px-5 py-12 lg:px-8 lg:py-16" aria-label="Lookup results">
          {data ? (
            <Results data={data} loading={loading} isOwn={query === ''} infos={status?.providers ?? []} />
          ) : loading ? (
            <ResultSkeleton />
          ) : (
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-8 text-center text-slate-400">
              We couldn’t load your IP details. Enter an IP address above to try a manual lookup.
            </div>
          )}
        </section>
        <ApiDocs status={status} />
        <Sources infos={status?.providers ?? []} />
      </main>
      <Footer />
    </div>
  );
}
