<?php
defined( 'ABSPATH' ) || exit;

/**
 * Persistent automation jobs.
 */
class AIBW_Jobs {

	const STATUSES = array( 'queued', 'running', 'researching', 'generating', 'optimizing', 'importing_images', 'draft_created', 'failed', 'needs_review', 'cancelled', 'skipped' );

	public static function create( $topic_row ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		$ok  = $wpdb->insert(
			AIBW_DB::jobs(),
			array(
				'uuid'       => wp_generate_uuid4(),
				'topic_id'   => (int) $topic_row->id,
				'topic_text' => $topic_row->title,
				'status'     => 'queued',
				'stage'      => 'queued',
				'attempts'   => 0,
				'created_at' => $now,
				'updated_at' => $now,
			)
		);
		if ( ! $ok ) {
			return new WP_Error( 'aibw_db', __( 'Could not create the job.', 'ai-blog-writer' ) );
		}
		return (int) $wpdb->insert_id;
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . AIBW_DB::jobs() . ' WHERE id = %d', absint( $id ) ) );
	}

	public static function update( $id, $data ) {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql' );
		$wpdb->update( AIBW_DB::jobs(), $data, array( 'id' => absint( $id ) ) );
	}

	public static function active() {
		global $wpdb;
		$table = AIBW_DB::jobs();
		return $wpdb->get_row( "SELECT * FROM {$table} WHERE status IN ('queued','running','researching','generating','optimizing','importing_images') ORDER BY id ASC LIMIT 1" );
	}

	public static function counts() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT status, COUNT(*) AS c FROM ' . AIBW_DB::jobs() . ' GROUP BY status', ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$out[ $row['status'] ] = (int) $row['c'];
		}
		return $out;
	}

	public static function recent( $limit = 15 ) {
		global $wpdb;
		$limit = max( 1, min( 50, (int) $limit ) );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . AIBW_DB::jobs() . ' ORDER BY id DESC LIMIT %d', $limit ) );
	}

	public static function log_line( $job_id, $severity, $stage, $provider, $message, $post_id = 0, $topic = '' ) {
		global $wpdb;
		$severity = sanitize_key( $severity );
		if ( ! in_array( $severity, array( 'info', 'warning', 'error' ), true ) ) {
			$severity = 'info';
		}
		$wpdb->insert(
			AIBW_DB::logs(),
			array(
				'job_id'     => absint( $job_id ),
				'created_at' => current_time( 'mysql' ),
				'severity'   => $severity,
				'stage'      => sanitize_key( $stage ),
				'provider'   => sanitize_text_field( $provider ),
				'topic'      => mb_substr( sanitize_text_field( $topic ), 0, 180 ),
				'message'    => AIBW_Settings::redact( mb_substr( (string) $message, 0, 2000 ) ),
				'post_id'    => absint( $post_id ),
			)
		);
	}

	public static function query_logs( $args ) {
		global $wpdb;
		$table  = AIBW_DB::logs();
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['severity'] ) ) {
			$where[]  = 'severity = %s';
			$params[] = sanitize_key( $args['severity'] );
		}
		if ( ! empty( $args['provider'] ) ) {
			$where[]  = 'provider = %s';
			$params[] = sanitize_text_field( $args['provider'] );
		}
		if ( ! empty( $args['topic'] ) ) {
			$where[]  = 'topic LIKE %s';
			$params[] = '%' . $wpdb->esc_like( sanitize_text_field( $args['topic'] ) ) . '%';
		}
		if ( ! empty( $args['after'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $args['after'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = $args['after'] . ' 00:00:00';
		}
		$sql      = 'SELECT * FROM ' . $table . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT 100';
		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql;
		return $wpdb->get_results( $prepared );
	}

	public static function prune() {
		$days = (int) AIBW_Settings::automation()['log_retention_days'];
		if ( $days < 1 ) {
			return;
		}
		global $wpdb;
		$cut = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . AIBW_DB::logs() . ' WHERE created_at < %s', $cut ) );
	}

	public static function usage_add( $tokens, $cost ) {
		$key  = 'aibw_usage_' . gmdate( 'Ymd' );
		$usage = get_option( $key, array() );
		if ( ! is_array( $usage ) ) {
			$usage = array();
		}
		$usage['requests'] = isset( $usage['requests'] ) ? (int) $usage['requests'] + 1 : 1;
		$usage['tokens']   = isset( $usage['tokens'] ) ? (int) $usage['tokens'] + (int) $tokens : (int) $tokens;
		if ( null !== $cost ) {
			$usage['cost_estimate'] = isset( $usage['cost_estimate'] ) ? (float) $usage['cost_estimate'] + (float) $cost : (float) $cost;
			$usage['cost_is_estimate'] = 1;
		}
		update_option( $key, $usage, false );
		return $usage;
	}

	public static function usage_today() {
		$usage = get_option( 'aibw_usage_' . gmdate( 'Ymd' ), array() );
		return is_array( $usage ) ? $usage : array();
	}

	public static function budget_blocked() {
		$auto  = AIBW_Settings::automation();
		$usage = self::usage_today();
		if ( $auto['daily_budget'] <= 0 ) {
			return '';
		}
		if ( ! isset( $usage['cost_estimate'] ) ) {
			return '';
		}
		if ( (float) $usage['cost_estimate'] >= (float) $auto['daily_budget'] ) {
			return __( 'Estimated daily spending limit reached. New automation work is paused. This figure is an estimate, not a bill.', 'ai-blog-writer' );
		}
		return '';
	}

	/**
	 * Jobs left in a running state after a crash become retryable.
	 */
	public static function recover_stale() {
		global $wpdb;
		$table = AIBW_DB::jobs();
		$cut   = gmdate( 'Y-m-d H:i:s', time() - 20 * MINUTE_IN_SECONDS );
		$stale = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status IN ('running','researching','generating','optimizing','importing_images') AND updated_at < %s", $cut ) );
		foreach ( (array) $stale as $job ) {
			self::update(
				$job->id,
				array(
					'status'        => 'needs_review',
					'error_message' => __( 'The job stopped before it finished. You can retry the unfinished stage.', 'ai-blog-writer' ),
				)
			);
			self::log_line( $job->id, 'warning', $job->stage, '', __( 'Recovered a stale job after an interrupted request.', 'ai-blog-writer' ), (int) $job->post_id, $job->topic_text );
			if ( $job->topic_id ) {
				AIBW_Topics::update( $job->topic_id, array( 'status' => 'failed' ) );
			}
		}
	}
}
