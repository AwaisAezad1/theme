<?php
defined( 'ABSPATH' ) || exit;
$tz = wp_timezone_string();
?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'Automation', 'ai-blog-writer' ); ?></h1>
	<p class="aibw-lead"><?php esc_html_e( 'Scheduled posts are saved as drafts for you to review. Nothing is published automatically.', 'ai-blog-writer' ); ?></p>
	<?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
	<?php if ( ! empty( $last['message'] ) ) : ?>
		<div class="notice notice-info"><p><strong><?php esc_html_e( 'Last result:', 'ai-blog-writer' ); ?></strong> <?php echo esc_html( $last['message'] ); ?> <small><?php echo esc_html( isset( $last['time'] ) ? $last['time'] : '' ); ?></small></p></div>
	<?php endif; ?>

	<div class="aibw-card">
		<h2><?php esc_html_e( 'Status', 'ai-blog-writer' ); ?></h2>
		<ul>
			<li><?php echo ! empty( $auto['enabled'] ) && empty( $auto['paused'] ) ? esc_html__( 'Automation is enabled.', 'ai-blog-writer' ) : esc_html__( 'Automation is off or paused.', 'ai-blog-writer' ); ?></li>
			<li><?php esc_html_e( 'Site timezone:', 'ai-blog-writer' ); ?> <?php echo esc_html( $tz ); ?></li>
			<li><?php esc_html_e( 'Next run:', 'ai-blog-writer' ); ?> <?php echo esc_html( AIBW_Scheduler::next_local_label() ); ?></li>
			<li><?php esc_html_e( 'Drafts created:', 'ai-blog-writer' ); ?> <?php echo isset( $jobs['draft_created'] ) ? (int) $jobs['draft_created'] : 0; ?></li>
			<li><?php esc_html_e( 'Failed jobs:', 'ai-blog-writer' ); ?> <?php echo isset( $jobs['failed'] ) ? (int) $jobs['failed'] : 0; ?></li>
			<li><?php esc_html_e( 'Needs review:', 'ai-blog-writer' ); ?> <?php echo isset( $jobs['needs_review'] ) ? (int) $jobs['needs_review'] : 0; ?></li>
			<li><?php esc_html_e( 'Pending topics:', 'ai-blog-writer' ); ?> <?php echo isset( $topics['pending'] ) ? (int) $topics['pending'] : 0; ?></li>
			<li><?php esc_html_e( 'Requests today:', 'ai-blog-writer' ); ?> <?php echo isset( $usage['requests'] ) ? (int) $usage['requests'] : 0; ?>,
				<?php esc_html_e( 'tokens:', 'ai-blog-writer' ); ?> <?php echo isset( $usage['tokens'] ) ? (int) $usage['tokens'] : 0; ?>
				<?php if ( isset( $usage['cost_estimate'] ) ) : ?>
					<?php echo esc_html( sprintf( __( '(estimated $%s, not a bill)', 'ai-blog-writer' ), number_format( (float) $usage['cost_estimate'], 4 ) ) ); ?>
				<?php else : ?>
					<?php esc_html_e( 'No priced usage was reported by the provider.', 'ai-blog-writer' ); ?>
				<?php endif; ?>
			</li>
		</ul>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:8px;flex-wrap:wrap;">
			<?php wp_nonce_field( 'aibw_automation_action' ); ?>
			<input type="hidden" name="action" value="aibw_automation_action" />
			<button class="button button-primary" name="do" value="run"><?php esc_html_e( 'Run Now', 'ai-blog-writer' ); ?></button>
			<button class="button" name="do" value="pause"><?php esc_html_e( 'Pause', 'ai-blog-writer' ); ?></button>
			<button class="button" name="do" value="resume"><?php esc_html_e( 'Resume', 'ai-blog-writer' ); ?></button>
		</form>
		<p class="description"><?php esc_html_e( 'WordPress cron runs when someone visits the site. For a reliable daily schedule, ask the server to call wp-cron.php every 5 to 15 minutes and set DISABLE_WP_CRON to true. Example: curl -s https://example.com/wp-cron.php?doing_wp_cron >/dev/null', 'ai-blog-writer' ); ?></p>
	</div>

	<div class="aibw-card">
		<h2><?php esc_html_e( 'Queue and recent jobs', 'ai-blog-writer' ); ?></h2>
		<?php if ( ! $queue ) : ?><p><?php esc_html_e( 'No pending topics.', 'ai-blog-writer' ); ?></p><?php endif; ?>
		<ul>
			<?php foreach ( $queue as $topic ) : ?>
				<li><?php echo esc_html( $topic->title ); ?> <small><?php echo esc_html( $topic->status ); ?></small></li>
			<?php endforeach; ?>
		</ul>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'Job', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Status', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Stage', 'ai-blog-writer' ); ?></th><th></th></tr></thead>
			<tbody>
			<?php if ( ! $recent ) : ?><tr><td colspan="5"><?php esc_html_e( 'No jobs yet.', 'ai-blog-writer' ); ?></td></tr><?php endif; ?>
			<?php foreach ( $recent as $job ) : ?>
				<tr>
					<td><?php echo (int) $job->id; ?></td>
					<td><?php echo esc_html( $job->topic_text ); ?></td>
					<td><?php echo esc_html( $job->status ); ?></td>
					<td><?php echo esc_html( $job->stage ); ?><?php if ( $job->error_message ) : ?><br><small><?php echo esc_html( $job->error_message ); ?></small><?php endif; ?></td>
					<td>
						<?php if ( in_array( $job->status, array( 'failed', 'needs_review' ), true ) ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'aibw_automation_action' ); ?>
								<input type="hidden" name="action" value="aibw_automation_action" />
								<input type="hidden" name="job_id" value="<?php echo (int) $job->id; ?>" />
								<button class="button" name="do" value="retry"><?php esc_html_e( 'Retry Failed Job', 'ai-blog-writer' ); ?></button>
							</form>
						<?php endif; ?>
						<?php if ( $job->post_id ) : ?><a href="<?php echo esc_url( get_edit_post_link( $job->post_id ) ); ?>"><?php esc_html_e( 'Edit draft', 'ai-blog-writer' ); ?></a><?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="aibw-card">
		<h2><?php esc_html_e( 'Settings', 'ai-blog-writer' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'aibw_save_automation' ); ?>
			<input type="hidden" name="action" value="aibw_save_automation" />
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Enable automation', 'ai-blog-writer' ); ?></th><td><label><input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $auto['enabled'] ) ); ?> /> <?php esc_html_e( 'Run on the schedule below', 'ai-blog-writer' ); ?></label></td></tr>
				<tr><th scope="row"><label for="aibw-freq"><?php esc_html_e( 'Frequency', 'ai-blog-writer' ); ?></label></th><td>
					<select name="frequency" id="aibw-freq">
						<option value="daily" <?php selected( $auto['frequency'], 'daily' ); ?>><?php esc_html_e( 'Daily', 'ai-blog-writer' ); ?></option>
						<option value="weekly" <?php selected( $auto['frequency'], 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'ai-blog-writer' ); ?></option>
						<option value="days" <?php selected( $auto['frequency'], 'days' ); ?>><?php esc_html_e( 'Selected days', 'ai-blog-writer' ); ?></option>
					</select>
					<p>
						<?php
						$names = array( __( 'Sun', 'ai-blog-writer' ), __( 'Mon', 'ai-blog-writer' ), __( 'Tue', 'ai-blog-writer' ), __( 'Wed', 'ai-blog-writer' ), __( 'Thu', 'ai-blog-writer' ), __( 'Fri', 'ai-blog-writer' ), __( 'Sat', 'ai-blog-writer' ) );
						foreach ( $names as $i => $name ) :
							?>
							<label><input type="checkbox" name="weekdays[]" value="<?php echo (int) $i; ?>" <?php checked( in_array( (string) $i, array_map( 'strval', (array) $auto['weekdays'] ), true ) || in_array( $i, (array) $auto['weekdays'], true ) ); ?> /> <?php echo esc_html( $name ); ?></label>
						<?php endforeach; ?>
					</p>
				</td></tr>
				<tr><th scope="row"><label for="aibw-time"><?php esc_html_e( 'Time', 'ai-blog-writer' ); ?></label></th><td><input type="time" id="aibw-time" name="time" value="<?php echo esc_attr( $auto['time'] ); ?>" /> <span class="description"><?php echo esc_html( $tz ); ?></span></td></tr>
				<tr><th scope="row"><label for="aibw-articles"><?php esc_html_e( 'Articles per run', 'ai-blog-writer' ); ?></label></th><td><input type="number" min="1" max="5" id="aibw-articles" name="articles" value="<?php echo (int) $auto['articles']; ?>" /></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Length', 'ai-blog-writer' ); ?></th><td>
					<input type="number" name="min_words" value="<?php echo (int) $auto['min_words']; ?>" /> –
					<input type="number" name="max_words" value="<?php echo (int) $auto['max_words']; ?>" />
				</td></tr>
				<tr><th scope="row"><label for="aibw-lang"><?php esc_html_e( 'Language', 'ai-blog-writer' ); ?></label></th><td><input id="aibw-lang" name="language" value="<?php echo esc_attr( $auto['language'] ); ?>" placeholder="<?php echo esc_attr( $settings['language'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="aibw-tone"><?php esc_html_e( 'Tone', 'ai-blog-writer' ); ?></label></th><td>
					<select id="aibw-tone" name="tone"><option value=""><?php esc_html_e( 'Use the writing default', 'ai-blog-writer' ); ?></option>
						<?php foreach ( AIBW_Generator::tones() as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $auto['tone'], $key ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="aibw-aud"><?php esc_html_e( 'Audience', 'ai-blog-writer' ); ?></label></th><td><input class="regular-text" id="aibw-aud" name="audience" value="<?php echo esc_attr( $auto['audience'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="aibw-niche"><?php esc_html_e( 'Niche', 'ai-blog-writer' ); ?></label></th><td><input class="regular-text" id="aibw-niche" name="niche" value="<?php echo esc_attr( $auto['niche'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="aibw-cat"><?php esc_html_e( 'Category', 'ai-blog-writer' ); ?></label></th><td>
					<select id="aibw-cat" name="category"><option value="0"><?php esc_html_e( 'Writing default', 'ai-blog-writer' ); ?></option>
						<?php foreach ( $categories as $cat ) : ?><option value="<?php echo (int) $cat->term_id; ?>" <?php selected( (int) $auto['category'], (int) $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option><?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="aibw-tags"><?php esc_html_e( 'Tags', 'ai-blog-writer' ); ?></label></th><td><input class="regular-text" id="aibw-tags" name="tags" value="<?php echo esc_attr( $auto['tags'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="aibw-author"><?php esc_html_e( 'Author', 'ai-blog-writer' ); ?></label></th><td>
					<select id="aibw-author" name="author"><option value="0"><?php esc_html_e( 'Site administrator', 'ai-blog-writer' ); ?></option>
						<?php foreach ( $authors as $user ) : ?><option value="<?php echo (int) $user->ID; ?>" <?php selected( (int) $auto['author'], (int) $user->ID ); ?>><?php echo esc_html( $user->display_name ); ?></option><?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="aibw-images"><?php esc_html_e( 'Images', 'ai-blog-writer' ); ?></label></th><td>
					<select id="aibw-images" name="images"><option value=""><?php esc_html_e( 'Writing default', 'ai-blog-writer' ); ?></option>
						<?php foreach ( AIBW_Images::modes() as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $auto['images'], $key ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Image providers', 'ai-blog-writer' ); ?></th><td>
					<select name="image_primary"><option value=""><?php esc_html_e( 'Accounts default', 'ai-blog-writer' ); ?></option>
						<?php foreach ( AIBW_Images::sources() as $id => $src ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( $auto['image_primary'], $id ); ?>><?php echo esc_html( $src['label'] ); ?></option><?php endforeach; ?>
					</select>
					<select name="image_fallback"><option value=""><?php esc_html_e( 'Other connected provider', 'ai-blog-writer' ); ?></option>
						<?php foreach ( AIBW_Images::sources() as $id => $src ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( $auto['image_fallback'], $id ); ?>><?php echo esc_html( $src['label'] ); ?></option><?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Research', 'ai-blog-writer' ); ?></th><td>
					<select name="research_mode">
						<option value="required" <?php selected( $auto['research_mode'], 'required' ); ?>><?php esc_html_e( 'Required', 'ai-blog-writer' ); ?></option>
						<option value="optional" <?php selected( $auto['research_mode'], 'optional' ); ?>><?php esc_html_e( 'Optional', 'ai-blog-writer' ); ?></option>
						<option value="off" <?php selected( $auto['research_mode'], 'off' ); ?>><?php esc_html_e( 'Off', 'ai-blog-writer' ); ?></option>
					</select>
					<select name="research_provider">
						<?php foreach ( AIBW_Research::providers() as $id => $label ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( $auto['research_provider'], $id ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
					</select>
					<p><label><input type="checkbox" name="allow_warning_drafts" value="1" <?php checked( ! empty( $auto['allow_warning_drafts'] ) ); ?> /> <?php esc_html_e( 'Still save a draft when research warnings remain (off by default).', 'ai-blog-writer' ); ?></label></p>
					<p><label><?php esc_html_e( 'Brave Search key', 'ai-blog-writer' ); ?> <input type="password" name="brave_key" value="" autocomplete="off" /></label></p>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'SEO checks', 'ai-blog-writer' ); ?></th><td><label><input type="checkbox" name="seo_checks" value="1" <?php checked( ! empty( $auto['seo_checks'] ) ); ?> /> <?php esc_html_e( 'Run heading, keyword and metadata checks', 'ai-blog-writer' ); ?></label>
					<p class="description"><?php echo AIBW_SEO::active_plugin() ? esc_html__( 'An SEO plugin is active. Focus fields are copied into that plugin only.', 'ai-blog-writer' ) : esc_html__( 'No SEO plugin is active. Fields stay on the draft and are not printed as frontend meta tags.', 'ai-blog-writer' ); ?></p>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Email', 'ai-blog-writer' ); ?></th><td>
					<?php
					$mails = array(
						'notify_success'  => __( 'Draft created', 'ai-blog-writer' ),
						'notify_failure'  => __( 'Failed job', 'ai-blog-writer' ),
						'notify_auth'     => __( 'Authentication failure', 'ai-blog-writer' ),
						'notify_research' => __( 'Research failure', 'ai-blog-writer' ),
						'notify_images'   => __( 'Image failure', 'ai-blog-writer' ),
						'notify_budget'   => __( 'Budget warning', 'ai-blog-writer' ),
					);
					foreach ( $mails as $key => $label ) :
						?>
						<label><input type="checkbox" name="<?php echo esc_attr( $key ); ?>" value="1" <?php checked( ! empty( $auto[ $key ] ) ); ?> /> <?php echo esc_html( $label ); ?></label><br>
					<?php endforeach; ?>
				</td></tr>
				<tr><th scope="row"><label for="aibw-budget"><?php esc_html_e( 'Daily estimated budget (USD)', 'ai-blog-writer' ); ?></label></th><td><input id="aibw-budget" name="daily_budget" type="number" min="0" step="0.01" value="<?php echo esc_attr( $auto['daily_budget'] ); ?>" /> <span class="description"><?php esc_html_e( '0 means no limit. Only models with a known public price are counted, and the amount is an estimate.', 'ai-blog-writer' ); ?></span></td></tr>
				<tr><th scope="row"><label for="aibw-retries"><?php esc_html_e( 'Max retries', 'ai-blog-writer' ); ?></label></th><td><input id="aibw-retries" name="max_retries" type="number" min="0" max="5" value="<?php echo (int) $auto['max_retries']; ?>" /></td></tr>
				<tr><th scope="row"><label for="aibw-step"><?php esc_html_e( 'Step time limit (seconds)', 'ai-blog-writer' ); ?></label></th><td><input id="aibw-step" name="max_step_seconds" type="number" min="15" max="90" value="<?php echo (int) $auto['max_step_seconds']; ?>" /></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Topics', 'ai-blog-writer' ); ?></th><td>
					<select name="topic_mode">
						<option value="queue" <?php selected( $auto['topic_mode'], 'queue' ); ?>><?php esc_html_e( 'Only topics I add', 'ai-blog-writer' ); ?></option>
						<option value="ideas" <?php selected( $auto['topic_mode'], 'ideas' ); ?>><?php esc_html_e( 'Approved AI suggestions plus my topics', 'ai-blog-writer' ); ?></option>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="aibw-keep"><?php esc_html_e( 'Keep logs (days)', 'ai-blog-writer' ); ?></label></th><td><input id="aibw-keep" name="log_retention_days" type="number" min="1" value="<?php echo (int) $auto['log_retention_days']; ?>" /></td></tr>
			</table>
			<?php submit_button( __( 'Save automation', 'ai-blog-writer' ) ); ?>
		</form>
	</div>

	<div class="aibw-card" id="aibw-logs">
		<h2><?php esc_html_e( 'Logs', 'ai-blog-writer' ); ?></h2>
		<form method="get">
			<input type="hidden" name="page" value="aibw-automation" />
			<label><?php esc_html_e( 'From', 'ai-blog-writer' ); ?> <input type="date" name="after" value="<?php echo isset( $_GET['after'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_GET['after'] ) ) ) : ''; ?>" /></label>
			<label><?php esc_html_e( 'Severity', 'ai-blog-writer' ); ?>
				<select name="severity"><option value=""><?php esc_html_e( 'Any', 'ai-blog-writer' ); ?></option><option value="info">info</option><option value="warning">warning</option><option value="error">error</option></select>
			</label>
			<label><?php esc_html_e( 'Provider', 'ai-blog-writer' ); ?> <input name="provider" value="<?php echo isset( $_GET['provider'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_GET['provider'] ) ) ) : ''; ?>" /></label>
			<label><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?> <input name="topic" value="<?php echo isset( $_GET['topic'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_GET['topic'] ) ) ) : ''; ?>" /></label>
			<button class="button"><?php esc_html_e( 'Filter', 'ai-blog-writer' ); ?></button>
		</form>
		<?php
		$filter = array(
			'severity' => isset( $_GET['severity'] ) ? sanitize_key( wp_unslash( $_GET['severity'] ) ) : '',
			'provider' => isset( $_GET['provider'] ) ? sanitize_text_field( wp_unslash( $_GET['provider'] ) ) : '',
			'topic'    => isset( $_GET['topic'] ) ? sanitize_text_field( wp_unslash( $_GET['topic'] ) ) : '',
			'after'    => isset( $_GET['after'] ) ? sanitize_text_field( wp_unslash( $_GET['after'] ) ) : '',
		);
		$rows = AIBW_Jobs::query_logs( $filter );
		?>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'Time', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Job', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Stage', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Severity', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Provider', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Post', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Message', 'ai-blog-writer' ); ?></th></tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?><tr><td colspan="8"><?php esc_html_e( 'No log rows.', 'ai-blog-writer' ); ?></td></tr><?php endif; ?>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row->created_at ); ?></td>
					<td><?php echo (int) $row->job_id; ?></td>
					<td><?php echo esc_html( $row->topic ); ?></td>
					<td><?php echo esc_html( $row->stage ); ?></td>
					<td><?php echo esc_html( $row->severity ); ?></td>
					<td><?php echo esc_html( $row->provider ); ?></td>
					<td><?php echo $row->post_id ? (int) $row->post_id : ''; ?></td>
					<td><?php echo esc_html( $row->message ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
