<?php
/**
 * Home: latest journal posts (used when WooCommerce is not active).
 */

$marina_posts = new WP_Query(
    array(
        'posts_per_page'      => 3,
        'ignore_sticky_posts' => true,
    )
);

if ( ! $marina_posts->have_posts() ) {
    return;
}
?>
<section class="section section--low">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow"><?php esc_html_e( 'The Journal', 'marina-clothing' ); ?></span>
                <h2 class="section-head__title"><?php esc_html_e( 'Latest Style Notes', 'marina-clothing' ); ?></h2>
            </div>
        </div>
        <div class="post-grid">
            <?php
            while ( $marina_posts->have_posts() ) {
                $marina_posts->the_post();
                get_template_part( 'template-parts/content', 'card' );
            }
            wp_reset_postdata();
            ?>
        </div>
    </div>
</section>
