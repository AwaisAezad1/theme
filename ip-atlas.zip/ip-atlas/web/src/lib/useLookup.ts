import { useCallback, useEffect, useRef, useState } from 'react';
import { ApiClientError, lookupIp } from './api';
import type { LookupResponse } from '../types';

export interface LookupState {
  loading: boolean;
  data: LookupResponse | null;
  error: string | null;
  /** The query that produced `data` ("" means the visitor's own IP). */
  query: string;
}

/**
 * Runs lookups, cancelling any request that is still in flight so a slow older response can never
 * overwrite a newer one. The last good result stays on screen (dimmed) while a new one loads.
 */
export function useLookup() {
  const [state, setState] = useState<LookupState>({ loading: true, data: null, error: null, query: '' });
  const controller = useRef<AbortController | null>(null);

  const run = useCallback(async (query: string) => {
    controller.current?.abort();
    const ctl = new AbortController();
    controller.current = ctl;
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await lookupIp(query, ctl.signal);
      if (ctl.signal.aborted) return;
      setState({ loading: false, data, error: null, query });
    } catch (err) {
      if (ctl.signal.aborted) return;
      const message = err instanceof ApiClientError ? err.message : 'Lookup failed. Please try again.';
      setState((s) => ({ ...s, loading: false, error: message }));
    }
  }, []);

  useEffect(() => () => controller.current?.abort(), []);

  return { ...state, run };
}
