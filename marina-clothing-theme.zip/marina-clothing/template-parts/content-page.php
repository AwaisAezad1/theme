<?php
/**
 * Page content.
 *
 * WooCommerce cart / checkout / account pages get a compact header and a
 * wide container; regular pages get the editorial header and prose width
 * (wide/full-aligned blocks can still break out).
 */

$marina_is_wc_page = marina_is_woocommerce_active() && ( is_cart() || is_checkout() || is_account_page() );
$marina_eyebrow    = '';

if ( $marina_is_wc_page ) {
    if ( is_cart() ) {
        $marina_eyebrow = __( 'Your Selection', 'marina-clothing' );
    } elseif ( is_checkout() ) {
        $marina_eyebrow = __( 'Secure Checkout', 'marina-clothing' );
    } else {
        $marina_eyebrow = __( 'Your Account', 'marina-clothing' );
    }
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $marina_is_wc_page ? 'page-commerce' : 'page-editorial' ); ?>>
    <?php
    marina_page_header(
        get_the_title(),
        array(
            'eyebrow' => $marina_eyebrow,
            'compact' => $marina_is_wc_page,
        )
    );
    ?>

    <?php if ( has_post_thumbnail() && ! $marina_is_wc_page ) : ?>
        <figure class="container article-cover">
            <?php the_post_thumbnail( 'full' ); ?>
        </figure>
    <?php endif; ?>

    <div class="section section--tight">
        <div class="container <?php echo $marina_is_wc_page ? '' : 'container--prose'; ?> entry-content">
            <?php
            the_content();

            wp_link_pages(
                array(
                    'before' => '<nav class="page-links">' . esc_html__( 'Pages:', 'marina-clothing' ),
                    'after'  => '</nav>',
                )
            );
            ?>
        </div>
    </div>

    <?php if ( ! $marina_is_wc_page && ( comments_open() || get_comments_number() ) ) : ?>
        <div class="container container--prose">
            <?php comments_template(); ?>
        </div>
    <?php endif; ?>
</article>
