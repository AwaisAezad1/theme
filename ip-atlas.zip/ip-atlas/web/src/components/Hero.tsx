import { useId, type FormEvent } from 'react';
import { Icon } from './Icons';

interface Props {
  value: string;
  onChange: (v: string) => void;
  onSubmit: (query: string) => void;
  onUseMyIp: () => void;
  loading: boolean;
  error: string | null;
}

export default function Hero({ value, onChange, onSubmit, onUseMyIp, loading, error }: Props) {
  const inputId = useId();
  const hintId = useId();

  function submit(e: FormEvent) {
    e.preventDefault();
    onSubmit(value.trim());
  }

  return (
    <section id="lookup" className="hero-grid relative border-b border-white/[0.06]">
      <div className="orb orb-one" />
      <div className="orb orb-two" />
      <div className="relative z-10 mx-auto max-w-7xl px-5 pb-12 pt-14 text-center sm:pt-16 lg:px-8 lg:pb-16 lg:pt-20">
        <div className="eyebrow mx-auto mb-6">
          <span className="h-1.5 w-1.5 rounded-full bg-cyan-300 shadow-[0_0_8px_#67e8f9]" />
          MaxMind · IPinfo · IP2Location
        </div>
        <h1 className="mx-auto max-w-4xl text-4xl font-semibold leading-[1.08] tracking-[-0.04em] text-white sm:text-6xl lg:text-[68px]">
          Know where any <span className="text-gradient">IP lives.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-base leading-7 text-slate-400 sm:text-lg">
          Instantly uncover location, network, and timezone data for any IPv4 or IPv6 address, and compare what three leading providers report.
        </p>

        <form onSubmit={submit} className="mx-auto mt-10 max-w-3xl" role="search" noValidate>
          <label htmlFor={inputId} className="sr-only">IP address</label>
          <div className="search-shell">
            <Icon name="search" className="ml-1 h-5 w-5 shrink-0 text-slate-500" />
            <input
              id={inputId}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="Enter an IP address, e.g. 8.8.8.8"
              autoComplete="off"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              inputMode="text"
              maxLength={60}
              aria-invalid={error ? true : undefined}
              aria-describedby={hintId}
              className="min-w-0 flex-1 bg-transparent px-2 text-sm text-white placeholder:text-slate-600 sm:px-3 sm:text-base"
            />
            <button type="button" onClick={onUseMyIp} className="detect-button">
              <Icon name="locate" className="h-4 w-4" />
              <span className="hidden sm:inline">Use my IP</span>
              <span className="sm:hidden">My IP</span>
            </button>
            <button type="submit" className="lookup-button" aria-busy={loading}>
              {loading ? 'Locating…' : 'Look up'}
            </button>
          </div>
          <p id={hintId} role={error ? 'alert' : undefined} className={`mt-3 text-left text-sm ${error ? 'text-rose-400' : 'text-xs text-slate-500'}`}>
            {error ?? 'Supports public IPv4 and IPv6 addresses'}
          </p>
        </form>
      </div>
    </section>
  );
}
