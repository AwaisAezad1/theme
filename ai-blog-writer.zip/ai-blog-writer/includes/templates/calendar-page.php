<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'Content Calendar', 'ai-blog-writer' ); ?></h1>
	<p class="aibw-lead"><?php esc_html_e( 'Topics with a date stay in the queue until that date. Topics without a date can run on the next automation pass.', 'ai-blog-writer' ); ?></p>
	<?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Date', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Status', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Priority', 'ai-blog-writer' ); ?></th></tr></thead>
		<tbody>
		<?php
		$any = false;
		foreach ( $topics as $topic ) :
			if ( ! $topic->scheduled_date || '0000-00-00' === $topic->scheduled_date ) {
				continue;
			}
			$any = true;
			?>
			<tr>
				<td><?php echo esc_html( $topic->scheduled_date ); ?></td>
				<td><?php echo esc_html( $topic->title ); ?></td>
				<td><?php echo esc_html( $topic->status ); ?></td>
				<td><?php echo (int) $topic->priority; ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if ( ! $any ) : ?><tr><td colspan="4"><?php esc_html_e( 'No dated topics yet. Add a date from the Topic Queue.', 'ai-blog-writer' ); ?></td></tr><?php endif; ?>
		</tbody>
	</table>
</div>
