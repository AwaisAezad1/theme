# IP Atlas

A website and JSON API that shows where an IP address is, using three geolocation providers side by side:
**MaxMind GeoLite2**, **IPinfo** and **IP2Location LITE**.

* Detects the visitor's IP and lets anyone look up any IPv4 / IPv6 address
* Shows a merged summary plus a provider-by-provider comparison (and flags where providers disagree)
* Developer API: `GET /api/v1/ip/{ip}`, CORS enabled, rate limited, optional API keys
* One Node.js process serves both the website and the API; the databases are local files, so lookups take microseconds, cost nothing per request, and keep working if a vendor is down

## Quick start (local)

Requires **Node.js 20.12 or newer** (22 recommended).

```bash
npm ci
cp .env.example .env        # then add your free database credentials, see docs/SETUP.md
npm run db:update           # downloads the three databases into ./data
npm run db:check            # verifies every database with sample lookups
npm run build
npm start                   # http://localhost:3000
```

While developing, `npm run dev` runs the API on :3000 and the website with hot reload on :5173.
Locally your IP is `127.0.0.1` (a private address), so set `DEV_CLIENT_IP=8.8.8.8` in `.env` to see real data for "your IP", or type any public IP into the search box.

## Project layout

```
ip-atlas/
├── server/                   Node.js + TypeScript + Fastify
│   ├── src/
│   │   ├── index.ts          starts the server, graceful shutdown
│   │   ├── app.ts            Fastify setup: security headers, compression, static site, error handling
│   │   ├── config.ts         every setting, read from environment / .env, validated at startup
│   │   ├── routes/api.ts     /api/v1/* endpoints, CORS, rate limit, API keys, client-IP detection
│   │   ├── services/lookup.ts  merges the providers into one summary
│   │   ├── providers/        one adapter per provider (maxmind, ipinfo, ip2location) + registry
│   │   ├── lib/ip.ts         strict IP parsing, private-range detection, trusted proxies
│   │   └── cli/              db:update and db:check commands
│   └── test/                 server tests (use MaxMind's official test databases)
├── web/                      React + Vite + Tailwind (your Figma design)
│   └── src/                  App, components/, lib/ (API client, formatting), tests
├── data/                     database files live here (not committed)
├── deploy/                   nginx, systemd service + timer examples
├── docs/                     SETUP.md (accounts & databases), DEPLOYMENT.md (going live)
├── Dockerfile, docker-compose.yml
└── .env.example              all settings, documented
```

## Commands

| Command | What it does |
|---|---|
| `npm run dev` | API + website with hot reload |
| `npm run build` | Builds the website and compiles the server |
| `npm start` | Runs the production server |
| `npm test` | Runs all server and website tests |
| `npm run typecheck` | TypeScript checks for both |
| `npm run db:update` | Downloads / refreshes databases (skips ones that are still fresh; `-- --force`, `-- --only=maxmind`) |
| `npm run db:check` | Shows which databases are loaded and runs sample lookups |

## API

Base URL is your domain. No signup is needed for light use.

| Endpoint | Description |
|---|---|
| `GET /api/v1/ip` | Lookup of the caller's own IP |
| `GET /api/v1/ip/{ip}` | Lookup of any IPv4 / IPv6 address |
| `GET /api/v1/status` | Loaded databases, build dates, rate limits |
| `GET /ip` | Caller's IP as plain text (`curl yourdomain.com/ip`) |
| `GET /healthz` | Liveness check for load balancers |

Query parameters: `providers=maxmind,ipinfo` (limit providers), `pretty=1` (indented JSON).

```bash
curl "https://your-domain.com/api/v1/ip/8.8.8.8?pretty=1"
```

Response shape (abridged):

```json
{
  "ip": "8.8.8.8", "version": 4, "is_public": true, "range": "public",
  "summary": {
    "country_code": "US", "country": "United States", "region": "California", "city": "Mountain View",
    "latitude": 37.4, "longitude": -122.07,
    "timezone": { "id": "America/Los_Angeles", "utc_offset": "-07:00", "local_time": "2026-10-12T00:00:00-07:00" },
    "asn": 15169, "organization": "Google LLC",
    "sources": { "location": "maxmind", "network": "maxmind" },
    "country_agreement": { "matching": 3, "total": 3 }
  },
  "providers": {
    "maxmind":     { "status": "ok", "data": { "...": "..." } },
    "ipinfo":      { "status": "ok", "data": { "...": "..." } },
    "ip2location": { "status": "ok", "data": { "...": "..." } }
  }
}
```

Provider `status` is one of `ok`, `no_data` (database has no entry), `unavailable` (database not installed), `skipped`, `error`.
Private / loopback / reserved addresses return `is_public: false` with a `notice` and no lookups.

Errors are always JSON: `{"error": {"code": "invalid_ip", "message": "...", "status": 400}}`.
Codes: `invalid_ip` (400), `invalid_providers` (400), `invalid_api_key` (401), `not_found` (404), `rate_limited` (429), `internal_error` (500).

**Rate limits:** 60 requests/minute per IP by default (`RATE_LIMIT_ANONYMOUS`). If you set `API_KEYS`, clients that send a valid key
(`Authorization: Bearer KEY` or `X-API-Key: KEY`) get `RATE_LIMIT_KEYED` (600) per minute instead. There is no self-service signup:
you create keys yourself (any random string) and give them to people. Responses carry `X-RateLimit-*` headers.

## Customising

* **Name, contact email, privacy note:** `web/src/config.ts`, then `npm run build`
* **Colours / look:** `web/src/index.css` and the Tailwind classes in `web/src/components/`
* **Page title / description:** `web/index.html`
* **Rate limits, keys, proxies, databases:** `.env`

## Licensing and attribution (important)

The free databases come with conditions. The site already shows the required attribution lines (footer of the "Data sources" section); keep them.

* **MaxMind GeoLite2:** requires attribution and that you keep the data reasonably up to date (the updater handles this; MaxMind's terms ask you to keep the data current; check the current EULA). You must accept their GeoLite2 EULA when you create the account.
* **IP2Location LITE:** requires attribution; updated monthly. Downloading more often than once a month can get the account disabled, so the updater downloads at most once per calendar month.
* **IPinfo:** the free Lite database covers country + ASN only (no city). City-level data requires a paid IPinfo plan, which you can plug in with `IPINFO_DOWNLOAD_URL` (see `.env.example`).

Using the results on a public website that you monetise (ads etc.) may need different license terms from some providers; check each provider's terms for your use.

You are also responsible for a privacy policy appropriate to your country: this site looks up IP addresses, which count as personal data in some jurisdictions. The app itself stores nothing and sets no cookies, and does not log requests unless you enable `LOG_REQUESTS`, but nginx / your host may log visitor IPs.
