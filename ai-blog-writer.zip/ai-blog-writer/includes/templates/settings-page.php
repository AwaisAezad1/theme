<?php
/**
 * "Settings" page - writing and publishing defaults.
 *
 * Variables: $settings, $categories, $static_front, $msg
 */
defined( 'ABSPATH' ) || exit;
?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'AI Blog Writer Settings', 'ai-blog-writer' ); ?></h1>

	<?php if ( $msg ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="aibw_save_settings">
		<?php wp_nonce_field( 'aibw_save_settings' ); ?>

		<div class="aibw-card">
			<h2><?php esc_html_e( 'Writing defaults', 'ai-blog-writer' ); ?></h2>
			<p class="description"><?php esc_html_e( 'These fill in the "More options" on the Write a Blog page. You can still change them for each blog.', 'ai-blog-writer' ); ?></p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="tone"><?php esc_html_e( 'Tone', 'ai-blog-writer' ); ?></label></th>
					<td>
						<select name="tone" id="tone">
							<?php foreach ( AIBW_Generator::tones() as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['tone'], $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="length"><?php esc_html_e( 'Length', 'ai-blog-writer' ); ?></label></th>
					<td>
						<select name="length" id="length">
							<?php foreach ( AIBW_Generator::lengths() as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['length'], $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="images"><?php esc_html_e( 'Pictures', 'ai-blog-writer' ); ?></label></th>
					<td>
						<select name="images" id="images">
							<?php foreach ( AIBW_Images::modes() as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['images'], $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Needs a free image source on the AI Accounts page.', 'ai-blog-writer' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="language"><?php esc_html_e( 'Language', 'ai-blog-writer' ); ?></label></th>
					<td><input type="text" name="language" id="language" class="regular-text" value="<?php echo esc_attr( $settings['language'] ); ?>"></td>
				</tr>
			</table>
		</div>

		<div class="aibw-card">
			<h2><?php esc_html_e( 'Publishing', 'ai-blog-writer' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="category"><?php esc_html_e( 'Default category', 'ai-blog-writer' ); ?></label></th>
					<td>
						<select name="category" id="category">
							<option value="0"><?php esc_html_e( 'WordPress default', 'ai-blog-writer' ); ?></option>
							<?php foreach ( $categories as $cat ) : ?>
								<option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( (int) $settings['category'], (int) $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Front page', 'ai-blog-writer' ); ?></th>
					<td>
						<label><input type="checkbox" name="sticky" value="1" <?php checked( ! empty( $settings['sticky'] ) ); ?>> <?php esc_html_e( 'Keep new blogs at the top of the front page (pre-ticked on the Write a Blog page)', 'ai-blog-writer' ); ?></label>
						<?php if ( $static_front ) : ?>
							<p class="description aibw-warn"><?php esc_html_e( 'Your front page is currently a fixed page, so posts do not show up there on their own. Either switch Settings > Reading to "Your latest posts", or add the shortcode [aibw_latest_blogs count="3"] to that page.', 'ai-blog-writer' ); ?></p>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'Your front page shows your latest posts, so "Add Blog to Front Page" works out of the box.', 'ai-blog-writer' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
			</table>
		</div>

		<?php submit_button( __( 'Save Settings', 'ai-blog-writer' ) ); ?>
	</form>
</div>
