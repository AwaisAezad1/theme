<?php
/**
 * Theme bootstrap.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WDS_VERSION', '1.0.0' );
define( 'WDS_DIR', get_template_directory() );
define( 'WDS_URI', get_template_directory_uri() );

/*
 * Core theme files.
 */
require_once WDS_DIR . '/inc/setup.php';
require_once WDS_DIR . '/inc/enqueue.php';
require_once WDS_DIR . '/inc/helpers.php';
require_once WDS_DIR . '/inc/ajax.php';

/*
 * WooCommerce integration.
 */
if ( class_exists( 'WooCommerce' ) || function_exists( 'is_woocommerce' ) ) {
    require_once WDS_DIR . '/inc/woocommerce.php';
}
