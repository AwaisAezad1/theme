<?php
/**
 * Off-canvas drawers: mobile navigation, mini cart, wishlist.
 */

$marina_wc = marina_is_woocommerce_active();
?>
<div class="drawer-overlay" data-drawer-overlay hidden></div>

<aside class="drawer drawer--left" id="nav-drawer" aria-label="<?php esc_attr_e( 'Menu', 'marina-clothing' ); ?>" aria-hidden="true" tabindex="-1">
    <div class="drawer__head">
        <span class="drawer__title"><?php esc_html_e( 'Menu', 'marina-clothing' ); ?></span>
        <button class="icon-btn" type="button" data-drawer-close aria-label="<?php esc_attr_e( 'Close', 'marina-clothing' ); ?>"><?php marina_the_icon( 'close' ); ?></button>
    </div>
    <div class="drawer__body">
        <?php get_search_form(); ?>
        <nav class="drawer-nav" aria-label="<?php esc_attr_e( 'Mobile Menu', 'marina-clothing' ); ?>">
            <?php
            wp_nav_menu(
                array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'menu_class'     => 'menu',
                    'fallback_cb'    => 'marina_primary_menu_fallback',
                )
            );
            ?>
        </nav>
        <?php if ( $marina_wc ) : ?>
            <a class="btn btn--ghost btn--block" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>">
                <?php marina_the_icon( 'person' ); ?>
                <span><?php echo is_user_logged_in() ? esc_html__( 'My Account', 'marina-clothing' ) : esc_html__( 'Sign In', 'marina-clothing' ); ?></span>
            </a>
        <?php endif; ?>
    </div>
</aside>

<?php if ( $marina_wc ) : ?>
    <aside class="drawer drawer--right" id="cart-drawer" aria-label="<?php esc_attr_e( 'Shopping bag', 'marina-clothing' ); ?>" aria-hidden="true" tabindex="-1">
        <div class="drawer__head">
            <span class="drawer__title"><?php esc_html_e( 'Your Bag', 'marina-clothing' ); ?></span>
            <button class="icon-btn" type="button" data-drawer-close aria-label="<?php esc_attr_e( 'Close', 'marina-clothing' ); ?>"><?php marina_the_icon( 'close' ); ?></button>
        </div>
        <div class="drawer__body drawer__body--cart">
            <div class="widget_shopping_cart_content">
                <?php woocommerce_mini_cart(); ?>
            </div>
        </div>
    </aside>

    <aside class="drawer drawer--right" id="wishlist-drawer" aria-label="<?php esc_attr_e( 'Wishlist', 'marina-clothing' ); ?>" aria-hidden="true" tabindex="-1">
        <div class="drawer__head">
            <span class="drawer__title"><?php esc_html_e( 'Saved Pieces', 'marina-clothing' ); ?></span>
            <button class="icon-btn" type="button" data-drawer-close aria-label="<?php esc_attr_e( 'Close', 'marina-clothing' ); ?>"><?php marina_the_icon( 'close' ); ?></button>
        </div>
        <div class="drawer__body">
            <ul class="wishlist-list" data-wishlist-list></ul>
        </div>
    </aside>
<?php endif; ?>
