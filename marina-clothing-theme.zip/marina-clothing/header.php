<?php
/**
 * Header.
 */

$marina_wc = marina_is_woocommerce_active();
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'marina-clothing' ); ?></a>

<header class="site-header" id="masthead">

    <div class="topbar">
        <div class="topbar__side topbar__side--left">
            <span><?php echo esc_html( marina_opt( 'topbar_left' ) ); ?></span>
        </div>
        <p class="topbar__announcement"><?php echo esc_html( marina_opt( 'announcement' ) ); ?></p>
        <div class="topbar__side topbar__side--right">
            <?php if ( $marina_wc ) : ?>
                <?php marina_the_icon( 'language' ); ?>
                <span><?php echo esc_html( get_woocommerce_currency() . ' (' . html_entity_decode( get_woocommerce_currency_symbol() ) . ')' ); ?></span>
            <?php endif; ?>
        </div>
    </div>

    <div class="masthead">
        <div class="masthead__left">
            <button class="icon-btn masthead__menu-toggle" type="button" data-drawer-open="nav-drawer" aria-controls="nav-drawer" aria-expanded="false">
                <?php marina_the_icon( 'menu' ); ?>
                <span class="screen-reader-text"><?php esc_html_e( 'Open menu', 'marina-clothing' ); ?></span>
            </button>

            <form role="search" method="get" class="header-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <label class="screen-reader-text" for="header-search-input"><?php esc_html_e( 'Search', 'marina-clothing' ); ?></label>
                <?php marina_the_icon( 'search' ); ?>
                <input id="header-search-input" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr( $marina_wc ? __( 'Search garments, fabrics...', 'marina-clothing' ) : __( 'Search...', 'marina-clothing' ) ); ?>">
                <?php if ( $marina_wc ) : ?>
                    <input type="hidden" name="post_type" value="product">
                <?php endif; ?>
            </form>
        </div>

        <div class="brand">
            <?php marina_brand(); ?>
            <?php if ( marina_opt( 'brand_tagline' ) ) : ?>
                <p class="brand__tagline"><?php echo esc_html( marina_opt( 'brand_tagline' ) ); ?></p>
            <?php endif; ?>
        </div>

        <div class="masthead__actions">
            <button class="icon-btn masthead__search-toggle" type="button" data-search-toggle aria-label="<?php esc_attr_e( 'Search', 'marina-clothing' ); ?>">
                <?php marina_the_icon( 'search' ); ?>
            </button>

            <?php if ( $marina_wc ) : ?>
                <button class="icon-btn" type="button" data-drawer-open="wishlist-drawer" aria-controls="wishlist-drawer" aria-label="<?php esc_attr_e( 'Wishlist', 'marina-clothing' ); ?>">
                    <?php marina_the_icon( 'favorite' ); ?>
                    <span class="count-badge count-badge--accent" data-wishlist-count hidden>0</span>
                </button>

                <a class="icon-btn" href="<?php echo esc_url( wc_get_cart_url() ); ?>" data-drawer-open="cart-drawer" aria-controls="cart-drawer" aria-label="<?php esc_attr_e( 'Shopping bag', 'marina-clothing' ); ?>">
                    <?php marina_the_icon( 'shopping_bag' ); ?>
                    <?php marina_cart_count_badge(); ?>
                </a>

                <a class="account-btn" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" aria-label="<?php esc_attr_e( 'My account', 'marina-clothing' ); ?>">
                    <?php marina_the_icon( 'person' ); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <nav class="primary-nav" aria-label="<?php esc_attr_e( 'Primary Menu', 'marina-clothing' ); ?>">
        <?php
        wp_nav_menu(
            array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'menu',
                'depth'          => 2,
                'fallback_cb'    => 'marina_primary_menu_fallback',
            )
        );
        ?>
    </nav>

    <div class="mobile-search" data-mobile-search hidden>
        <div class="container">
            <?php get_search_form(); ?>
        </div>
    </div>
</header>

<?php get_template_part( 'template-parts/drawers' ); ?>
