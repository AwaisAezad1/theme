/**
 * Prints the state of every provider and runs sample lookups, so you can confirm a fresh setup works:
 *   npm run db:check
 */
import { loadConfig } from '../config.js';
import { ProviderRegistry } from '../providers/registry.js';
import { PROVIDER_IDS } from '../providers/types.js';

const SAMPLES = ['8.8.8.8', '1.1.1.1', '2001:4860:4860::8888'];

async function main(): Promise<void> {
  const config = loadConfig();
  const quiet = { info() {}, warn() {}, error: (m: string) => console.error(`  ! ${m}`) };
  const registry = ProviderRegistry.fromConfig(config, quiet);
  await registry.init();

  let problems = 0;
  console.log('Providers');
  for (const info of registry.info()) {
    const state = info.loaded ? 'loaded' : 'NOT INSTALLED';
    console.log(`  ${info.name.padEnd(12)} ${state.padEnd(14)} ${info.source}${info.database_date ? `, built ${info.database_date}` : ''}`);
    if (info.warning) {
      console.log(`    warning: ${info.warning}`);
      problems++;
    }
    if (!info.loaded) problems++;
  }

  console.log('\nSample lookups');
  for (const ip of SAMPLES) {
    console.log(`  ${ip}`);
    const results = await registry.lookup(ip);
    for (const id of PROVIDER_IDS) {
      const r = results[id];
      if (!r) continue;
      const d = r.data;
      const detail = d
        ? [d.city, d.region, d.country_code, d.asn ? `AS${d.asn}` : null, d.organization ?? d.isp].filter(Boolean).join(', ')
        : (r.message ?? '');
      console.log(`    ${id.padEnd(12)} ${r.status.padEnd(12)} ${detail}`);
    }
  }

  registry.close();
  console.log(problems ? `\n${problems} problem(s) found. See docs/SETUP.md.` : '\nAll providers look healthy.');
  process.exit(problems ? 1 : 0);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
