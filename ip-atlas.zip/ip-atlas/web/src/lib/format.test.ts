import { describe, expect, it } from 'vitest';
import { coordinatesDiffer, formatClock, formatCoordinates, formatDate, valuesDiffer, visibleRows } from './format';
import { blank } from '../test/fixtures';

describe('format helpers', () => {
  it('formats coordinates, clock and dates', () => {
    expect(formatCoordinates(51.51417, -0.09313)).toBe('51.5142, -0.0931');
    expect(formatCoordinates(null, 1)).toBeNull();
    expect(formatClock('2026-10-12T07:05:09+01:00')).toBe('07:05');
    expect(formatClock(null)).toBeNull();
    expect(formatDate('2026-10-06')).toBe('6 Oct 2026');
    expect(formatDate('2026-10-12T07:00:00+01:00')).toBe('12 Oct 2026');
    expect(formatDate('nope')).toBeNull();
  });

  it('detects disagreement only when 2+ providers answered and values differ (accent/case insensitive)', () => {
    expect(valuesDiffer(['London', 'london'])).toBe(false);
    expect(valuesDiffer(['Zürich', 'Zurich'])).toBe(false);
    expect(valuesDiffer(['London', 'Leeds'])).toBe(true);
    expect(valuesDiffer(['London', null, null])).toBe(false);
    expect(valuesDiffer([null, null])).toBe(false);
  });

  it('flags coordinates more than 100 km apart', () => {
    expect(coordinatesDiffer([[51.51, -0.09], [51.50, -0.12]])).toBe(false);
    expect(coordinatesDiffer([[51.51, -0.09], [53.48, -2.24]])).toBe(true);
    expect(coordinatesDiffer([[51.51, -0.09], null])).toBe(false);
  });

  it('hides optional rows when no provider has a value', () => {
    const results = [{ status: 'ok' as const, data: { ...blank, country_code: 'GB' } }];
    const keys = visibleRows(results).map((r) => r.key);
    expect(keys).not.toContain('accuracy');
    expect(keys).not.toContain('domain');
    expect(keys).toContain('city');
    const withRadius = [{ status: 'ok' as const, data: { ...blank, accuracy_radius_km: 10 } }];
    expect(visibleRows(withRadius).map((r) => r.key)).toContain('accuracy');
  });
});
