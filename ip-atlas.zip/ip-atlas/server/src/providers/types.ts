export type ProviderId = 'maxmind' | 'ipinfo' | 'ip2location';
export const PROVIDER_IDS: readonly ProviderId[] = ['maxmind', 'ipinfo', 'ip2location'];

/** Normalised geolocation record. Every provider maps its own schema onto this shape; missing data is null. */
export interface GeoRecord {
  country_code: string | null;
  country: string | null;
  continent_code: string | null;
  continent: string | null;
  region: string | null;
  city: string | null;
  postal_code: string | null;
  latitude: number | null;
  longitude: number | null;
  /** MaxMind only: radius in km around the coordinates in which the device is likely to be. */
  accuracy_radius_km: number | null;
  /** IANA timezone id, e.g. "Asia/Karachi". */
  timezone: string | null;
  /** Fixed UTC offset such as "+05:00" (IP2Location provides only this). */
  utc_offset: string | null;
  asn: number | null;
  organization: string | null;
  isp: string | null;
  domain: string | null;
}

export type ProviderStatus =
  /** A record was found. */
  | 'ok'
  /** The database is loaded but has no entry for this IP. */
  | 'no_data'
  /** The database is not installed / not configured. */
  | 'unavailable'
  /** Lookup was not attempted (e.g. private address). */
  | 'skipped'
  /** Lookup failed unexpectedly. */
  | 'error';

export interface ProviderResult {
  status: ProviderStatus;
  data: GeoRecord | null;
  message?: string;
}

export interface ProviderInfo {
  id: ProviderId;
  name: string;
  /** Human readable description of the data source, e.g. "GeoLite2 City + ASN (local database)". */
  source: string;
  loaded: boolean;
  /** ISO date (YYYY-MM-DD) the database was built, when known. */
  database_date: string | null;
  /** Free-form note shown to users, e.g. coverage limitations. */
  note: string | null;
  /** Set when the database loaded but looks wrong (failed self-test). */
  warning: string | null;
}

export interface GeoProvider {
  readonly id: ProviderId;
  readonly name: string;
  init(): Promise<void>;
  /** Re-open the database if the file on disk changed. Returns true when something was reloaded. */
  reloadIfChanged(): Promise<boolean>;
  lookup(ip: string): Promise<ProviderResult>;
  info(): ProviderInfo;
  close(): void;
}

export function emptyRecord(): GeoRecord {
  return {
    country_code: null,
    country: null,
    continent_code: null,
    continent: null,
    region: null,
    city: null,
    postal_code: null,
    latitude: null,
    longitude: null,
    accuracy_radius_km: null,
    timezone: null,
    utc_offset: null,
    asn: null,
    organization: null,
    isp: null,
    domain: null,
  };
}

/** True when the record carries at least one meaningful value. */
export function hasData(r: GeoRecord): boolean {
  return Object.values(r).some((v) => v !== null);
}
