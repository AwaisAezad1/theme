<?php
/**
 * WooCommerce compatibility.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Declare WooCommerce theme support.
 */
function wds_woocommerce_setup() {
    add_theme_support(
        'woocommerce',
        array(
            'thumbnail_image_width' => 600,
            'single_image_width'    => 800,
            'product_grid'          => array(
                'default_rows'    => 4,
                'min_rows'        => 1,
                'max_rows'        => 8,
                'default_columns' => 4,
                'min_columns'     => 1,
                'max_columns'     => 6,
            ),
        )
    );
}
add_action( 'after_setup_theme', 'wds_woocommerce_setup' );

/*
 * Add WooCommerce hooks and filters here.
 *
 * Examples:
 *
 * add_filter( 'woocommerce_product_add_to_cart_text', 'wds_change_add_to_cart_text' );
 * add_action( 'woocommerce_before_main_content', 'wds_before_woocommerce' );
 */
