<?php
/**
 * Home: "Shop by Category" bar.
 */

$marina_terms = marina_get_featured_categories( 5 );

if ( ! $marina_terms ) {
    return;
}

$marina_fallbacks = array( 'category-1', 'category-2', 'category-3', 'category-4', 'category-5' );
?>
<section class="section section--low home-cats">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow"><?php esc_html_e( 'Curation', 'marina-clothing' ); ?></span>
                <h2 class="section-head__title"><?php esc_html_e( 'Shop by Category', 'marina-clothing' ); ?></h2>
            </div>
            <a class="text-link" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">
                <span><?php esc_html_e( 'Explore All Categories', 'marina-clothing' ); ?></span>
                <?php marina_the_icon( 'arrow_forward' ); ?>
            </a>
        </div>

        <div class="cat-grid">
            <?php foreach ( $marina_terms as $marina_i => $marina_term ) : ?>
                <?php $marina_img = marina_category_image_url( $marina_term, marina_image( $marina_fallbacks[ $marina_i % 5 ] ) ); ?>
                <a class="cat-tile" href="<?php echo esc_url( get_term_link( $marina_term ) ); ?>">
                    <span class="cat-tile__image">
                        <img src="<?php echo esc_url( $marina_img ); ?>" alt="" loading="lazy">
                    </span>
                    <span class="cat-tile__name"><?php echo esc_html( $marina_term->name ); ?></span>
                    <span class="cat-tile__count">
                        <?php
                        /* translators: %s: number of products */
                        echo esc_html( sprintf( _n( '%s Piece', '%s Pieces', $marina_term->count, 'marina-clothing' ), number_format_i18n( $marina_term->count ) ) );
                        ?>
                    </span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
