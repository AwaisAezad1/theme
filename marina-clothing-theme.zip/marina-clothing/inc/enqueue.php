<?php
/**
 * Styles and scripts.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Google Fonts: Playfair Display, Plus Jakarta Sans and a subsetted
 * Material Symbols icon font (only the glyphs the theme uses).
 */
function marina_fonts_url() {
    return 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Plus+Jakarta+Sans:ital,wght@0,300..800;1,300..800&display=swap';
}

function marina_icons_url() {
    return 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,400,0..1,0&icon_names='
        . implode( ',', marina_icon_names() )
        . '&display=block';
}

/**
 * Cache-busting version for a theme file (its modification time).
 */
function marina_ver( $relative ) {
    $path = MARINA_DIR . '/' . ltrim( $relative, '/' );
    return file_exists( $path ) ? MARINA_VERSION . '.' . filemtime( $path ) : MARINA_VERSION;
}

function marina_enqueue_assets() {
    wp_enqueue_style( 'marina-fonts', marina_fonts_url(), array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
    wp_enqueue_style( 'marina-icons', marina_icons_url(), array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion

    wp_enqueue_style(
        'marina-style',
        get_stylesheet_uri(),
        array(),
        marina_ver( 'style.css' )
    );

    wp_enqueue_style(
        'marina-custom',
        MARINA_URI . '/assets/css/custom.css',
        array( 'marina-style' ),
        marina_ver( 'assets/css/custom.css' )
    );

    if ( marina_is_woocommerce_active() ) {
        wp_enqueue_style(
            'marina-woocommerce',
            MARINA_URI . '/assets/css/woocommerce.css',
            array( 'marina-custom' ),
            marina_ver( 'assets/css/woocommerce.css' )
        );

        // The header mini-cart drawer relies on cart fragments.
        wp_enqueue_script( 'wc-cart-fragments' );
    }

    wp_enqueue_script(
        'marina-main',
        MARINA_URI . '/assets/js/main.js',
        marina_is_woocommerce_active() ? array( 'jquery' ) : array(),
        marina_ver( 'assets/js/main.js' ),
        true
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }

    /*
     * Data available to main.js.
     */
    wp_localize_script(
        'marina-main',
        'marinaData',
        array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'marina_nonce' ),
            'homeUrl' => home_url( '/' ),
            'cartUrl' => marina_is_woocommerce_active() ? wc_get_cart_url() : '',
            'noDrawer' => marina_is_woocommerce_active() && ( is_cart() || is_checkout() ),
            'i18n'    => array(
                'added'          => __( 'Added', 'marina-clothing' ),
                'addedToBag'     => __( 'Added to your bag', 'marina-clothing' ),
                'wishlistEmpty'  => __( 'Your wishlist is empty. Tap the heart on any piece to save it here.', 'marina-clothing' ),
                'remove'         => __( 'Remove', 'marina-clothing' ),
                'subscribed'     => __( 'Welcome, you are on the list.', 'marina-clothing' ),
                'error'          => __( 'Something went wrong. Please try again.', 'marina-clothing' ),
                'selectOption'   => __( 'Select %s', 'marina-clothing' ),
            ),
        )
    );
}
add_action( 'wp_enqueue_scripts', 'marina_enqueue_assets' );

/**
 * Preconnect to Google Fonts.
 */
function marina_resource_hints( $urls, $relation_type ) {
    if ( 'preconnect' === $relation_type ) {
        $urls[] = 'https://fonts.googleapis.com';
        $urls[] = array(
            'href' => 'https://fonts.gstatic.com',
            'crossorigin',
        );
    }

    return $urls;
}
add_filter( 'wp_resource_hints', 'marina_resource_hints', 10, 2 );

/**
 * Admin-only assets.
 *
 * Add admin CSS/JS here when your project needs it.
 */
function marina_admin_assets() {
    // wp_enqueue_style(
    //     'marina-admin',
    //     MARINA_URI . '/assets/css/admin.css',
    //     array(),
    //     MARINA_VERSION
    // );
}
add_action( 'admin_enqueue_scripts', 'marina_admin_assets' );
