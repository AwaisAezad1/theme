import { SITE_NAME } from '../config';
import { Icon, LogoMark } from './Icons';

export default function Header() {
  return (
    <header className="relative z-20 border-b border-white/[0.07] bg-[#07111f]/90 backdrop-blur">
      <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between px-5 sm:h-[76px] lg:px-8">
        <a href="#lookup" className="flex items-center gap-2.5 text-cyan-300" aria-label={`${SITE_NAME} home`}>
          <LogoMark />
          <span className="text-lg font-bold tracking-tight text-white">{SITE_NAME}</span>
        </a>
        <nav aria-label="Main" className="hidden items-center gap-8 text-sm md:flex">
          <a href="#lookup" className="text-white">IP Lookup</a>
          <a href="#api" className="transition hover:text-white">API</a>
          <a href="#sources" className="transition hover:text-white">Data sources</a>
        </nav>
        <a href="#api" className="button-secondary">
          API docs <Icon name="arrow" className="h-4 w-4" />
        </a>
      </div>
    </header>
  );
}
