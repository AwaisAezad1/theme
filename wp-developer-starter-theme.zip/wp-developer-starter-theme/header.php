<?php
/**
 * Header.
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="container">

        <?php if ( has_custom_logo() ) : ?>
            <?php the_custom_logo(); ?>
        <?php else : ?>
            <h1 class="site-title">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <?php bloginfo( 'name' ); ?>
                </a>
            </h1>

            <p class="site-description">
                <?php bloginfo( 'description' ); ?>
            </p>
        <?php endif; ?>

        <nav class="site-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'wp-developer-starter' ); ?>">
            <?php
            wp_nav_menu(
                array(
                    'theme_location' => 'primary',
                    'fallback_cb'    => false,
                )
            );
            ?>
        </nav>

    </div>
</header>
