# Marina Clothing

Editorial WooCommerce theme for the Marina Clothing store. The home page and single
product page follow the two Stitch mockups (`stitch_marina_clothing_website_design (1|2).zip`);
every other template (shop, categories, cart, checkout, account, blog, pages,
search, 404) uses the same design system.

## Design system

* Tokens (colours, type, radius, spacing, shadows) live as CSS custom properties
  at the top of `style.css`, mirroring `DESIGN.md` from the mockups.
* Fonts: Playfair Display (headings) + Plus Jakarta Sans (UI/body), and a
  Material Symbols icon font **subset** to the glyphs listed in
  `marina_icon_names()` (`inc/helpers.php`). Add a name there when you use a new icon.
* CSS: `style.css` (tokens, base, buttons) → `assets/css/custom.css` (layout,
  header/footer, home, blog) → `assets/css/woocommerce.css` (shop, product,
  mini-cart, cart/checkout blocks, account).

## What's dynamic

| Section | Source |
| --- | --- |
| Header menu / footer columns | Menu locations *Primary*, *Footer: Collections*, *Footer: Concierge*, *Footer: Legal* (fallback: product categories & account pages) |
| Home categories | Most-populated product categories (image: category thumbnail → a product photo → bundled image) |
| Walk-in closet, spotlight | Featured products, then best sellers (only products with a real photo) |
| Trending grid | Best sellers, filterable by category |
| Product page | Gallery images + captions, variation swatches (auto-built from the variation selects), tabs as accordions, upsells/cross-sells/related as "Complete the look", reviews ledger with rating breakdown |
| Copy & imagery | Appearance → Customize → **Marina Theme** |

## Behaviour

* AJAX "Quick add" anywhere + slide-in bag drawer (cart fragments).
* Wishlist drawer — client-side (localStorage), no plugin needed.
* Newsletter forms store emails in the `marina_newsletter_subscribers` option and
  fire `do_action( 'marina_newsletter_subscribed', $email )` for ESP integrations.
* Product page: hover magnifier, thumbnail carousel, swipe, full-screen viewer,
  size guide (shown when a product has a "size" attribute; rows filterable via
  `marina_size_guide_rows`), sticky mobile buy bar.

## WooCommerce template overrides

`woocommerce/archive-product.php`, `content-product.php`, `content-single-product.php`,
`single-product-reviews.php`, `loop/loop-start.php`, plus theme-only partials in
`woocommerce/single-product/marina-*.php`. Standard hooks still fire.

## Developer notes

* PHP functions, constants and handles use the `marina_` / `MARINA_` / `marina-` prefix.
* Text domain: `marina-clothing` (translations go in `languages/`).
* Front-end data is exposed to `assets/js/main.js` as `marinaData`; a small
  `marinaAjax( action, data )` helper is available for admin-ajax calls.
