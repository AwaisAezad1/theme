import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { after, describe, it } from 'node:test';
import type { FastifyInstance } from 'fastify';
import { makeApp } from './helpers.js';

const apps: FastifyInstance[] = [];
async function app(overrides: Record<string, string> = {}, realIp2 = false) {
  const a = await makeApp(overrides, { realIp2 });
  apps.push(a);
  return a;
}
after(async () => {
  await Promise.all(apps.map((a) => a.close()));
});

const json = (res: { body: string }) => JSON.parse(res.body);

describe('GET /api/v1/ip/:ip', () => {
  it('returns provider data and a summary for a public IPv4', async () => {
    const a = await app({}, true);
    const res = await a.inject('/api/v1/ip/81.2.69.142');
    assert.equal(res.statusCode, 200);
    assert.match(res.headers['content-type'] as string, /application\/json/);
    const body = json(res);
    assert.equal(body.ip, '81.2.69.142');
    assert.equal(body.version, 4);
    assert.equal(body.is_public, true);
    assert.equal(body.providers.maxmind.status, 'ok');
    assert.equal(body.providers.maxmind.data.city, 'London');
    assert.equal(body.providers.ipinfo.status, 'ok');
    assert.equal(body.providers.ip2location.status, 'ok');
    assert.equal(body.summary.city, 'London');
    assert.equal(body.summary.country_code, 'GB');
    assert.equal(body.summary.sources.location, 'maxmind');
    assert.deepEqual(body.summary.country_agreement, { matching: 3, total: 3 });
    assert.equal(body.summary.timezone.id, 'Europe/London');
    assert.match(body.summary.timezone.utc_offset, /^[+-]\d{2}:\d{2}$/);
    assert.match(body.summary.timezone.local_time, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}$/);
    assert.equal(res.headers['cache-control'], 'public, max-age=300');
  });

  it('works for IPv6 (including URL-encoded and expanded forms)', async () => {
    const a = await app();
    const res = await a.inject('/api/v1/ip/2a02:ff00::1');
    assert.equal(res.statusCode, 200);
    assert.equal(json(res).version, 6);
    assert.equal(json(res).summary.country_code, 'IT');
    const enc = await a.inject('/api/v1/ip/2a02%3Aff00%3A0%3A0%3A0%3A0%3A0%3A1');
    assert.equal(enc.statusCode, 200);
    assert.equal(json(enc).ip, '2a02:ff00::1');
  });

  it('marks providers without data / without a database honestly', async () => {
    const a = await app();
    const body = json(await a.inject('/api/v1/ip/81.2.69.142'));
    assert.equal(body.providers.ip2location.status, 'unavailable');
    assert.deepEqual(body.summary.country_agreement, { matching: 2, total: 2 });
    const unknown = json(await a.inject('/api/v1/ip/8.8.8.8'));
    assert.equal(unknown.providers.maxmind.status, 'no_data');
    assert.equal(unknown.providers.ipinfo.status, 'ok');
    assert.equal(unknown.summary.country_code, 'GB'); // falls back to the provider that has an answer
  });

  it('does not look up private or reserved addresses', async () => {
    const a = await app();
    for (const [ip, range] of [
      ['192.168.1.10', 'private'],
      ['127.0.0.1', 'loopback'],
      ['::1', 'loopback'],
    ] as const) {
      const body = json(await a.inject(`/api/v1/ip/${encodeURIComponent(ip)}`));
      assert.equal(body.is_public, false);
      assert.equal(body.range, range);
      assert.equal(body.summary, null);
      assert.equal(body.providers.maxmind.status, 'skipped');
      assert.match(body.notice, /no public geolocation/);
    }
  });

  it('rejects invalid input with a 400 JSON error', async () => {
    const a = await app();
    for (const bad of ['abc', '1.2.3', '256.256.256.256', '8.8.8.8%2F24', 'fe80::1%25eth0', '0x7f.0.0.1']) {
      const res = await a.inject(`/api/v1/ip/${bad}`);
      assert.equal(res.statusCode, 400, bad);
      assert.equal(json(res).error.code, 'invalid_ip');
      assert.equal(json(res).error.status, 400);
    }
  });

  it('filters providers with ?providers=', async () => {
    const a = await app();
    const body = json(await a.inject('/api/v1/ip/81.2.69.142?providers=maxmind'));
    assert.equal(body.providers.maxmind.status, 'ok');
    assert.equal(body.providers.ipinfo.status, 'skipped');
    assert.equal(body.summary.country_agreement.total, 1);
    const bad = await a.inject('/api/v1/ip/81.2.69.142?providers=maxmind,bogus');
    assert.equal(bad.statusCode, 400);
    assert.equal(json(bad).error.code, 'invalid_providers');
  });

  it('pretty-prints on request', async () => {
    const a = await app();
    const res = await a.inject('/api/v1/ip/81.2.69.142?pretty=1');
    assert.match(res.body, /\n  "ip": "81.2.69.142"/);
  });

  it('sends CORS and robots headers for the API', async () => {
    const a = await app();
    const res = await a.inject({ url: '/api/v1/ip/81.2.69.142', headers: { origin: 'https://example.org' } });
    assert.equal(res.headers['access-control-allow-origin'], '*');
    assert.equal(res.headers['x-robots-tag'], 'noindex');
    const pre = await a.inject({
      method: 'OPTIONS',
      url: '/api/v1/ip/81.2.69.142',
      headers: { origin: 'https://example.org', 'access-control-request-method': 'GET' },
    });
    assert.equal(pre.statusCode, 204);
  });
});

describe('client IP detection', () => {
  it('uses the socket address when it is a public client', async () => {
    const a = await app();
    const res = await a.inject({ url: '/api/v1/ip', remoteAddress: '81.2.69.142' });
    assert.equal(json(res).ip, '81.2.69.142');
    assert.equal(json(res).summary.city, 'London');
    assert.equal(res.headers['cache-control'], 'no-store');
  });

  it('ignores X-Forwarded-For from untrusted clients (spoofing)', async () => {
    const a = await app();
    const res = await a.inject({
      url: '/api/v1/ip',
      remoteAddress: '81.2.69.142',
      headers: { 'x-forwarded-for': '8.8.8.8' },
    });
    assert.equal(json(res).ip, '81.2.69.142');
  });

  it('honours X-Forwarded-For from a trusted proxy', async () => {
    const a = await app();
    const res = await a.inject({
      url: '/api/v1/ip',
      remoteAddress: '127.0.0.1',
      headers: { 'x-forwarded-for': '81.2.69.142' },
    });
    assert.equal(json(res).ip, '81.2.69.142');
    const chain = await a.inject({
      url: '/api/v1/ip',
      remoteAddress: '10.0.0.2',
      headers: { 'x-forwarded-for': '1.1.1.1, 81.2.69.142, 10.0.0.9' },
    });
    // The rightmost untrusted entry is the real client; anything the client prepended is ignored.
    assert.equal(json(chain).ip, '81.2.69.142');
  });

  it('reports private clients as such (local development)', async () => {
    const a = await app();
    const res = await a.inject({ url: '/api/v1/ip', remoteAddress: '127.0.0.1' });
    assert.equal(json(res).is_public, false);
  });

  it('supports CLIENT_IP_HEADER only behind a trusted proxy', async () => {
    const a = await app({ CLIENT_IP_HEADER: 'cf-connecting-ip', TRUST_PROXY: '127.0.0.1' });
    const ok = await a.inject({
      url: '/api/v1/ip',
      remoteAddress: '127.0.0.1',
      headers: { 'cf-connecting-ip': '81.2.69.142' },
    });
    assert.equal(json(ok).ip, '81.2.69.142');
    const spoof = await a.inject({
      url: '/api/v1/ip',
      remoteAddress: '203.0.113.5',
      headers: { 'cf-connecting-ip': '81.2.69.142' },
    });
    assert.equal(json(spoof).ip, '203.0.113.5');
    const junk = await a.inject({
      url: '/api/v1/ip',
      remoteAddress: '127.0.0.1',
      headers: { 'cf-connecting-ip': 'not-an-ip' },
    });
    assert.equal(json(junk).ip, '127.0.0.1');
  });

  it('DEV_CLIENT_IP works outside production and is ignored in production', async () => {
    const dev = await app({ DEV_CLIENT_IP: '81.2.69.142' });
    assert.equal(json(await dev.inject({ url: '/api/v1/ip', remoteAddress: '127.0.0.1' })).ip, '81.2.69.142');
    const prod = await app({ DEV_CLIENT_IP: '81.2.69.142', NODE_ENV: 'production' });
    assert.equal(json(await prod.inject({ url: '/api/v1/ip', remoteAddress: '127.0.0.1' })).ip, '127.0.0.1');
  });

  it('GET /ip returns plain text', async () => {
    const a = await app();
    const res = await a.inject({ url: '/ip', remoteAddress: '81.2.69.142' });
    assert.equal(res.statusCode, 200);
    assert.match(res.headers['content-type'] as string, /text\/plain/);
    assert.equal(res.body, '81.2.69.142\n');
  });
});

describe('rate limiting and API keys', () => {
  it('limits anonymous clients per IP and returns a JSON 429', async () => {
    const a = await app({ RATE_LIMIT_ANONYMOUS: '3' });
    const hit = () => a.inject({ url: '/api/v1/ip/81.2.69.142', remoteAddress: '203.0.113.7' });
    for (let i = 0; i < 3; i++) assert.equal((await hit()).statusCode, 200);
    const blocked = await hit();
    assert.equal(blocked.statusCode, 429);
    assert.equal(json(blocked).error.code, 'rate_limited');
    assert.ok(blocked.headers['retry-after']);
    assert.equal(blocked.headers['x-ratelimit-limit'], '3');
    // A different client is unaffected.
    assert.equal((await a.inject({ url: '/api/v1/ip/81.2.69.142', remoteAddress: '203.0.113.8' })).statusCode, 200);
  });

  it('gives valid API keys a higher limit and rejects invalid keys', async () => {
    const a = await app({ RATE_LIMIT_ANONYMOUS: '1', RATE_LIMIT_KEYED: '5', API_KEYS: 'secret-one, secret-two' });
    const withKey = (key: string, header: Record<string, string>) =>
      a.inject({ url: '/api/v1/ip/81.2.69.142', remoteAddress: '203.0.113.9', headers: header });
    for (let i = 0; i < 5; i++) {
      assert.equal((await withKey('k', { authorization: 'Bearer secret-one' })).statusCode, 200);
    }
    assert.equal((await withKey('k', { authorization: 'Bearer secret-one' })).statusCode, 429);
    assert.equal((await withKey('k', { 'x-api-key': 'secret-two' })).statusCode, 200);
    const bad = await withKey('k', { authorization: 'Bearer nope' });
    assert.equal(bad.statusCode, 401);
    assert.equal(json(bad).error.code, 'invalid_api_key');
  });

  it('ignores API key headers when no keys are configured', async () => {
    const a = await app();
    const res = await a.inject({ url: '/api/v1/ip/81.2.69.142', headers: { authorization: 'Bearer YOUR_API_KEY' } });
    assert.equal(res.statusCode, 200);
  });
});

describe('status, health and errors', () => {
  it('reports database status', async () => {
    const a = await app({}, true);
    const body = json(await a.inject('/api/v1/status'));
    assert.equal(body.status, 'ok');
    assert.equal(body.providers.length, 3);
    assert.deepEqual(body.rate_limit, { anonymous: 60, with_api_key: 600, window: '1 minute' });
    assert.equal(body.providers.find((p: { id: string }) => p.id === 'maxmind').loaded, true);
  });

  it('GET /healthz is always ok', async () => {
    const a = await app();
    const res = await a.inject('/healthz');
    assert.equal(res.statusCode, 200);
    assert.deepEqual(json(res), { status: 'ok' });
  });

  it('returns JSON 404 for unknown API paths and non-HTML requests', async () => {
    const a = await app();
    const res = await a.inject('/api/v1/nope');
    assert.equal(res.statusCode, 404);
    assert.equal(json(res).error.code, 'not_found');
    const other = await a.inject('/whatever');
    assert.equal(other.statusCode, 404);
  });

  it('sets security headers', async () => {
    const a = await app();
    const res = await a.inject('/healthz');
    assert.match(res.headers['content-security-policy'] as string, /default-src 'self'/);
    assert.doesNotMatch(res.headers['content-security-policy'] as string, /upgrade-insecure-requests/);
    assert.equal(res.headers['x-content-type-options'], 'nosniff');
    assert.equal(res.headers['x-powered-by'], undefined);
  });
});

describe('serving the website', () => {
  const dist = fs.mkdtempSync(path.join(os.tmpdir(), 'ipa-web-'));
  fs.mkdirSync(path.join(dist, 'assets'));
  fs.writeFileSync(path.join(dist, 'index.html'), '<!doctype html><title>IP Atlas</title><div id="root"></div>');
  fs.writeFileSync(path.join(dist, 'assets', 'app-abc123.js'), 'console.log(1)');
  fs.writeFileSync(path.join(dist, 'robots.txt'), 'User-agent: *');

  it('serves index.html, hashed assets and static files with the right caching', async () => {
    const a = await app({ WEB_DIST: dist });
    const home = await a.inject('/');
    assert.equal(home.statusCode, 200);
    assert.match(home.body, /IP Atlas/);
    assert.equal(home.headers['cache-control'], 'no-cache');

    const asset = await a.inject('/assets/app-abc123.js');
    assert.equal(asset.statusCode, 200);
    assert.equal(asset.headers['cache-control'], 'public, max-age=31536000, immutable');

    assert.equal((await a.inject('/robots.txt')).statusCode, 200);
  });

  it('serves files added after startup (rebuild while running)', async () => {
    const a = await app({ WEB_DIST: dist });
    fs.writeFileSync(path.join(dist, 'assets', 'app-new999.js'), 'console.log(2)');
    const res = await a.inject('/assets/app-new999.js');
    assert.equal(res.statusCode, 200);
    assert.equal(res.headers['cache-control'], 'public, max-age=31536000, immutable');
  });

  it('falls back to index.html for browser navigation, but 404s everything else', async () => {
    const a = await app({ WEB_DIST: dist });
    const nav = await a.inject({ url: '/some/page', headers: { accept: 'text/html,application/xhtml+xml' } });
    assert.equal(nav.statusCode, 200);
    assert.match(nav.body, /IP Atlas/);
    assert.equal((await a.inject('/missing.js')).statusCode, 404);
    const api = await a.inject({ url: '/api/v1/nope', headers: { accept: 'text/html' } });
    assert.equal(api.statusCode, 404);
    assert.equal(json(api).error.code, 'not_found');
  });
});
