<?php
defined( 'ABSPATH' ) || exit;

/**
 * Settings storage, API-key handling and error log.
 */
class AIBW_Settings {

	const OPTION     = 'aibw_settings';
	const LOG_OPTION = 'aibw_log';

	public static function defaults() {
		return array(
			'default_provider' => 'groq',
			'fallback'         => 1,
			'keys'             => array(),
			'models'           => array(),
			'tone'             => 'informative',
			'length'           => 'medium',
			'language'         => 'English',
			'category'         => 0,
			'sticky'           => 1,
		);
	}

	public static function get() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	public static function update( $settings ) {
		update_option( self::OPTION, $settings, false );
	}

	/* ------------------------------------------------------------------ */
	/* API keys (stored encrypted with the site's salts, never sent to the */
	/* browser)                                                            */
	/* ------------------------------------------------------------------ */

	private static function crypt_key() {
		return hash( 'sha256', wp_salt( 'auth' ), true );
	}

	public static function encrypt( $plain ) {
		if ( '' === $plain ) {
			return '';
		}
		if ( function_exists( 'openssl_encrypt' ) && function_exists( 'openssl_random_pseudo_bytes' ) ) {
			$iv     = openssl_random_pseudo_bytes( 16 );
			$cipher = openssl_encrypt( $plain, 'AES-256-CBC', self::crypt_key(), OPENSSL_RAW_DATA, $iv );
			if ( false !== $cipher ) {
				return 'enc:' . base64_encode( $iv . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			}
		}
		return 'raw:' . base64_encode( $plain ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	public static function decrypt( $stored ) {
		if ( ! is_string( $stored ) || '' === $stored ) {
			return '';
		}
		if ( 0 === strpos( $stored, 'enc:' ) && function_exists( 'openssl_decrypt' ) ) {
			$bin = base64_decode( substr( $stored, 4 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( false === $bin || strlen( $bin ) < 17 ) {
				return '';
			}
			$plain = openssl_decrypt( substr( $bin, 16 ), 'AES-256-CBC', self::crypt_key(), OPENSSL_RAW_DATA, substr( $bin, 0, 16 ) );
			return false === $plain ? '' : $plain;
		}
		if ( 0 === strpos( $stored, 'raw:' ) ) {
			$plain = base64_decode( substr( $stored, 4 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			return false === $plain ? '' : $plain;
		}
		return '';
	}

	public static function get_key( $provider ) {
		$s = self::get();
		return isset( $s['keys'][ $provider ] ) ? self::decrypt( $s['keys'][ $provider ] ) : '';
	}

	public static function has_key( $provider ) {
		return '' !== self::get_key( $provider );
	}

	/** Last 4 characters, for showing "connected" without revealing the key. */
	public static function key_hint( $provider ) {
		$key = self::get_key( $provider );
		return '' === $key ? '' : '••••' . substr( $key, -4 );
	}

	public static function get_model( $provider ) {
		$s = self::get();
		if ( ! empty( $s['models'][ $provider ] ) ) {
			return $s['models'][ $provider ];
		}
		return AIBW_Providers::default_model( $provider );
	}

	/** An AI is ready when it is connected (every provider needs a key). */
	public static function is_ready( $provider ) {
		return AIBW_Providers::get( $provider ) && self::has_key( $provider );
	}

	public static function ready_providers() {
		$ready = array();
		foreach ( array_keys( AIBW_Providers::all() ) as $id ) {
			if ( self::is_ready( $id ) ) {
				$ready[] = $id;
			}
		}
		return $ready;
	}

	/** The AI that should be pre-selected on the writer page. */
	public static function preferred_provider() {
		$s     = self::get();
		$ready = self::ready_providers();
		if ( in_array( $s['default_provider'], $ready, true ) ) {
			return $s['default_provider'];
		}
		return $ready ? $ready[0] : $s['default_provider'];
	}

	public static function word_count( $length ) {
		$map = array(
			'short'  => 600,
			'medium' => 1000,
			'long'   => 1600,
		);
		return isset( $map[ $length ] ) ? $map[ $length ] : 1000;
	}

	/* ------------------------------------------------------------------ */
	/* Error log                                                           */
	/* ------------------------------------------------------------------ */

	public static function log( $message, $provider = '' ) {
		$log   = get_option( self::LOG_OPTION, array() );
		$log   = is_array( $log ) ? $log : array();
		$log[] = array(
			'time'     => current_time( 'mysql' ),
			'provider' => $provider,
			'message'  => $message,
		);
		update_option( self::LOG_OPTION, array_slice( $log, -20 ), false );
	}

	public static function get_log() {
		$log = get_option( self::LOG_OPTION, array() );
		return is_array( $log ) ? array_reverse( $log ) : array();
	}

	public static function clear_log() {
		delete_option( self::LOG_OPTION );
	}
}
