import { useState } from "react";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "", email: "", company: "", budget: "", message: "", service: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div>
      {/* HERO */}
      <section style={{ padding: "6rem 2rem 5rem", maxWidth: 1280, margin: "0 auto" }}>
        <div className="section-label" style={{ marginBottom: "1.5rem" }}>Get In Touch</div>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 5vw, 5rem)", fontWeight: 900, lineHeight: 1.05, letterSpacing: "-0.02em", maxWidth: 700, marginBottom: "1.5rem" }}>
          Let's talk about<br />
          <em style={{ color: "#FF5500", fontStyle: "italic" }}>your project.</em>
        </h1>
        <p style={{ color: "#777", fontSize: "1rem", lineHeight: 1.8, maxWidth: 500 }}>
          We take on a limited number of projects each quarter. Tell us about your goals and we'll let you know if we're a good fit.
        </p>
      </section>

      {/* MAIN CONTENT */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem 8rem", display: "grid", gridTemplateColumns: "1fr 1.6fr", gap: "6rem" }}>
        {/* LEFT — info */}
        <div>
          <div style={{ marginBottom: "4rem" }}>
            <div className="section-label" style={{ marginBottom: "1.5rem" }}>Office</div>
            {[
              { city: "New York", addr: "150 West 25th Street, Suite 1200\nNew York, NY 10001" },
              { city: "Berlin", addr: "Torstraße 61\n10119 Berlin, Germany" },
            ].map((o, i) => (
              <div key={i} style={{ marginBottom: "2rem", paddingBottom: "2rem", borderBottom: "1px solid #1A1A1A" }}>
                <div style={{ fontWeight: 700, marginBottom: "0.5rem" }}>{o.city}</div>
                <p style={{ color: "#666", fontSize: "0.88rem", lineHeight: 1.8, whiteSpace: "pre-line" }}>{o.addr}</p>
              </div>
            ))}
          </div>

          <div style={{ marginBottom: "4rem" }}>
            <div className="section-label" style={{ marginBottom: "1.5rem" }}>Contact</div>
            {[
              { label: "General", value: "hello@vantage.studio" },
              { label: "New Projects", value: "new@vantage.studio" },
              { label: "Phone", value: "+1 (212) 555-0147" },
            ].map((c, i) => (
              <div key={i} style={{ marginBottom: "1.2rem" }}>
                <div style={{ fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.1em", color: "#555", textTransform: "uppercase", marginBottom: "0.3rem" }}>{c.label}</div>
                <div style={{ color: "#CCC", fontSize: "0.9rem" }}>{c.value}</div>
              </div>
            ))}
          </div>

          <div>
            <div className="section-label" style={{ marginBottom: "1.5rem" }}>Response Time</div>
            <div style={{ background: "#111", padding: "1.5rem", borderLeft: "3px solid #FF5500" }}>
              <div className="font-display" style={{ fontSize: "1.5rem", fontWeight: 700, marginBottom: "0.3rem" }}>{"< 4 hours"}</div>
              <p style={{ color: "#666", fontSize: "0.83rem", lineHeight: 1.7 }}>Average response time during business hours (Mon–Fri, 9am–6pm ET).</p>
            </div>
          </div>
        </div>

        {/* RIGHT — form */}
        <div>
          {submitted ? (
            <div style={{ background: "#111", padding: "4rem", borderTop: "3px solid #FF5500", textAlign: "center" }}>
              <div style={{ fontSize: "2rem", marginBottom: "1.5rem" }}>✓</div>
              <h2 className="font-display" style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "1rem" }}>We got it.</h2>
              <p style={{ color: "#777", lineHeight: 1.8 }}>We'll review your project details and get back to you within 4 business hours. Check your inbox.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} style={{ background: "#111", padding: "3rem" }}>
              <div style={{ marginBottom: "1.5rem" }}>
                <div className="section-label" style={{ marginBottom: "2rem" }}>Project Inquiry</div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.2rem", marginBottom: "1.2rem" }}>
                  {[
                    { id: "name", label: "Full Name", type: "text", placeholder: "Sarah Chen" },
                    { id: "email", label: "Email Address", type: "email", placeholder: "sarah@company.com" },
                  ].map((f) => (
                    <div key={f.id}>
                      <label style={{ display: "block", fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#555", marginBottom: "0.6rem" }}>{f.label}</label>
                      <input
                        type={f.type}
                        placeholder={f.placeholder}
                        value={formData[f.id as keyof typeof formData]}
                        onChange={e => setFormData({ ...formData, [f.id]: e.target.value })}
                        required
                        style={{
                          width: "100%", padding: "0.85rem 1rem",
                          background: "#0A0A0A", border: "1px solid #2A2A2A",
                          color: "#F4EFE6", fontFamily: "'Outfit', sans-serif", fontSize: "0.9rem",
                          outline: "none", transition: "border-color 0.2s",
                        }}
                        onFocus={e => (e.target.style.borderColor = "#FF5500")}
                        onBlur={e => (e.target.style.borderColor = "#2A2A2A")}
                      />
                    </div>
                  ))}
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.2rem", marginBottom: "1.2rem" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#555", marginBottom: "0.6rem" }}>Company</label>
                    <input
                      type="text"
                      placeholder="Acme Corp"
                      value={formData.company}
                      onChange={e => setFormData({ ...formData, company: e.target.value })}
                      style={{
                        width: "100%", padding: "0.85rem 1rem",
                        background: "#0A0A0A", border: "1px solid #2A2A2A",
                        color: "#F4EFE6", fontFamily: "'Outfit', sans-serif", fontSize: "0.9rem", outline: "none",
                      }}
                      onFocus={e => (e.target.style.borderColor = "#FF5500")}
                      onBlur={e => (e.target.style.borderColor = "#2A2A2A")}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#555", marginBottom: "0.6rem" }}>Budget Range</label>
                    <select
                      value={formData.budget}
                      onChange={e => setFormData({ ...formData, budget: e.target.value })}
                      style={{
                        width: "100%", padding: "0.85rem 1rem",
                        background: "#0A0A0A", border: "1px solid #2A2A2A",
                        color: formData.budget ? "#F4EFE6" : "#555",
                        fontFamily: "'Outfit', sans-serif", fontSize: "0.9rem", outline: "none",
                      }}
                      onFocus={e => (e.target.style.borderColor = "#FF5500")}
                      onBlur={e => (e.target.style.borderColor = "#2A2A2A")}
                    >
                      <option value="">Select range</option>
                      <option>$5,000 – $10,000</option>
                      <option>$10,000 – $25,000</option>
                      <option>$25,000 – $50,000</option>
                      <option>$50,000+</option>
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: "1.2rem" }}>
                  <label style={{ display: "block", fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#555", marginBottom: "0.6rem" }}>Service Needed</label>
                  <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
                    {["WordPress Site", "WooCommerce", "SEO", "Branding", "Full Package"].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setFormData({ ...formData, service: s })}
                        style={{
                          fontFamily: "'Outfit', sans-serif", fontSize: "0.72rem", fontWeight: 700,
                          letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.5rem 1rem",
                          border: "1px solid", cursor: "pointer", transition: "all 0.2s",
                          background: formData.service === s ? "#FF5500" : "transparent",
                          color: formData.service === s ? "#080808" : "#555",
                          borderColor: formData.service === s ? "#FF5500" : "#2A2A2A",
                        }}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div style={{ marginBottom: "2rem" }}>
                  <label style={{ display: "block", fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#555", marginBottom: "0.6rem" }}>Tell Us About Your Project</label>
                  <textarea
                    placeholder="What are you trying to achieve? What's not working right now? What does success look like?"
                    rows={5}
                    value={formData.message}
                    onChange={e => setFormData({ ...formData, message: e.target.value })}
                    required
                    style={{
                      width: "100%", padding: "0.85rem 1rem", resize: "vertical",
                      background: "#0A0A0A", border: "1px solid #2A2A2A",
                      color: "#F4EFE6", fontFamily: "'Outfit', sans-serif", fontSize: "0.9rem", outline: "none",
                    }}
                    onFocus={e => (e.target.style.borderColor = "#FF5500")}
                    onBlur={e => (e.target.style.borderColor = "#2A2A2A")}
                  />
                </div>

                <button type="submit" className="btn-primary" style={{ width: "100%", textAlign: "center", fontSize: "0.85rem", padding: "1.1rem" }}>
                  Send Project Brief →
                </button>
                <p style={{ fontSize: "0.75rem", color: "#444", textAlign: "center", marginTop: "1rem" }}>
                  We respond within 4 business hours. No automated replies.
                </p>
              </div>
            </form>
          )}
        </div>

        <style>{`@media (max-width: 900px) { section[style*="grid-template-columns: 1fr 1.6fr"] { grid-template-columns: 1fr !important; } }`}</style>
      </section>

      {/* MAP-STYLE BAND */}
      <section style={{ background: "#0D0D0D", padding: "5rem 2rem", borderTop: "1px solid #1A1A1A" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "3rem" }}>
            {[
              { label: "Strategy Call", val: "Free" },
              { label: "Proposal Turnaround", val: "48 hours" },
              { label: "Typical Project Start", val: "2–3 weeks" },
              { label: "Projects Per Quarter", val: "4–6 max" },
            ].map((s, i) => (
              <div key={i} style={{ borderLeft: "3px solid #FF5500", paddingLeft: "1.5rem" }}>
                <div style={{ fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.12em", color: "#555", textTransform: "uppercase", marginBottom: "0.5rem" }}>{s.label}</div>
                <div className="font-display" style={{ fontSize: "1.6rem", fontWeight: 700 }}>{s.val}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
