<?php
/**
 * Home: three brand promise cards.
 */

$marina_values = apply_filters(
    'marina_home_values',
    array(
        array(
            'icon'  => 'checkroom',
            'title' => __( 'Quality You Can Feel', 'marina-clothing' ),
            'text'  => __( 'Carefully selected fabrics and considered construction, made to look good and last wear after wear.', 'marina-clothing' ),
            'tag'   => __( 'Quality First', 'marina-clothing' ),
        ),
        array(
            'icon'  => 'precision_manufacturing',
            'title' => __( 'Thoughtfully Made', 'marina-clothing' ),
            'text'  => __( 'Every piece is designed with attention to fit, finish and the small details that make a big difference.', 'marina-clothing' ),
            'tag'   => __( 'Considered Design', 'marina-clothing' ),
        ),
        array(
            'icon'  => 'local_shipping',
            'title' => __( 'Fast, Easy Delivery', 'marina-clothing' ),
            'text'  => __( 'Orders are packed with care and shipped quickly, with simple returns if something is not quite right.', 'marina-clothing' ),
            'tag'   => __( 'Easy Returns', 'marina-clothing' ),
        ),
    )
);
?>
<section class="section values">
    <div class="container values__grid">
        <?php foreach ( $marina_values as $marina_value ) : ?>
            <div class="value-card">
                <span class="value-card__icon"><?php marina_the_icon( $marina_value['icon'] ); ?></span>
                <h3 class="value-card__title"><?php echo esc_html( $marina_value['title'] ); ?></h3>
                <p class="value-card__text"><?php echo esc_html( $marina_value['text'] ); ?></p>
                <span class="value-card__tag"><?php echo esc_html( $marina_value['tag'] ); ?></span>
            </div>
        <?php endforeach; ?>
    </div>
</section>
