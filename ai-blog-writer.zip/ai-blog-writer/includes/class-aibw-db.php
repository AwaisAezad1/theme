<?php
defined( 'ABSPATH' ) || exit;

/**
 * Custom tables for topics, jobs and logs.
 * Schema upgrades run from plugins_loaded and activation.
 */
class AIBW_DB {

	public static function topics() {
		global $wpdb;
		return $wpdb->prefix . 'aibw_topics';
	}

	public static function jobs() {
		global $wpdb;
		return $wpdb->prefix . 'aibw_jobs';
	}

	public static function logs() {
		global $wpdb;
		return $wpdb->prefix . 'aibw_logs';
	}

	public static function maybe_upgrade() {
		if ( get_option( 'aibw_db_version' ) === AIBW_DB_VERSION ) {
			return;
		}
		self::install();
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$topics  = self::topics();
		$jobs    = self::jobs();
		$logs    = self::logs();

		$sql = "CREATE TABLE {$topics} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title text NOT NULL,
			keyword varchar(191) NOT NULL DEFAULT '',
			audience varchar(191) NOT NULL DEFAULT '',
			category bigint(20) unsigned NOT NULL DEFAULT 0,
			tags varchar(255) NOT NULL DEFAULT '',
			priority smallint NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'pending',
			scheduled_date date DEFAULT NULL,
			source varchar(20) NOT NULL DEFAULT 'manual',
			notes text NULL,
			similarity_note text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY scheduled_date (scheduled_date)
		) {$charset};
		CREATE TABLE {$jobs} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			uuid varchar(36) NOT NULL,
			topic_id bigint(20) unsigned NOT NULL DEFAULT 0,
			topic_text text NOT NULL,
			status varchar(30) NOT NULL DEFAULT 'queued',
			stage varchar(30) NOT NULL DEFAULT 'queued',
			attempts smallint unsigned NOT NULL DEFAULT 0,
			provider varchar(40) NOT NULL DEFAULT '',
			model varchar(80) NOT NULL DEFAULT '',
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			research_json longtext NULL,
			article_json longtext NULL,
			seo_json longtext NULL,
			images_json longtext NULL,
			error_message text NULL,
			tokens int unsigned NOT NULL DEFAULT 0,
			cost_estimate decimal(10,4) DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			started_at datetime DEFAULT NULL,
			finished_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uuid (uuid),
			KEY status (status),
			KEY topic_id (topic_id),
			KEY post_id (post_id)
		) {$charset};
		CREATE TABLE {$logs} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			job_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			severity varchar(20) NOT NULL DEFAULT 'info',
			stage varchar(30) NOT NULL DEFAULT '',
			provider varchar(40) NOT NULL DEFAULT '',
			topic varchar(191) NOT NULL DEFAULT '',
			message text NOT NULL,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY job_id (job_id),
			KEY created_at (created_at)
		) {$charset};";

		dbDelta( $sql );
		update_option( 'aibw_db_version', AIBW_DB_VERSION, false );
	}
}
