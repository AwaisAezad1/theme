<?php get_header(); ?>

<main id="primary" class="site-content">
    <div class="container">

        <header class="page-header">
            <h1>
                <?php
                printf(
                    esc_html__( 'Search Results for: %s', 'wp-developer-starter' ),
                    '<span>' . esc_html( get_search_query() ) . '</span>'
                );
                ?>
            </h1>
        </header>

        <?php if ( have_posts() ) : ?>

            <?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'template-parts/content', get_post_type() ); ?>
            <?php endwhile; ?>

            <?php the_posts_pagination(); ?>

        <?php else : ?>

            <p><?php esc_html_e( 'Nothing found.', 'wp-developer-starter' ); ?></p>

        <?php endif; ?>

    </div>
</main>

<?php get_footer(); ?>
