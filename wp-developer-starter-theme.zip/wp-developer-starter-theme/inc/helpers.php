<?php
/**
 * Theme helper functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Get a theme asset URL.
 */
function wds_asset( $path = '' ) {
    return WDS_URI . '/assets/' . ltrim( $path, '/' );
}

/**
 * Check whether WooCommerce is active.
 */
function wds_is_woocommerce_active() {
    return class_exists( 'WooCommerce' );
}
