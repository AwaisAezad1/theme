=== AI Blog Writer ===
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Type a topic, pick an AI (ChatGPT, Claude, Gemini, Perplexity or free Groq) and add the finished blog - with a cover picture and related photos - to your front page in one click.

== Description ==

1. Go to AI Blog Writer > Write a Blog.
2. Type what the blog should be about.
3. Choose which AI writes it.
4. Press Generate Blog, read and edit the result, then press "Add Blog to Front Page" (or "Save as Draft").

Supported AIs: Groq (free), ChatGPT (OpenAI), Claude (Anthropic), Gemini (Google), Perplexity.

= Using your own or paid account =

On AI Blog Writer > AI Accounts each AI has Sign up / Log in / Get API key buttons. Create or log in to your account, copy the API key and paste it in. Your plan, credits and limits then apply. AI companies do not allow websites to sign in with a normal chat login, so a key is the way to connect an account. Chat subscriptions (for example ChatGPT Plus or Claude Pro) are usually billed separately from API use.

= Front page =

"Add Blog to Front Page" publishes the post and makes it sticky, which keeps it at the top of your blog posts list. If your front page is a fixed page (Settings > Reading), add the shortcode [aibw_latest_blogs count="3"] to that page.

= Pictures =

On AI Blog Writer > AI Accounts, connect a free Pexels or Pixabay key. The AI then decides what each picture should show (short search words) and real stock photos are found for the cover and for sections inside the blog. You can swap or remove any picture before publishing. When you add the blog, the photos are copied into your Media Library, the cover becomes the featured image, the photographer is credited under each picture, and the pictures are centred and styled to fit any theme. The AI never invents image links.

= Other features =

* Optional automatic fallback to the free AI if a paid AI fails.
* Tone, length, language and extra-instruction options.
* Model picker filled from your own account after "Test connection".
* History page with your AI blogs and an error log.

= External services =

When you press Generate Blog, the topic, your writing options and your API key are sent to the AI you selected. Nothing is sent to the plugin authors.

* Groq: https://groq.com/privacy-policy/
* OpenAI: https://openai.com/policies/privacy-policy
* Anthropic: https://www.anthropic.com/privacy
* Google: https://policies.google.com/privacy
* Perplexity: https://www.perplexity.ai/hub/legal/privacy-policy
* Pexels (pictures): https://www.pexels.com/privacy-policy/
* Pixabay (pictures): https://pixabay.com/service/privacy/

For pictures, only the short search words and your image key are sent to the image service you chose. Photos are downloaded from the image service's server into your Media Library when you add the blog.

= Security notes =

API keys are stored encrypted using your site's secret keys (WordPress salts). If you change the salts in wp-config.php, re-enter your keys. Always review AI text for accuracy before publishing.

== Changelog ==

= 1.2.0 =
* Automation dashboard, topic queue, content calendar and draft review.
* Scheduled draft generation with research, SEO checks and image fallback. Posts stay drafts until you publish them.
* Job log, retry, pause and resume. Deactivation removes only the schedule.

= 1.1.0 =
* New: cover picture and related photos in each blog (free Pexels or Pixabay), swap/remove before publishing, saved to the Media Library with credits, set as featured image.
* New: [aibw_latest_blogs] shows cover pictures in a card grid.

= 1.0.0 =
* First release. Adapted from AI Blog Automator by Bluteem LLC (GPL v2 or later).
