<?php
/**
 * Home: full-bleed editorial hero.
 */

$marina_image = marina_opt( 'hero_image' ) ? marina_opt( 'hero_image' ) : marina_image( 'hero' );
$marina_btn1  = marina_opt( 'hero_btn1_url' );
if ( ! $marina_btn1 ) {
    $marina_btn1 = marina_is_woocommerce_active() ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}
$marina_badge_icons = array( 'verified', 'auto_awesome', 'temp_preferences_custom' );
?>
<section class="hero">
    <div class="hero__media">
        <img src="<?php echo esc_url( $marina_image ); ?>" alt="" fetchpriority="high">
        <div class="hero__scrim hero__scrim--side"></div>
        <div class="hero__scrim hero__scrim--bottom"></div>
    </div>

    <div class="container hero__inner">
        <div class="hero__copy">
            <?php if ( marina_opt( 'hero_eyebrow' ) ) : ?>
                <span class="hero__eyebrow"><?php echo esc_html( marina_opt( 'hero_eyebrow' ) ); ?></span>
            <?php endif; ?>

            <h1 class="hero__title">
                <?php echo esc_html( marina_opt( 'hero_title' ) ); ?><br>
                <em><?php echo esc_html( marina_opt( 'hero_title_accent' ) ); ?></em>
                <?php echo esc_html( marina_opt( 'hero_title_end' ) ); ?>
            </h1>

            <?php if ( marina_opt( 'hero_text' ) ) : ?>
                <p class="hero__text"><?php echo esc_html( marina_opt( 'hero_text' ) ); ?></p>
            <?php endif; ?>

            <div class="hero__actions">
                <?php if ( marina_opt( 'hero_btn1_label' ) ) : ?>
                    <a class="btn btn--light" href="<?php echo esc_url( $marina_btn1 ); ?>"><?php echo esc_html( marina_opt( 'hero_btn1_label' ) ); ?></a>
                <?php endif; ?>
                <?php if ( marina_opt( 'hero_btn2_label' ) ) : ?>
                    <a class="btn btn--glass" href="<?php echo esc_url( marina_opt( 'hero_btn2_url' ) ); ?>">
                        <span><?php echo esc_html( marina_opt( 'hero_btn2_label' ) ); ?></span>
                        <?php marina_the_icon( 'north_east' ); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php $marina_badges = marina_opt_lines( 'hero_badges' ); ?>
        <?php if ( $marina_badges ) : ?>
            <ul class="hero__badges">
                <?php foreach ( $marina_badges as $marina_i => $marina_badge ) : ?>
                    <li><?php marina_the_icon( $marina_badge_icons[ $marina_i % 3 ] ); ?><span><?php echo esc_html( $marina_badge ); ?></span></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</section>
