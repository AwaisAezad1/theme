<?php
defined( 'ABSPATH' ) || exit;

/**
 * Related pictures for blogs.
 *
 * The AI only suggests short English search phrases. The photos themselves come from a real
 * stock-photo service (Pexels or Pixabay, both free), so every link is real and the licence is
 * clear. When a blog is published the chosen photos are copied into the Media Library, so the
 * site never depends on someone else's server and the images are properly sized by WordPress.
 */
class AIBW_Images {

	/** Only these hosts may be downloaded from (the browser sends the URL, so never trust it blindly). */
	private static function allowed_hosts() {
		return array( 'images.pexels.com', 'cdn.pixabay.com', 'pixabay.com' );
	}

	public static function sources() {
		return array(
			'pexels'  => array(
				'label'    => 'Pexels (Free)',
				'short'    => 'Pexels',
				'signup'   => 'https://www.pexels.com/api/',
				'keys_url' => 'https://www.pexels.com/api/',
				'privacy'  => 'https://www.pexels.com/privacy-policy/',
				'blurb'    => 'Free, high-quality photos. Best default.',
			),
			'pixabay' => array(
				'label'    => 'Pixabay (Free)',
				'short'    => 'Pixabay',
				'signup'   => 'https://pixabay.com/accounts/register/',
				'keys_url' => 'https://pixabay.com/api/docs/',
				'privacy'  => 'https://pixabay.com/service/privacy/',
				'blurb'    => 'Free photos, a good second option.',
			),
		);
	}

	public static function modes() {
		return array(
			'some'  => __( 'Cover + 2 pictures inside the blog', 'ai-blog-writer' ),
			'many'  => __( 'Cover + 4 pictures inside the blog', 'ai-blog-writer' ),
			'cover' => __( 'Cover picture only', 'ai-blog-writer' ),
			'none'  => __( 'No pictures', 'ai-blog-writer' ),
		);
	}

	/** @return array{cover:bool,inline:int} */
	public static function plan( $mode ) {
		$map = array(
			'some'  => array( 'cover' => true, 'inline' => 2 ),
			'many'  => array( 'cover' => true, 'inline' => 4 ),
			'cover' => array( 'cover' => true, 'inline' => 0 ),
		);
		return isset( $map[ $mode ] ) ? $map[ $mode ] : array( 'cover' => false, 'inline' => 0 );
	}

	/* ------------------------------------------------------------------ */
	/* Keys                                                                */
	/* ------------------------------------------------------------------ */

	public static function get_key( $source ) {
		$s = AIBW_Settings::get();
		return isset( $s['image_keys'][ $source ] ) ? AIBW_Settings::decrypt( $s['image_keys'][ $source ] ) : '';
	}

	public static function key_hint( $source ) {
		$key = self::get_key( $source );
		return '' === $key ? '' : '••••' . substr( $key, -4 );
	}

	public static function current_source() {
		$s       = AIBW_Settings::get();
		$sources = self::sources();
		return isset( $sources[ $s['image_source'] ] ) ? $s['image_source'] : 'pexels';
	}

	/** Pictures can be used when the chosen source has a key. */
	public static function is_ready() {
		return '' !== self::get_key( self::current_source() );
	}

	/* ------------------------------------------------------------------ */
	/* Searching                                                           */
	/* ------------------------------------------------------------------ */

	public static function clean_query( $q ) {
		$q = wp_strip_all_tags( (string) $q );
		$q = preg_replace( '/[\*_"\'\[\]<>#]+/u', '', $q );
		$q = trim( preg_replace( '/\s+/u', ' ', $q ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $q, 0, 60 ) : substr( $q, 0, 60 );
	}

	/**
	 * Find one photo for a search phrase.
	 *
	 * @param string   $query   Search phrase.
	 * @param string[] $exclude Photo IDs already used (so the same photo never appears twice).
	 * @return array|null|WP_Error Photo array, null when nothing matches, WP_Error when the service fails.
	 */
	public static function find( $query, $exclude = array(), $source = '', $key = '', $allow_fallback = false ) {
		$source = '' !== $source ? $source : self::current_source();
		$key    = '' !== $key ? $key : self::get_key( $source );
		if ( ! isset( self::sources()[ $source ] ) || '' === $key ) {
			if ( $allow_fallback ) {
				return self::find_fallback( $query, $exclude, $source, new WP_Error( 'aibw_img_nokey', __( 'No image source is connected yet. Add a free key on the AI Accounts page.', 'ai-blog-writer' ) ) );
			}
			return new WP_Error( 'aibw_img_nokey', __( 'No image source is connected yet. Add a free key on the AI Accounts page.', 'ai-blog-writer' ) );
		}

		$query = self::clean_query( $query );
		if ( '' === $query ) {
			return null;
		}

		// If the exact phrase finds nothing, try shorter versions of it.
		$tries = array( $query );
		$words = explode( ' ', $query );
		if ( count( $words ) > 2 ) {
			$tries[] = implode( ' ', array_slice( $words, 0, 2 ) );
		}
		if ( count( $words ) > 1 ) {
			$tries[] = $words[0];
		}

		$last_error = null;
		foreach ( $tries as $q ) {
			$hits = 'pixabay' === $source ? self::search_pixabay( $q, $key ) : self::search_pexels( $q, $key );
			if ( is_wp_error( $hits ) ) {
				$last_error = $hits;
				$code       = $hits->get_error_code();
				if ( in_array( $code, array( 'aibw_img_rate', 'aibw_img_http' ), true ) ) {
					$hits = 'pixabay' === $source ? self::search_pixabay( $q, $key ) : self::search_pexels( $q, $key );
				}
				if ( is_wp_error( $hits ) ) {
					if ( $allow_fallback ) {
						return self::find_fallback( $query, $exclude, $source, $hits );
					}
					return $hits;
				}
			}
			foreach ( $hits as $hit ) {
				if ( ! in_array( $hit['uid'], $exclude, true ) ) {
					$hit['provider'] = $source;
					return $hit;
				}
			}
		}
		if ( $allow_fallback ) {
			return self::find_fallback( $query, $exclude, $source, $last_error ? $last_error : null );
		}
		return null;
	}

	/**
	 * Try the other configured image provider. Permanent auth errors are not retried forever.
	 *
	 * @param string        $query
	 * @param string[]      $exclude
	 * @param string        $source
	 * @param WP_Error|null $error
	 * @return array|null|WP_Error
	 */
	private static function find_fallback( $query, $exclude, $source, $error ) {
		$auto = AIBW_Settings::automation();
		$alt  = '';
		if ( ! empty( $auto['image_fallback'] ) && $auto['image_fallback'] !== $source && isset( self::sources()[ $auto['image_fallback'] ] ) ) {
			$alt = $auto['image_fallback'];
		} else {
			$alt = 'pexels' === $source ? 'pixabay' : 'pexels';
		}
		if ( $alt === $source || '' === self::get_key( $alt ) ) {
			return $error instanceof WP_Error ? $error : null;
		}
		if ( $error instanceof WP_Error && 'aibw_img_key' === $error->get_error_code() ) {
			AIBW_Settings::log( $error->get_error_message(), 'images' );
		}
		return self::find( $query, $exclude, $alt, '', false );
	}

	/** @return true|WP_Error */
	public static function test( $source, $key ) {
		$res = self::find( 'nature', array(), $source, $key );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return null === $res ? new WP_Error( 'aibw_img_empty', __( 'Connected, but the test search found no photos.', 'ai-blog-writer' ) ) : true;
	}

	private static function get_json( $url, $headers, $label ) {
		$res = wp_remote_get(
			$url,
			array(
				'timeout' => 20,
				'reject_unsafe_urls' => true,
				'headers' => $headers,
			)
		);
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'aibw_img_http', $label . ': ' . $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 401 === $code || 403 === $code ) {
			return new WP_Error( 'aibw_img_key', $label . ': ' . __( 'the key was rejected. Check it on the AI Accounts page.', 'ai-blog-writer' ) );
		}
		if ( 429 === $code ) {
			return new WP_Error( 'aibw_img_rate', $label . ': ' . __( 'hourly limit reached. Try again later.', 'ai-blog-writer' ) );
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'aibw_img_http', $label . ': HTTP ' . $code );
		}
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		return is_array( $data ) ? $data : array();
	}

	private static function search_pexels( $q, $key ) {
		$url  = add_query_arg(
			array(
				'query'       => $q,
				'per_page'    => 15,
				'orientation' => 'landscape',
			),
			'https://api.pexels.com/v1/search'
		);
		$data = self::get_json( $url, array( 'Authorization' => $key ), 'Pexels' );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$out = array();
		foreach ( isset( $data['photos'] ) ? (array) $data['photos'] : array() as $p ) {
			$src = isset( $p['src']['large2x'] ) ? $p['src']['large2x'] : ( isset( $p['src']['large'] ) ? $p['src']['large'] : '' );
			if ( '' === $src || empty( $p['id'] ) ) {
				continue;
			}
			$by     = isset( $p['photographer'] ) ? $p['photographer'] : 'Pexels';
			$by_url = isset( $p['photographer_url'] ) ? $p['photographer_url'] : 'https://www.pexels.com/';
			$out[]  = array(
				'uid'    => 'pexels:' . (int) $p['id'],
				'src'    => esc_url_raw( $src ),
				'alt'    => ! empty( $p['alt'] ) ? sanitize_text_field( $p['alt'] ) : ucfirst( $q ),
				'credit' => self::credit( __( 'Photo by', 'ai-blog-writer' ), $by, $by_url, 'Pexels', 'https://www.pexels.com/' ),
			);
		}
		return $out;
	}

	private static function search_pixabay( $q, $key ) {
		$url  = add_query_arg(
			array(
				'key'         => $key,
				'q'           => $q,
				'image_type'  => 'photo',
				'orientation' => 'horizontal',
				'safesearch'  => 'true',
				'min_width'   => 1000,
				'per_page'    => 15,
			),
			'https://pixabay.com/api/'
		);
		$data = self::get_json( $url, array(), 'Pixabay' );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$out = array();
		foreach ( isset( $data['hits'] ) ? (array) $data['hits'] : array() as $p ) {
			if ( empty( $p['largeImageURL'] ) || empty( $p['id'] ) ) {
				continue;
			}
			$user   = isset( $p['user'] ) ? $p['user'] : 'Pixabay';
			$by_url = ! empty( $p['user_id'] ) ? 'https://pixabay.com/users/' . rawurlencode( $user ) . '-' . (int) $p['user_id'] . '/' : 'https://pixabay.com/';
			$tags   = isset( $p['tags'] ) ? sanitize_text_field( $p['tags'] ) : '';
			$out[]  = array(
				'uid'    => 'pixabay:' . (int) $p['id'],
				'src'    => esc_url_raw( $p['largeImageURL'] ),
				'alt'    => '' !== $tags ? ucfirst( $tags ) : ucfirst( $q ),
				'credit' => self::credit( __( 'Image by', 'ai-blog-writer' ), $user, $by_url, 'Pixabay', 'https://pixabay.com/' ),
			);
		}
		return $out;
	}

	private static function credit( $prefix, $name, $name_url, $site, $site_url ) {
		return esc_html( $prefix ) . ' <a href="' . esc_url( $name_url ) . '" target="_blank" rel="noopener">' . esc_html( $name ) . '</a> '
			. esc_html__( 'on', 'ai-blog-writer' ) . ' <a href="' . esc_url( $site_url ) . '" target="_blank" rel="noopener">' . esc_html( $site ) . '</a>';
	}

	/* ------------------------------------------------------------------ */
	/* Publishing: copy photos into the Media Library                      */
	/* ------------------------------------------------------------------ */

	private static function allowed_credit( $html ) {
		return wp_kses(
			(string) $html,
			array(
				'a' => array(
					'href'   => true,
					'target' => true,
					'rel'    => true,
				),
			)
		);
	}

	/**
	 * Download one photo into the Media Library.
	 *
	 * @return int|WP_Error Attachment ID.
	 */
	public static function import( $url, $post_id, $alt, $credit_html ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! $host || ! in_array( strtolower( $host ), self::allowed_hosts(), true ) || 0 !== strpos( $url, 'https://' ) ) {
			return new WP_Error( 'aibw_img_host', __( 'That picture does not come from an allowed image source.', 'ai-blog-writer' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = self::download_checked( $url );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}

		$name = sanitize_file_name( basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
		if ( ! preg_match( '/\.(jpe?g|png|webp)$/i', $name ) ) {
			$name .= '.jpg';
		}

		$id = media_handle_sideload(
			array(
				'name'     => $name,
				'tmp_name' => $tmp,
			),
			$post_id,
			sanitize_text_field( $alt )
		);
		if ( is_wp_error( $id ) ) {
			if ( file_exists( $tmp ) ) {
				@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
			}
			return $id;
		}

		update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
		update_post_meta( $id, '_aibw_image', '1' );
		wp_update_post(
			array(
				'ID'           => $id,
				'post_excerpt' => self::allowed_credit( $credit_html ),
			)
		);
		return (int) $id;
	}

	/**
	 * Download only from allowed hosts, including redirects, and reject bad files.
	 *
	 * @return string|WP_Error Temporary file path.
	 */
	public static function download_checked( $url ) {
		$current = $url;
		$seen    = 0;
		$body    = '';
		$code    = 0;
		$type    = '';
		while ( $seen < 3 ) {
			++$seen;
			$host = wp_parse_url( $current, PHP_URL_HOST );
			if ( ! $host || ! in_array( strtolower( $host ), self::allowed_hosts(), true ) || 0 !== strpos( $current, 'https://' ) ) {
				return new WP_Error( 'aibw_img_host', __( 'That picture does not come from an allowed image source.', 'ai-blog-writer' ) );
			}
			$res = wp_remote_get(
				$current,
				array(
					'timeout'     => 30,
					'redirection' => 0,
					'reject_unsafe_urls' => true,
					'limit_response_size' => 8 * 1024 * 1024,
				)
			);
			if ( is_wp_error( $res ) ) {
				return $res;
			}
			$code = (int) wp_remote_retrieve_response_code( $res );
			if ( $code >= 300 && $code < 400 ) {
				$loc = wp_remote_retrieve_header( $res, 'location' );
				if ( ! is_string( $loc ) || '' === $loc ) {
					return new WP_Error( 'aibw_img_http', __( 'The image host sent an invalid redirect.', 'ai-blog-writer' ) );
				}
				$current = wp_http_validate_url( $loc ) ? $loc : '';
				if ( '' === $current ) {
					return new WP_Error( 'aibw_img_host', __( 'The image redirect was rejected.', 'ai-blog-writer' ) );
				}
				continue;
			}
			if ( 200 !== $code ) {
				return new WP_Error( 'aibw_img_http', 'HTTP ' . $code );
			}
			$type = (string) wp_remote_retrieve_header( $res, 'content-type' );
			$body = wp_remote_retrieve_body( $res );
			break;
		}
		if ( '' === $body ) {
			return new WP_Error( 'aibw_img_http', __( 'The image download was empty.', 'ai-blog-writer' ) );
		}
		if ( strlen( $body ) > 8 * 1024 * 1024 ) {
			return new WP_Error( 'aibw_img_size', __( 'The image is larger than 8 MB.', 'ai-blog-writer' ) );
		}
		if ( $type && ! preg_match( '#image/(jpeg|png|webp|gif)#i', $type ) ) {
			return new WP_Error( 'aibw_img_mime', __( 'The download was not a supported image type.', 'ai-blog-writer' ) );
		}
		$tmp = wp_tempnam( 'aibw-img' );
		if ( ! $tmp ) {
			return new WP_Error( 'aibw_img_tmp', __( 'Could not create a temporary file.', 'ai-blog-writer' ) );
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		$written = file_put_contents( $tmp, $body );
		if ( false === $written || $written !== strlen( $body ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return new WP_Error( 'aibw_img_tmp', __( 'Could not write the downloaded image.', 'ai-blog-writer' ) );
		}
		$info = @getimagesize( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( ! is_array( $info ) || empty( $info['mime'] ) || ! in_array( $info['mime'], array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
			return new WP_Error( 'aibw_img_mime', __( 'The downloaded file is not a valid image.', 'ai-blog-writer' ) );
		}
		return $tmp;
	}

	/**
	 * Search, download and attach images for an automation draft.
	 *
	 * @param int      $post_id
	 * @param string[] $queries First query is the featured image.
	 * @return array
	 */
	public static function attach_queries( $post_id, $queries ) {
		$results = array();
		$exclude = array();
		$queries = array_values( array_filter( array_map( array( __CLASS__, 'clean_query' ), (array) $queries ) ) );
		$index   = 0;
		foreach ( $queries as $query ) {
			// The first requested image is the cover; failures must not silently
			// turn an inline-image request into a featured image.
			$is_cover = ( 0 === $index );
			++$index;
			$hit = self::find( $query, $exclude, '', '', true );
			if ( is_wp_error( $hit ) || ! $hit ) {
				$results[] = array(
					'query' => $query,
					'ok'    => false,
					'error' => is_wp_error( $hit ) ? $hit->get_error_message() : __( 'No matching photo.', 'ai-blog-writer' ),
				);
				continue;
			}
			$exclude[] = $hit['uid'];
			$id = self::import( $hit['src'], $post_id, $hit['alt'], $hit['credit'] );
			if ( is_wp_error( $id ) ) {
				$results[] = array( 'query' => $query, 'ok' => false, 'error' => $id->get_error_message() );
				continue;
			}
			if ( $is_cover ) {
				if ( ! has_post_thumbnail( $post_id ) && ! set_post_thumbnail( $post_id, $id ) ) {
					$results[] = array( 'query' => $query, 'ok' => false, 'error' => __( 'The featured image could not be assigned.', 'ai-blog-writer' ) );
					continue;
				}
			} else {
				$block   = self::block( $id, $hit['alt'], $hit['credit'] );
				$content = (string) get_post_field( 'post_content', $post_id );
				// Spread images over successive sections instead of placing all
				// inline photos immediately below the first heading.
				$section = (int) get_post_meta( $post_id, '_aibw_inline_image_section', true );
				$updated = self::insert_inline_block( $content, $block, $section );
				$saved = wp_update_post( array( 'ID' => $post_id, 'post_content' => $updated ), true );
				if ( is_wp_error( $saved ) || ! $saved ) {
					$results[] = array( 'query' => $query, 'ok' => false, 'error' => is_wp_error( $saved ) ? $saved->get_error_message() : __( 'Could not insert inline image.', 'ai-blog-writer' ) );
					continue;
				}
				update_post_meta( $post_id, '_aibw_inline_image_section', $section + 1 );
			}
			$results[] = array(
				'query'      => $query,
				'ok'         => true,
				'attachment' => $id,
				'provider'   => isset( $hit['provider'] ) ? $hit['provider'] : '',
				'src'        => $hit['src'],
			);
		}

		return $results;
	}


	/** Insert after successive H2 headings; append when no further section exists. */
	private static function insert_inline_block( $content, $block, $section ) {
		$matches = array();
		preg_match_all( '/<h2\b[^>]*>.*?<\/h2>/is', $content, $matches, PREG_OFFSET_CAPTURE );
		if ( ! empty( $matches[0][ $section ] ) ) {
			$match = $matches[0][ $section ];
			$at = $match[1] + strlen( $match[0] );
			return substr( $content, 0, $at ) . "\n" . $block . substr( $content, $at );
		}
		return $content . "\n" . $block;
	}

	/** A WordPress image block: centred, captioned, editable in the normal editor. */
	public static function block( $attachment_id, $alt, $credit_html ) {
		$img = wp_get_attachment_image_src( $attachment_id, 'large' );
		$url = $img ? $img[0] : wp_get_attachment_url( $attachment_id );
		$cap = '' !== trim( (string) $credit_html ) ? '<figcaption class="wp-element-caption">' . self::allowed_credit( $credit_html ) . '</figcaption>' : '';

		return '<!-- wp:image {"id":' . (int) $attachment_id . ',"sizeSlug":"large","linkDestination":"none","align":"center","className":"aibw-figure"} -->' . "\n"
			. '<figure class="wp-block-image aligncenter size-large aibw-figure"><img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . (int) $attachment_id . '"/>' . $cap . '</figure>' . "\n"
			. '<!-- /wp:image -->';
	}

	/**
	 * Turn the editor's preview figures into real Media Library images.
	 * Figures whose picture cannot be imported are dropped, so no broken boxes are published.
	 */
	public static function process_content( $content, $post_id ) {
		$content = preg_replace( '#<div[^>]*\baibw-tools\b[^>]*>.*?</div>#is', '', $content );

		return preg_replace_callback(
			'#<figure\b[^>]*\baibw-figure\b[^>]*>(.*?)</figure>#is',
			function ( $m ) use ( $post_id ) {
				$inner = $m[1];
				if ( ! preg_match( '#<img\b[^>]*\bsrc=["\']([^"\']+)["\']#i', $inner, $src ) ) {
					return '';
				}
				$alt = '';
				if ( preg_match( '#<img\b[^>]*\balt=["\']([^"\']*)["\']#i', $inner, $a ) ) {
					$alt = html_entity_decode( $a[1], ENT_QUOTES );
				}
				$credit = '';
				if ( preg_match( '#<figcaption[^>]*>(.*?)</figcaption>#is', $inner, $c ) ) {
					$credit = $c[1];
				}

				$id = self::import( html_entity_decode( $src[1] ), $post_id, $alt, $credit );
				if ( is_wp_error( $id ) ) {
					AIBW_Settings::log( $id->get_error_message(), 'images' );
					return '';
				}
				return self::block( $id, $alt, $credit );
			},
			$content
		);
	}
}
