import type { ParsedIp } from '../lib/ip.js';
import type { ProviderRegistry } from '../providers/registry.js';
import {
  PROVIDER_IDS,
  type GeoRecord,
  type ProviderId,
  type ProviderInfo,
  type ProviderResult,
} from '../providers/types.js';

export interface TimezoneInfo {
  id: string | null;
  utc_offset: string;
  local_time: string | null;
}

export interface Summary {
  country_code: string | null;
  country: string | null;
  continent: string | null;
  region: string | null;
  city: string | null;
  postal_code: string | null;
  latitude: number | null;
  longitude: number | null;
  timezone: TimezoneInfo | null;
  asn: number | null;
  organization: string | null;
  /** Which provider each group of summary fields came from. */
  sources: { location: ProviderId | null; network: ProviderId | null };
  /** How many answering providers report the same country as the summary. */
  country_agreement: { matching: number; total: number };
}

export interface LookupResponse {
  ip: string;
  version: 4 | 6;
  is_public: boolean;
  range: string;
  summary: Summary | null;
  providers: Record<ProviderId, ProviderResult>;
  generated_at: string;
  notice?: string;
}

const LOCATION_PRIORITY: ProviderId[] = ['maxmind', 'ip2location', 'ipinfo'];
const NETWORK_PRIORITY: ProviderId[] = ['maxmind', 'ipinfo', 'ip2location'];

/** UTC offset like "+05:00" and local wall-clock time for an IANA zone; null if the zone is unknown. */
export function timeInZone(zone: string, now: Date = new Date()): { utc_offset: string; local_time: string } | null {
  try {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: zone,
      hourCycle: 'h23',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'longOffset',
    }).formatToParts(now);
    const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
    const rawOffset = get('timeZoneName'); // "GMT+05:00" | "GMT"
    const offset = rawOffset === 'GMT' ? '+00:00' : rawOffset.replace('GMT', '').replace('\u2212', '-');
    if (!/^[+-]\d{2}:\d{2}$/.test(offset)) return null;
    const local = `${get('year')}-${get('month')}-${get('day')}T${get('hour')}:${get('minute')}:${get('second')}${offset}`;
    return { utc_offset: offset, local_time: local };
  } catch {
    return null;
  }
}

function pickProvider(
  results: Record<ProviderId, ProviderResult>,
  order: ProviderId[],
  has: (r: GeoRecord) => boolean,
): ProviderId | null {
  return order.find((id) => results[id].status === 'ok' && results[id].data && has(results[id].data!)) ?? null;
}

export function buildSummary(results: Record<ProviderId, ProviderResult>, now: Date = new Date()): Summary | null {
  const location =
    pickProvider(results, LOCATION_PRIORITY, (r) => r.city !== null) ??
    pickProvider(results, LOCATION_PRIORITY, (r) => r.country_code !== null);
  const network = pickProvider(results, NETWORK_PRIORITY, (r) => r.asn !== null || r.organization !== null || r.isp !== null);
  if (!location && !network) return null;

  const loc = location ? results[location].data! : null;
  const net = network ? results[network].data! : null;

  // Timezone: prefer the location provider's IANA id, otherwise any provider that has one, otherwise a bare offset.
  const ianaId =
    loc?.timezone ??
    LOCATION_PRIORITY.map((id) => results[id].data?.timezone ?? null).find((z) => z !== null) ??
    null;
  let timezone: TimezoneInfo | null = null;
  if (ianaId) {
    const t = timeInZone(ianaId, now);
    if (t) timezone = { id: ianaId, ...t };
  }
  if (!timezone) {
    const offset = LOCATION_PRIORITY.map((id) => results[id].data?.utc_offset ?? null).find((o) => o !== null) ?? null;
    if (offset) timezone = { id: null, utc_offset: offset, local_time: null };
  }

  const answering = PROVIDER_IDS.filter((id) => results[id].status === 'ok' && results[id].data?.country_code);
  const country = loc?.country_code ?? null;
  const matching = country ? answering.filter((id) => results[id].data!.country_code === country).length : 0;

  const network_org = net ? (net.organization ?? net.isp ?? null) : null;
  return {
    country_code: loc?.country_code ?? null,
    country: loc?.country ?? null,
    continent: loc?.continent ?? null,
    region: loc?.region ?? null,
    city: loc?.city ?? null,
    postal_code: loc?.postal_code ?? null,
    latitude: loc?.latitude ?? null,
    longitude: loc?.longitude ?? null,
    timezone,
    asn: net?.asn ?? null,
    organization: network_org,
    sources: { location, network },
    country_agreement: { matching, total: answering.length },
  };
}

export async function lookupIp(
  registry: ProviderRegistry,
  parsed: ParsedIp,
  only?: readonly ProviderId[],
  now: Date = new Date(),
): Promise<LookupResponse> {
  const base = {
    ip: parsed.ip,
    version: parsed.version,
    is_public: parsed.isPublic,
    range: parsed.range,
    generated_at: now.toISOString(),
  };

  if (!parsed.isPublic) {
    const skipped = { status: 'skipped', data: null } as const;
    return {
      ...base,
      summary: null,
      providers: { maxmind: skipped, ipinfo: skipped, ip2location: skipped },
      notice: `${parsed.ip} is a ${parsed.range} address, so it has no public geolocation data.`,
    };
  }

  const raw = await registry.lookup(parsed.ip, only);
  const notRequested: ProviderResult = { status: 'skipped', data: null, message: 'Not requested.' };
  const providers = {
    maxmind: raw.maxmind ?? notRequested,
    ipinfo: raw.ipinfo ?? notRequested,
    ip2location: raw.ip2location ?? notRequested,
  };
  return { ...base, summary: buildSummary(providers, now), providers };
}

export interface StatusResponse {
  status: 'ok' | 'degraded';
  uptime_seconds: number;
  rate_limit: { anonymous: number; with_api_key: number; window: string };
  providers: ProviderInfo[];
}
