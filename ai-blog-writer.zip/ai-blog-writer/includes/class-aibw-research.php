<?php
defined( 'ABSPATH' ) || exit;

/**
 * Source collection. Ordinary chat models are not treated as web search.
 * Wikipedia needs no key. Perplexity uses the connected account (it searches the web).
 * Brave Search is optional and needs its own key stored with the other credentials.
 */
class AIBW_Research {

	public static function providers() {
		return array(
			'wikipedia'  => __( 'Wikipedia (no key, encyclopedic sources)', 'ai-blog-writer' ),
			'perplexity' => __( 'Perplexity (uses the connected Perplexity key and live search)', 'ai-blog-writer' ),
			'brave'      => __( 'Brave Search API (separate key)', 'ai-blog-writer' ),
			'none'       => __( 'No web research', 'ai-blog-writer' ),
		);
	}

	public static function brave_key() {
		$s = AIBW_Settings::get();
		return isset( $s['research_keys']['brave'] ) ? AIBW_Settings::decrypt( $s['research_keys']['brave'] ) : '';
	}

	/**
	 * @return array|WP_Error Structured report. Never invents URLs.
	 */
	public static function collect( $topic, $keyword = '' ) {
		$auto = AIBW_Settings::automation();
		$id   = $auto['research_provider'];
		if ( 'off' === $auto['research_mode'] || 'none' === $id ) {
			return array(
				'provider'  => 'none',
				'sources'   => array(),
				'warnings'  => array( __( 'Research was not run because no research provider is selected.', 'ai-blog-writer' ) ),
				'retrieved' => current_time( 'mysql' ),
				'queries'   => array(),
			);
		}

		$queries = self::queries( $topic, $keyword );
		if ( 'perplexity' === $id ) {
			$report = self::perplexity( $queries, $topic );
		} elseif ( 'brave' === $id ) {
			$report = self::brave( $queries );
		} else {
			$report = self::wikipedia( $queries );
		}
		if ( is_wp_error( $report ) ) {
			return $report;
		}
		$report['queries']   = $queries;
		$report['retrieved'] = current_time( 'mysql' );
		$report['warnings']  = isset( $report['warnings'] ) ? $report['warnings'] : array();
		$report['limitations'] = __( 'Retrieved sources are stored with the draft. Matching a source is not the same as proving every sentence is true.', 'ai-blog-writer' );
		return $report;
	}

	public static function queries( $topic, $keyword ) {
		$base = trim( $keyword ? $keyword : $topic );
		$out  = array( mb_substr( $base, 0, 120 ) );
		if ( $keyword && $keyword !== $topic ) {
			$out[] = mb_substr( trim( $topic . ' ' . $keyword ), 0, 120 );
		}
		return array_values( array_unique( array_filter( $out ) ) );
	}

	private static function wikipedia( $queries ) {
		$sources = array();
		foreach ( $queries as $q ) {
			$url  = add_query_arg(
				array(
					'action'   => 'query',
					'list'     => 'search',
					'srsearch' => $q,
					'srlimit'  => 4,
					'format'   => 'json',
				),
				'https://en.wikipedia.org/w/api.php'
			);
			$data = self::get_json( $url, array( 'User-Agent' => 'AIBlogWriter/' . AIBW_VERSION . ' (WordPress)' ) );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			foreach ( isset( $data['query']['search'] ) ? $data['query']['search'] : array() as $hit ) {
				if ( empty( $hit['title'] ) ) {
					continue;
				}
				$page = 'https://en.wikipedia.org/wiki/' . rawurlencode( str_replace( ' ', '_', $hit['title'] ) );
				$excerpt = isset( $hit['snippet'] ) ? wp_strip_all_tags( $hit['snippet'] ) : '';
				$sources[ $page ] = array(
					'url'            => esc_url_raw( $page ),
					'title'          => sanitize_text_field( $hit['title'] ),
					'type'           => 'encyclopedia',
					'retrieved'      => current_time( 'mysql' ),
					'excerpt'        => sanitize_text_field( $excerpt ),
					'claims'         => array(),
					'verification'   => 'retrieved',
					'warnings'       => array(),
				);
			}
		}
		$sources = array_values( $sources );
		$warnings = array();
		if ( ! $sources ) {
			$warnings[] = __( 'The research provider returned no sources.', 'ai-blog-writer' );
		}
		return array(
			'provider' => 'wikipedia',
			'sources'  => $sources,
			'warnings' => $warnings,
		);
	}

	private static function brave( $queries ) {
		$key = self::brave_key();
		if ( '' === $key ) {
			return new WP_Error( 'aibw_research_key', __( 'Brave Search is selected but no API key is saved.', 'ai-blog-writer' ) );
		}
		$sources = array();
		foreach ( $queries as $q ) {
			$url  = add_query_arg(
				array(
					'q'     => $q,
					'count' => 5,
				),
				'https://api.search.brave.com/res/v1/web/search'
			);
			$data = self::get_json( $url, array( 'Accept' => 'application/json', 'X-Subscription-Token' => $key ) );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			$results = isset( $data['web']['results'] ) ? $data['web']['results'] : array();
			foreach ( $results as $hit ) {
				if ( empty( $hit['url'] ) || ! wp_http_validate_url( $hit['url'] ) ) {
					continue;
				}
				$sources[ $hit['url'] ] = array(
					'url'          => esc_url_raw( $hit['url'] ),
					'title'        => isset( $hit['title'] ) ? sanitize_text_field( $hit['title'] ) : '',
					'type'         => 'web',
					'retrieved'    => current_time( 'mysql' ),
					'excerpt'      => isset( $hit['description'] ) ? sanitize_text_field( $hit['description'] ) : '',
					'claims'       => array(),
					'verification' => 'retrieved',
					'warnings'     => array(),
				);
			}
		}
		return array(
			'provider' => 'brave',
			'sources'  => array_values( $sources ),
			'warnings' => array() === $sources ? array( __( 'Brave Search returned no results.', 'ai-blog-writer' ) ) : array(),
		);
	}

	private static function perplexity( $queries, $topic ) {
		if ( ! AIBW_Settings::is_ready( 'perplexity' ) ) {
			return new WP_Error( 'aibw_research_key', __( 'Perplexity research needs a connected Perplexity API key.', 'ai-blog-writer' ) );
		}
		$prompt = "Search the web for the topic below. Return JSON only with a sources array. Each source must be a page you actually retrieved and must include url, title, excerpt. Do not invent URLs.\nTopic: " . $topic . "\nQueries: " . implode( ' | ', $queries );
		$key    = AIBW_Settings::get_key( 'perplexity' );
		$model  = AIBW_Settings::get_model( 'perplexity' );
		$p      = AIBW_Providers::get( 'perplexity' );
		$res    = wp_remote_post(
			$p['endpoint'],
			array(
				'timeout' => 60,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $key,
				),
				'body'    => wp_json_encode(
					array(
						'model'    => $model ? $model : 'sonar',
						'messages' => array(
							array( 'role' => 'user', 'content' => $prompt ),
						),
					)
				),
			)
		);
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'aibw_research', $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'aibw_research', 'Perplexity HTTP ' . $code );
		}
		$sources = array();
		$cites   = array();
		if ( isset( $data['citations'] ) && is_array( $data['citations'] ) ) {
			$cites = $data['citations'];
		} elseif ( isset( $data['search_results'] ) && is_array( $data['search_results'] ) ) {
			foreach ( $data['search_results'] as $hit ) {
				if ( ! empty( $hit['url'] ) ) {
					$cites[] = $hit;
				}
			}
		}
		foreach ( $cites as $cite ) {
			if ( is_string( $cite ) ) {
				$url   = $cite;
				$title = $cite;
				$excerpt = '';
			} else {
				$url     = isset( $cite['url'] ) ? $cite['url'] : '';
				$title   = isset( $cite['title'] ) ? $cite['title'] : $url;
				$excerpt = isset( $cite['snippet'] ) ? $cite['snippet'] : '';
			}
			if ( ! wp_http_validate_url( $url ) ) {
				continue;
			}
			$sources[ $url ] = array(
				'url'          => esc_url_raw( $url ),
				'title'        => sanitize_text_field( $title ),
				'type'         => 'web',
				'retrieved'    => current_time( 'mysql' ),
				'excerpt'      => sanitize_text_field( $excerpt ),
				'claims'       => array(),
				'verification' => 'retrieved',
				'warnings'     => array(),
			);
		}
		if ( isset( $data['usage'] ) ) {
			AIBW_Providers::$last_usage = $data['usage'];
		}
		return array(
			'provider' => 'perplexity',
			'sources'  => array_values( $sources ),
			'warnings' => $sources ? array() : array( __( 'Perplexity did not return citation URLs, so no sources were stored.', 'ai-blog-writer' ) ),
		);
	}

	/**
	 * Compare the article with retrieved excerpts. Warnings only.
	 */
	public static function fact_flags( $html, $report ) {
		$warnings = isset( $report['warnings'] ) ? $report['warnings'] : array();
		$text     = wp_strip_all_tags( (string) $html );
		$blob     = '';
		foreach ( isset( $report['sources'] ) ? $report['sources'] : array() as $source ) {
			$blob .= ' ' . ( isset( $source['excerpt'] ) ? $source['excerpt'] : '' ) . ' ' . ( isset( $source['title'] ) ? $source['title'] : '' );
		}
		if ( preg_match_all( '/\b(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?%)\b/', $text, $nums ) ) {
			foreach ( array_unique( $nums[0] ) as $num ) {
				if ( false === strpos( $blob, $num ) ) {
					$warnings[] = sprintf(
						/* translators: %s: number */
						__( 'The number %s appears in the article but not in the retrieved excerpts. Treat it as unverified.', 'ai-blog-writer' ),
						$num
					);
				}
			}
		}
		if ( preg_match( '/\b(19|20)\d{2}\b/', $text, $year ) && (int) $year[0] > (int) gmdate( 'Y' ) + 1 ) {
			$warnings[] = __( 'The article contains a future year that looks inconsistent.', 'ai-blog-writer' );
		}
		if ( empty( $report['sources'] ) ) {
			$warnings[] = __( 'No supporting sources were stored. Citations were not invented to fill the gap.', 'ai-blog-writer' );
		}
		return array_values( array_unique( $warnings ) );
	}

	public static function references_html( $sources ) {
		if ( ! $sources ) {
			return '';
		}
		$html = '<h2>' . esc_html__( 'References', 'ai-blog-writer' ) . '</h2><ul>';
		foreach ( $sources as $source ) {
			if ( empty( $source['url'] ) || ! wp_http_validate_url( $source['url'] ) ) {
				continue;
			}
			$title = ! empty( $source['title'] ) ? $source['title'] : $source['url'];
			$html .= '<li><a href="' . esc_url( $source['url'] ) . '">' . esc_html( $title ) . '</a>';
			if ( ! empty( $source['retrieved'] ) ) {
				$html .= ' <small>(' . esc_html( $source['retrieved'] ) . ')</small>';
			}
			$html .= '</li>';
		}
		return $html . '</ul>';
	}

	private static function get_json( $url, $headers ) {
		$res = wp_remote_get( $url, array( 'timeout' => 20, 'headers' => $headers ) );
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'aibw_research', $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 401 === $code || 403 === $code ) {
			return new WP_Error( 'aibw_research_key', __( 'The research provider rejected the API key.', 'ai-blog-writer' ) );
		}
		if ( 429 === $code ) {
			return new WP_Error( 'aibw_research_rate', __( 'The research provider rate limit was reached.', 'ai-blog-writer' ) );
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'aibw_research', 'HTTP ' . $code );
		}
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		return is_array( $data ) ? $data : array();
	}
}
