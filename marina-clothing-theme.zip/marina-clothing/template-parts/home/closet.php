<?php
/**
 * Home: interactive "Walk-In Closet" rail.
 *
 * Featured products (then best sellers) hang on a showroom rail. Selecting
 * one updates the inspector card underneath; tabs filter by category.
 */

$marina_products = marina_showcase_products( 8 );

if ( count( $marina_products ) < 3 ) {
    return;
}

// Category tabs from the products on the rail (max 3).
$marina_tabs = array();
foreach ( $marina_products as $marina_p ) {
    $marina_terms = get_the_terms( $marina_p->get_id(), 'product_cat' );
    if ( ! $marina_terms || is_wp_error( $marina_terms ) ) {
        continue;
    }
    foreach ( $marina_terms as $marina_t ) {
        if ( (int) get_option( 'default_product_cat' ) === $marina_t->term_id ) {
            continue;
        }
        $marina_tabs[ $marina_t->slug ] = isset( $marina_tabs[ $marina_t->slug ] ) ? array( $marina_t->name, $marina_tabs[ $marina_t->slug ][1] + 1 ) : array( $marina_t->name, 1 );
    }
}
uasort(
    $marina_tabs,
    function ( $a, $b ) {
        return $b[1] - $a[1];
    }
);
$marina_tabs = array_slice( $marina_tabs, 0, 3, true );

$marina_items = array();
foreach ( $marina_products as $marina_p ) {
    $marina_badge   = marina_product_badge( $marina_p );
    $marina_short   = wp_strip_all_tags( $marina_p->get_short_description() );
    $marina_ajax    = $marina_p->is_purchasable() && $marina_p->is_in_stock() && $marina_p->supports( 'ajax_add_to_cart' );
    $marina_items[] = array(
        'id'     => $marina_p->get_id(),
        'title'  => $marina_p->get_name(),
        'price'  => marina_plain_price( $marina_p ),
        'img'    => wp_get_attachment_image_url( $marina_p->get_image_id(), 'woocommerce_thumbnail' ),
        'badge'  => $marina_badge ? $marina_badge[0] : __( 'Signature Collection', 'marina-clothing' ),
        'sub'    => marina_product_subtitle( $marina_p ),
        'fabric' => $marina_short ? wp_trim_words( $marina_short, 14 ) : wp_trim_words( wp_strip_all_tags( $marina_p->get_description() ), 14 ),
        'url'    => $marina_p->get_permalink(),
        'cart'   => $marina_ajax ? $marina_p->add_to_cart_url() : $marina_p->get_permalink(),
        'ajax'   => $marina_ajax,
        'cats'   => marina_product_cat_slugs( $marina_p ),
    );
}
$marina_first = $marina_items[0];
?>
<section class="section closet" id="virtual-closet" data-closet>
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow"><?php marina_the_icon( 'checkroom' ); ?><?php esc_html_e( 'The Showroom', 'marina-clothing' ); ?></span>
                <h2 class="section-head__title section-head__title--display"><?php esc_html_e( 'Walk-In Closet', 'marina-clothing' ); ?></h2>
                <p class="closet__intro"><?php esc_html_e( 'Explore draped garments on our brushed steel showroom rail. Select any piece to inspect tailoring and drape.', 'marina-clothing' ); ?></p>
            </div>

            <div class="closet__controls">
                <div class="segmented" role="group" aria-label="<?php esc_attr_e( 'Filter the rail', 'marina-clothing' ); ?>">
                    <button type="button" class="segmented__btn is-active" aria-pressed="true" data-closet-filter="all"><?php esc_html_e( 'All Pieces', 'marina-clothing' ); ?></button>
                    <?php foreach ( $marina_tabs as $marina_slug => $marina_tab ) : ?>
                        <button type="button" class="segmented__btn" aria-pressed="false" data-closet-filter="<?php echo esc_attr( $marina_slug ); ?>"><?php echo esc_html( $marina_tab[0] ); ?></button>
                    <?php endforeach; ?>
                </div>
                <div class="closet__arrows">
                    <button type="button" class="round-btn" data-closet-scroll="-1" aria-label="<?php esc_attr_e( 'Scroll left', 'marina-clothing' ); ?>"><?php marina_the_icon( 'chevron_left' ); ?></button>
                    <button type="button" class="round-btn" data-closet-scroll="1" aria-label="<?php esc_attr_e( 'Scroll right', 'marina-clothing' ); ?>"><?php marina_the_icon( 'chevron_right' ); ?></button>
                </div>
            </div>
        </div>

        <div class="closet__stage">
            <div class="closet__rail" aria-hidden="true">
                <span class="closet__bracket closet__bracket--l"></span>
                <span class="closet__bracket closet__bracket--c"></span>
                <span class="closet__bracket closet__bracket--r"></span>
                <span class="closet__cap closet__cap--l"></span>
                <span class="closet__bar"></span>
                <span class="closet__cap closet__cap--r"></span>
                <span class="closet__bar-shadow"></span>
            </div>

            <div class="closet__scroller" data-closet-scroller>
                <ul class="closet__items">
                    <?php foreach ( $marina_items as $marina_i => $marina_item ) : ?>
                        <li class="garment" data-cats="<?php echo esc_attr( $marina_item['cats'] ); ?>">
                            <button type="button" class="garment__btn<?php echo 0 === $marina_i ? ' is-active' : ''; ?>" data-garment="<?php echo esc_attr( wp_json_encode( $marina_item ) ); ?>" aria-pressed="<?php echo 0 === $marina_i ? 'true' : 'false'; ?>">
                                <span class="garment__hook"></span>
                                <span class="garment__hanger"></span>
                                <span class="garment__card">
                                    <span class="garment__image">
                                        <img src="<?php echo esc_url( $marina_item['img'] ); ?>" alt="" loading="lazy">
                                        <span class="garment__flag badge badge--dark"><?php esc_html_e( 'Inspecting', 'marina-clothing' ); ?></span>
                                    </span>
                                    <span class="garment__name"><?php echo esc_html( $marina_item['title'] ); ?></span>
                                    <span class="garment__price"><?php echo esc_html( $marina_item['price'] ); ?></span>
                                </span>
                            </button>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="inspector" data-inspector aria-live="polite">
                <div class="inspector__main">
                    <div class="inspector__thumb"><img src="<?php echo esc_url( $marina_first['img'] ); ?>" alt="" data-i="img"></div>
                    <div>
                        <div class="inspector__meta">
                            <span class="badge badge--sand" data-i="badge"><?php echo esc_html( $marina_first['badge'] ); ?></span>
                            <span class="inspector__dot"></span>
                            <span data-i="sub"><?php echo esc_html( $marina_first['sub'] ); ?></span>
                        </div>
                        <h3 class="inspector__title" data-i="title"><?php echo esc_html( $marina_first['title'] ); ?></h3>
                        <p class="inspector__fabric" data-i="fabric"><?php echo esc_html( $marina_first['fabric'] ); ?></p>
                    </div>
                </div>
                <div class="inspector__side">
                    <div class="inspector__price-wrap">
                        <span class="inspector__price-label"><?php esc_html_e( 'Showroom Price', 'marina-clothing' ); ?></span>
                        <span class="inspector__price" data-i="price"><?php echo esc_html( $marina_first['price'] ); ?></span>
                    </div>
                    <div class="inspector__actions">
                        <a class="btn btn--primary button add_to_cart_button<?php echo $marina_first['ajax'] ? ' ajax_add_to_cart' : ''; ?>" href="<?php echo esc_url( $marina_first['cart'] ); ?>" data-quantity="1" data-product_id="<?php echo esc_attr( $marina_first['id'] ); ?>" data-i="cart" data-label-ajax="<?php esc_attr_e( 'Quick Add', 'marina-clothing' ); ?>" data-label-link="<?php esc_attr_e( 'Choose Options', 'marina-clothing' ); ?>" rel="nofollow">
                            <?php marina_the_icon( 'shopping_bag' ); ?>
                            <span data-i="cart-label"><?php echo $marina_first['ajax'] ? esc_html__( 'Quick Add', 'marina-clothing' ) : esc_html__( 'Choose Options', 'marina-clothing' ); ?></span>
                        </a>
                        <a class="btn btn--tonal" href="<?php echo esc_url( $marina_first['url'] ); ?>" data-i="url"><?php esc_html_e( 'Inspect Piece', 'marina-clothing' ); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
