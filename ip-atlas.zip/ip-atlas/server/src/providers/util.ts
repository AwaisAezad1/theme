import fs from 'node:fs/promises';

/** Trim a value into a non-empty string, otherwise null. */
export function text(value: unknown): string | null {
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  if (typeof value !== 'string') return null;
  const t = value.trim();
  return t.length > 0 ? t : null;
}

export function latitude(value: unknown): number | null {
  const n = typeof value === 'string' ? Number(value) : value;
  return typeof n === 'number' && Number.isFinite(n) && n >= -90 && n <= 90 ? n : null;
}

export function longitude(value: unknown): number | null {
  const n = typeof value === 'string' ? Number(value) : value;
  return typeof n === 'number' && Number.isFinite(n) && n >= -180 && n <= 180 ? n : null;
}

/** Parse "AS15169", "15169" or 15169 into 15169. */
export function asnNumber(value: unknown): number | null {
  if (typeof value === 'number') return Number.isInteger(value) && value > 0 ? value : null;
  if (typeof value !== 'string') return null;
  const m = /^(?:AS)?\s*(\d{1,10})$/i.exec(value.trim());
  if (!m) return null;
  const n = Number(m[1]);
  return n > 0 ? n : null;
}

const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });

/** English country name for an ISO 3166-1 alpha-2 code, or null. */
export function countryName(code: string | null): string | null {
  if (!code || !/^[A-Za-z]{2}$/.test(code)) return null;
  try {
    const name = regionNames.of(code.toUpperCase());
    return name && name !== code.toUpperCase() ? name : null;
  } catch {
    return null;
  }
}

const CONTINENTS: Record<string, string> = {
  AF: 'Africa',
  AN: 'Antarctica',
  AS: 'Asia',
  EU: 'Europe',
  NA: 'North America',
  OC: 'Oceania',
  SA: 'South America',
};

export function continentName(code: string | null): string | null {
  return code ? (CONTINENTS[code.toUpperCase()] ?? null) : null;
}

/** "mtime:size" signature used to detect database file replacement. Null when the file is missing. */
export async function fileSignature(path: string): Promise<string | null> {
  try {
    const s = await fs.stat(path);
    if (!s.isFile()) return null;
    return `${s.mtimeMs}:${s.size}`;
  } catch {
    return null;
  }
}

/** Date -> "YYYY-MM-DD" if it is a plausible build date (2000-01-01 .. tomorrow), else null. */
export function plausibleDate(d: Date | null | undefined): string | null {
  if (!(d instanceof Date) || Number.isNaN(d.getTime())) return null;
  const t = d.getTime();
  if (t < Date.UTC(2000, 0, 1) || t > Date.now() + 86_400_000) return null;
  return d.toISOString().slice(0, 10);
}

/** Probe addresses used to sanity-check a freshly loaded database. */
export const PROBE_IPS = ['8.8.8.8', '1.1.1.1', '2001:4860:4860::8888'] as const;
