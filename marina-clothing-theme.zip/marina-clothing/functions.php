<?php
/**
 * Theme bootstrap.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MARINA_VERSION', '1.1.0' );
define( 'MARINA_DIR', get_template_directory() );
define( 'MARINA_URI', get_template_directory_uri() );

/*
 * Core theme files.
 */
require_once MARINA_DIR . '/inc/setup.php';
require_once MARINA_DIR . '/inc/helpers.php';
require_once MARINA_DIR . '/inc/customizer.php';
require_once MARINA_DIR . '/inc/enqueue.php';
require_once MARINA_DIR . '/inc/template-tags.php';
require_once MARINA_DIR . '/inc/ajax.php';

/*
 * WooCommerce integration.
 */
if ( class_exists( 'WooCommerce' ) || function_exists( 'is_woocommerce' ) ) {
    require_once MARINA_DIR . '/inc/woocommerce.php';
}
