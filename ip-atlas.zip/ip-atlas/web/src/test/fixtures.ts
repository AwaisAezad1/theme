import type { GeoRecord, LookupResponse } from '../types';

export const blank: GeoRecord = {
  country_code: null, country: null, continent_code: null, continent: null, region: null, city: null,
  postal_code: null, latitude: null, longitude: null, accuracy_radius_km: null, timezone: null,
  utc_offset: null, asn: null, organization: null, isp: null, domain: null,
};

export function londonResponse(overrides: Partial<LookupResponse> = {}): LookupResponse {
  return {
    ip: '81.2.69.142',
    version: 4,
    is_public: true,
    range: 'public',
    generated_at: '2026-10-12T06:00:00.000Z',
    summary: {
      country_code: 'GB', country: 'United Kingdom', continent: 'Europe', region: 'England', city: 'London',
      postal_code: null, latitude: 51.5142, longitude: -0.0931,
      timezone: { id: 'Europe/London', utc_offset: '+01:00', local_time: '2026-10-12T07:00:00+01:00' },
      asn: 5089, organization: 'Virgin Media Limited',
      sources: { location: 'maxmind', network: 'maxmind' },
      country_agreement: { matching: 3, total: 3 },
    },
    providers: {
      maxmind: { status: 'ok', data: { ...blank, country_code: 'GB', country: 'United Kingdom', region: 'England', city: 'London', latitude: 51.5142, longitude: -0.0931, timezone: 'Europe/London', asn: 5089, organization: 'Virgin Media Limited' } },
      ipinfo: { status: 'ok', data: { ...blank, country_code: 'GB', country: 'United Kingdom', asn: 5089, organization: 'Virgin Media Limited' } },
      ip2location: { status: 'unavailable', data: null },
    },
    ...overrides,
  };
}

export const statusResponse = {
  status: 'ok',
  uptime_seconds: 10,
  rate_limit: { anonymous: 60, with_api_key: 600, window: '1 minute' },
  providers: [
    { id: 'maxmind', name: 'MaxMind', source: 'GeoLite2 City + ASN (local database)', loaded: true, database_date: '2026-10-06', note: null, warning: null },
    { id: 'ipinfo', name: 'IPinfo', source: 'IPinfo database (local)', loaded: true, database_date: '2026-10-11', note: 'IPinfo Lite covers country and network (ASN) data only; city-level data needs a paid IPinfo plan.', warning: null },
    { id: 'ip2location', name: 'IP2Location', source: 'not installed', loaded: false, database_date: null, note: null, warning: null },
  ],
};

export function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
}
