export type ProviderId = 'maxmind' | 'ipinfo' | 'ip2location';
export const PROVIDER_IDS: ProviderId[] = ['maxmind', 'ipinfo', 'ip2location'];

export interface GeoRecord {
  country_code: string | null;
  country: string | null;
  continent_code: string | null;
  continent: string | null;
  region: string | null;
  city: string | null;
  postal_code: string | null;
  latitude: number | null;
  longitude: number | null;
  accuracy_radius_km: number | null;
  timezone: string | null;
  utc_offset: string | null;
  asn: number | null;
  organization: string | null;
  isp: string | null;
  domain: string | null;
}

export type ProviderStatus = 'ok' | 'no_data' | 'unavailable' | 'skipped' | 'error';

export interface ProviderResult {
  status: ProviderStatus;
  data: GeoRecord | null;
  message?: string;
}

export interface Summary {
  country_code: string | null;
  country: string | null;
  continent: string | null;
  region: string | null;
  city: string | null;
  postal_code: string | null;
  latitude: number | null;
  longitude: number | null;
  timezone: { id: string | null; utc_offset: string; local_time: string | null } | null;
  asn: number | null;
  organization: string | null;
  sources: { location: ProviderId | null; network: ProviderId | null };
  country_agreement: { matching: number; total: number };
}

export interface LookupResponse {
  ip: string;
  version: 4 | 6;
  is_public: boolean;
  range: string;
  summary: Summary | null;
  providers: Record<ProviderId, ProviderResult>;
  generated_at: string;
  notice?: string;
}

export interface ProviderInfo {
  id: ProviderId;
  name: string;
  source: string;
  loaded: boolean;
  database_date: string | null;
  note: string | null;
  warning: string | null;
}

export interface StatusResponse {
  status: 'ok' | 'degraded';
  uptime_seconds: number;
  rate_limit: { anonymous: number; with_api_key: number; window: string };
  providers: ProviderInfo[];
}
