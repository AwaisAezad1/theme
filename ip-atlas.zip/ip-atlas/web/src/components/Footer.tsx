import { CONTACT_EMAIL, PRIVACY_NOTE, SITE_NAME } from '../config';
import { LogoMark } from './Icons';

export default function Footer() {
  return (
    <footer className="border-t border-white/[0.07] bg-[#06101c]">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 text-sm text-slate-500 lg:px-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2.5 text-cyan-300">
            <LogoMark className="h-7 w-7" />
            <span className="font-bold text-white">{SITE_NAME}</span>
          </div>
          <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2">
            <a href="#api" className="hover:text-white">API</a>
            <a href="#sources" className="hover:text-white">Data sources</a>
            <a href="/api/v1/status" className="hover:text-white">Status</a>
            {CONTACT_EMAIL && <a href={`mailto:${CONTACT_EMAIL}`} className="hover:text-white">Contact</a>}
          </nav>
        </div>
        <p className="max-w-3xl text-xs leading-5">{PRIVACY_NOTE}</p>
        <p className="text-xs">© {new Date().getFullYear()} {SITE_NAME}. IP geolocation is approximate and provided without warranty.</p>
      </div>
    </footer>
  );
}
