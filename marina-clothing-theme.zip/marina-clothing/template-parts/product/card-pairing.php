<?php
/**
 * "Complete the look" pairing card.
 *
 * @var array $args { @type WC_Product $product }
 */

$marina_p = $args['product'];
$marina_b = marina_product_badge( $marina_p );
$marina_s = marina_product_subtitle( $marina_p );
?>
<article class="pairing-card">
    <a class="pairing-card__media" href="<?php echo esc_url( $marina_p->get_permalink() ); ?>">
        <?php echo $marina_p->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        <?php if ( $marina_b ) : ?>
            <span class="badge badge--pill pairing-card__badge"><?php echo esc_html( $marina_b[0] ); ?></span>
        <?php endif; ?>
    </a>
    <div class="pairing-card__body">
        <div>
            <h3 class="pairing-card__title"><a href="<?php echo esc_url( $marina_p->get_permalink() ); ?>"><?php echo esc_html( $marina_p->get_name() ); ?></a></h3>
            <?php if ( $marina_s ) : ?>
                <p class="pairing-card__sub"><?php echo esc_html( $marina_s ); ?></p>
            <?php endif; ?>
        </div>
        <div class="pairing-card__foot">
            <span class="price"><?php echo $marina_p->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
            <?php marina_add_to_cart_button( $marina_p, 'pairing-card__btn' ); ?>
        </div>
    </div>
</article>
