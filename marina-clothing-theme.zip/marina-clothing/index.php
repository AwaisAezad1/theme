<?php
/**
 * Blog index / generic fallback.
 */

get_header();

$marina_title = is_home() && get_option( 'page_for_posts' ) ? get_the_title( get_option( 'page_for_posts' ) ) : __( 'The Journal', 'marina-clothing' );
?>

<main id="primary" class="site-main">
    <?php
    marina_page_header(
        $marina_title,
        array(
            'eyebrow'     => __( 'Style Notes & Stories', 'marina-clothing' ),
            'description' => get_bloginfo( 'description' ),
        )
    );
    ?>

    <section class="section">
        <div class="container">
            <?php if ( have_posts() ) : ?>
                <div class="post-grid">
                    <?php
                    while ( have_posts() ) {
                        the_post();
                        get_template_part( 'template-parts/content', 'card' );
                    }
                    ?>
                </div>
                <?php marina_pagination(); ?>
            <?php else : ?>
                <?php get_template_part( 'template-parts/content', 'none' ); ?>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php
get_footer();
