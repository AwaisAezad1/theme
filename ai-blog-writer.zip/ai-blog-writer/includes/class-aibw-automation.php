<?php
defined( 'ABSPATH' ) || exit;

/**
 * Bounded automation pipeline. One stage runs per invocation.
 * Drafts are never published by this class.
 */
class AIBW_Automation {

	const RUN = 'aibw_run_state';

	public static function init() {
		add_action( 'save_post_post', array( __CLASS__, 'mark_manual_edit' ), 20, 2 );
	}

	public static function mark_manual_edit( $post_id, $post ) {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! get_post_meta( $post_id, '_aibw_generated', true ) ) {
			return;
		}
		if ( ! empty( $GLOBALS['AIBW_AUTOMATION_WRITE'] ) ) {
			return;
		}
		update_post_meta( $post_id, '_aibw_user_edited', '1' );
	}

	/**
	 * Advance the queue by one stage.
	 *
	 * @param bool $ignore_enabled Run Now bypasses the enabled flag but still respects pause and budget.
	 * @return array
	 */
	public static function step( $ignore_enabled = false ) {
		AIBW_DB::maybe_upgrade();
		AIBW_Jobs::recover_stale();
		$auto = AIBW_Settings::automation();
		if ( ! $ignore_enabled && empty( $auto['enabled'] ) ) {
			return array( 'ok' => false, 'message' => __( 'Automation is turned off.', 'ai-blog-writer' ) );
		}
		if ( ! empty( $auto['paused'] ) ) {
			return array( 'ok' => false, 'message' => __( 'Automation is paused.', 'ai-blog-writer' ) );
		}
		$budget = AIBW_Jobs::budget_blocked();
		if ( $budget ) {
			self::note_result( $budget );
			AIBW_Jobs::log_line( 0, 'warning', 'budget', '', $budget, 0, '' );
			self::notify( 'budget', $budget );
			return array( 'ok' => false, 'message' => $budget );
		}
		if ( ! AIBW_Scheduler::acquire_lock() ) {
			return array( 'ok' => false, 'message' => __( 'Another automation step is already running.', 'ai-blog-writer' ) );
		}

		$started = time();
		$result  = array( 'ok' => true, 'message' => __( 'Nothing to do.', 'ai-blog-writer' ) );
		try {
			if ( function_exists( 'set_time_limit' ) ) {
				@set_time_limit( (int) $auto['max_step_seconds'] + 15 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			}
			$guard = 0;
			while ( $guard < 6 && ( time() - $started ) < (int) $auto['max_step_seconds'] ) {
				++$guard;
				$job = AIBW_Jobs::active();
				if ( ! $job ) {
					$job = self::open_job();
				}
				if ( is_wp_error( $job ) ) {
					$result = array( 'ok' => false, 'message' => $job->get_error_message() );
					break;
				}
				if ( ! $job ) {
					break;
				}
				$result = self::advance( $job );
				if ( empty( $result['ok'] ) || ! empty( $result['post_id'] ) ) {
					break;
				}
			}
			if ( time() - $started >= (int) $auto['max_step_seconds'] ) {
				$result['message'] .= ' ' . __( 'Stopped this step to stay inside the time limit. The next scheduled tick continues the job.', 'ai-blog-writer' );
			}
		} catch ( Exception $e ) {
			$result = array( 'ok' => false, 'message' => $e->getMessage() );
		}
		AIBW_Scheduler::release_lock();
		self::note_result( $result['message'] );
		AIBW_Jobs::prune();
		return $result;
	}

	private static function open_job() {
		$state = get_option( self::RUN, array() );
		$auto  = AIBW_Settings::automation();
		$day   = current_time( 'Y-m-d' );
		if ( ! is_array( $state ) || ! isset( $state['day'] ) || $state['day'] !== $day ) {
			$state = array( 'day' => $day, 'count' => 0 );
		}
		if ( (int) $state['count'] >= (int) $auto['articles'] ) {
			return null;
		}
		$topic = AIBW_Topics::next_pending();
		if ( ! $topic && 'ideas' === $auto['topic_mode'] ) {
			return new WP_Error( 'aibw_notopic', __( 'No approved topic is waiting. Suggested ideas stay out of the queue until you approve them.', 'ai-blog-writer' ) );
		}
		if ( ! $topic ) {
			AIBW_Jobs::log_line( 0, 'warning', 'queue', '', __( 'No eligible topic was available, so this run stopped without inventing one.', 'ai-blog-writer' ), 0, '' );
			return new WP_Error( 'aibw_notopic', __( 'No eligible topic is in the queue.', 'ai-blog-writer' ) );
		}
		$id = AIBW_Jobs::create( $topic );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		AIBW_Topics::update( $topic->id, array( 'status' => 'assigned' ) );
		$state['count'] = (int) $state['count'] + 1;
		update_option( self::RUN, $state, false );
		return AIBW_Jobs::get( $id );
	}

	private static function advance( $job ) {
		$stage = $job->stage ? $job->stage : 'queued';
		if ( 'queued' === $stage || 'running' === $job->status ) {
			$stage = self::stage_after( $job );
		}
		AIBW_Jobs::update( $job->id, array( 'status' => 'running', 'started_at' => $job->started_at ? $job->started_at : current_time( 'mysql' ) ) );
		$job = AIBW_Jobs::get( $job->id );
		switch ( $stage ) {
			case 'researching':
				return self::do_research( $job );
			case 'generating':
				return self::do_generate( $job );
			case 'optimizing':
				return self::do_seo( $job );
			case 'importing_images':
				return self::do_images( $job );
			case 'draft_created':
				return array( 'ok' => true, 'message' => __( 'Draft already saved.', 'ai-blog-writer' ) );
			default:
				AIBW_Jobs::update( $job->id, array( 'stage' => 'researching', 'status' => 'researching' ) );
				return array( 'ok' => true, 'message' => __( 'Job queued for research.', 'ai-blog-writer' ) );
		}
	}

	private static function stage_after( $job ) {
		if ( 'queued' === $job->stage ) {
			return 'researching';
		}
		return $job->stage;
	}

	private static function do_research( $job ) {
		AIBW_Jobs::update( $job->id, array( 'status' => 'researching', 'stage' => 'researching' ) );
		$topic  = AIBW_Topics::get( $job->topic_id );
		$report = AIBW_Research::collect( $job->topic_text, $topic ? $topic->keyword : '' );
		if ( is_wp_error( $report ) ) {
			return self::fail( $job, 'researching', $report->get_error_message(), 'aibw_research_key' === $report->get_error_code() );
		}
		$auto = AIBW_Settings::automation();
		if ( 'required' === $auto['research_mode'] && empty( $report['sources'] ) ) {
			return self::fail( $job, 'researching', __( 'Research is required and no sources were retrieved. No draft was marked as researched.', 'ai-blog-writer' ), false );
		}
		AIBW_Jobs::update(
			$job->id,
			array(
				'research_json' => wp_json_encode( $report ),
				'stage'         => 'generating',
				'status'        => 'generating',
			)
		);
		AIBW_Jobs::log_line( $job->id, 'info', 'researching', $report['provider'], sprintf( __( 'Stored %d source(s).', 'ai-blog-writer' ), count( $report['sources'] ) ), 0, $job->topic_text );
		return array( 'ok' => true, 'message' => __( 'Research stored. Generation runs on the next step.', 'ai-blog-writer' ) );
	}

	private static function do_generate( $job ) {
		$auto     = AIBW_Settings::automation();
		$provider = AIBW_Settings::preferred_provider();
		if ( ! AIBW_Settings::is_ready( $provider ) ) {
			return self::fail( $job, 'generating', __( 'No connected AI is available to write the article.', 'ai-blog-writer' ), true );
		}
		$topic  = AIBW_Topics::get( $job->topic_id );
		$report = json_decode( (string) $job->research_json, true );
		$report = is_array( $report ) ? $report : array( 'sources' => array() );
		$brief  = self::source_brief( $report );
		$system = 'You write structured blog drafts. Return one JSON object and nothing else. Do not invent citations or URLs. Only mention a source if it appears in the research brief.';
		$prompt = "Write a blog draft as JSON with keys: title, slug, excerpt, content_html, seo_title, meta_description, focus_keyword, related_keywords (array), featured_image_query, inline_image_queries (array of short English photo search phrases), image_alts (array), references (array of {title,url} copied only from the research brief).\n"
			. 'Language: ' . ( $auto['language'] ? $auto['language'] : AIBW_Settings::get()['language'] ) . "\n"
			. 'Tone: ' . ( $auto['tone'] ? $auto['tone'] : AIBW_Settings::get()['tone'] ) . "\n"
			. 'Audience: ' . $auto['audience'] . "\n"
			. 'Niche: ' . $auto['niche'] . "\n"
			. 'Length between ' . (int) $auto['min_words'] . ' and ' . (int) $auto['max_words'] . " words.\n"
			. "content_html may use only p, h2, h3, ul, ol, li, strong, em, a, blockquote.\n"
			. "Topic:\n" . $job->topic_text . "\n"
			. ( $topic && $topic->keyword ? "Keyword: {$topic->keyword}\n" : '' )
			. "Research brief:\n" . $brief;

		$raw = AIBW_Providers::request( $provider, $prompt, AIBW_Settings::get_key( $provider ), AIBW_Settings::get_model( $provider ), 8192, $system );
		if ( is_wp_error( $raw ) && ! empty( AIBW_Settings::get()['fallback'] ) && 'groq' !== $provider && AIBW_Settings::is_ready( 'groq' ) ) {
			AIBW_Jobs::log_line( $job->id, 'warning', 'generating', $provider, $raw->get_error_message(), 0, $job->topic_text );
			$provider = 'groq';
			$raw      = AIBW_Providers::request( 'groq', $prompt, AIBW_Settings::get_key( 'groq' ), AIBW_Settings::get_model( 'groq' ), 8192, $system );
		}
		if ( is_wp_error( $raw ) ) {
			return self::fail( $job, 'generating', $raw->get_error_message(), false );
		}
		$article = self::decode_article( $raw );
		if ( is_wp_error( $article ) ) {
			return self::fail( $job, 'generating', $article->get_error_message(), false );
		}
		$article['references'] = self::filter_references( isset( $article['references'] ) ? $article['references'] : array(), $report );
		$usage = AIBW_Providers::$last_usage;
		$cost  = AIBW_Providers::estimate_cost( $provider, AIBW_Settings::get_model( $provider ), $usage );
		$tokens = 0;
		if ( isset( $usage['total_tokens'] ) ) {
			$tokens = (int) $usage['total_tokens'];
		} elseif ( isset( $usage['prompt_tokens'] ) ) {
			$tokens = (int) $usage['prompt_tokens'] + (int) ( isset( $usage['completion_tokens'] ) ? $usage['completion_tokens'] : 0 );
		}
		AIBW_Jobs::usage_add( $tokens, $cost );
		AIBW_Jobs::update(
			$job->id,
			array(
				'article_json'  => wp_json_encode( $article ),
				'provider'      => $provider,
				'model'         => AIBW_Settings::get_model( $provider ),
				'tokens'        => $tokens,
				'cost_estimate' => null === $cost ? null : $cost,
				'stage'         => 'optimizing',
				'status'        => 'optimizing',
			)
		);
		AIBW_Jobs::log_line( $job->id, 'info', 'generating', $provider, __( 'Structured article parsed.', 'ai-blog-writer' ), 0, $job->topic_text );
		return array( 'ok' => true, 'message' => __( 'Article generated. SEO runs on the next step.', 'ai-blog-writer' ) );
	}

	private static function do_seo( $job ) {
		$article = json_decode( (string) $job->article_json, true );
		if ( ! is_array( $article ) ) {
			return self::fail( $job, 'optimizing', __( 'The saved article data was unreadable.', 'ai-blog-writer' ), false );
		}
		$topic   = AIBW_Topics::get( $job->topic_id );
		$keyword = ! empty( $article['focus_keyword'] ) ? $article['focus_keyword'] : ( $topic ? $topic->keyword : '' );
		$review  = AIBW_SEO::review( $article, $keyword );
		$report  = json_decode( (string) $job->research_json, true );
		$flags   = AIBW_Research::fact_flags( $article['content_html'], is_array( $report ) ? $report : array() );
		$review['fact_warnings'] = $flags;
		$auto    = AIBW_Settings::automation();
		$blocked = ( 'required' === $auto['research_mode'] && $flags && empty( $auto['allow_warning_drafts'] ) );
		if ( $blocked ) {
			AIBW_Jobs::update( $job->id, array( 'seo_json' => wp_json_encode( $review ), 'status' => 'needs_review', 'stage' => 'optimizing', 'error_message' => __( 'Research warnings are unresolved and warning drafts are not allowed.', 'ai-blog-writer' ) ) );
			AIBW_Jobs::log_line( $job->id, 'warning', 'optimizing', '', implode( ' ', $flags ), 0, $job->topic_text );
			self::notify( 'research', implode( ' ', $flags ) );
			return array( 'ok' => false, 'message' => __( 'Draft was not saved because research warnings remain and the conservative setting is on.', 'ai-blog-writer' ) );
		}
		AIBW_Jobs::update(
			$job->id,
			array(
				'seo_json' => wp_json_encode( $review ),
				'stage'    => 'importing_images',
				'status'   => 'importing_images',
			)
		);
		return array( 'ok' => true, 'message' => __( 'SEO checks stored. Images run on the next step.', 'ai-blog-writer' ) );
	}

	private static function do_images( $job ) {
		$article = json_decode( (string) $job->article_json, true );
		$review  = json_decode( (string) $job->seo_json, true );
		$report  = json_decode( (string) $job->research_json, true );
		if ( ! is_array( $article ) || ! is_array( $review ) ) {
			return self::fail( $job, 'importing_images', __( 'Article data was missing before the draft could be saved.', 'ai-blog-writer' ), false );
		}
		if ( $job->post_id && get_post_meta( $job->post_id, '_aibw_user_edited', true ) ) {
			AIBW_Jobs::update( $job->id, array( 'status' => 'needs_review', 'error_message' => __( 'The draft was edited in WordPress, so automation did not replace it.', 'ai-blog-writer' ) ) );
			return array( 'ok' => false, 'message' => __( 'Skipped because the draft has manual edits.', 'ai-blog-writer' ) );
		}

		$content = wp_kses_post( $article['content_html'] );
		if ( is_array( $report ) ) {
			$content .= AIBW_Research::references_html( isset( $report['sources'] ) ? $report['sources'] : array() );
		}
		$content = AIBW_SEO::insert_internal_links( $content, $review['internal'] );
		$topic   = AIBW_Topics::get( $job->topic_id );
		$auto    = AIBW_Settings::automation();
		$author  = $auto['author'] ? (int) $auto['author'] : ( $topic ? 0 : 0 );
		if ( ! $author ) {
			$author = self::default_author();
		}
		$cat = $topic && $topic->category ? (int) $topic->category : (int) $auto['category'];
		if ( ! $cat ) {
			$cat = (int) AIBW_Settings::get()['category'];
		}

		$GLOBALS['AIBW_AUTOMATION_WRITE'] = true;
		$postarr = array(
			'post_title'   => sanitize_text_field( $article['title'] ),
			'post_name'    => $review['fields']['slug'],
			'post_excerpt' => $review['fields']['excerpt'],
			'post_content' => $content,
			'post_status'  => 'draft',
			'post_type'    => 'post',
			'post_author'  => $author,
		);
		if ( $cat ) {
			$postarr['post_category'] = array( $cat );
		}
		if ( $job->post_id && get_post( $job->post_id ) ) {
			$postarr['ID'] = (int) $job->post_id;
			$post_id       = wp_update_post( wp_slash( $postarr ), true );
		} else {
			$post_id = wp_insert_post( wp_slash( $postarr ), true );
		}
		if ( is_wp_error( $post_id ) ) {
			return self::fail( $job, 'importing_images', $post_id->get_error_message(), false );
		}
		$tags = $topic && $topic->tags ? $topic->tags : $auto['tags'];
		if ( $tags ) {
			wp_set_post_tags( $post_id, $tags, false );
		}
		update_post_meta( $post_id, '_aibw_generated', '1' );
		update_post_meta( $post_id, '_aibw_provider', sanitize_key( $job->provider ) );
		update_post_meta( $post_id, '_aibw_topic', $job->topic_text );
		update_post_meta( $post_id, '_aibw_job', (int) $job->id );
		update_post_meta( $post_id, '_aibw_research', is_array( $report ) ? $report : array() );
		update_post_meta( $post_id, '_aibw_warnings', isset( $review['fact_warnings'] ) ? $review['fact_warnings'] : array() );
		$seo_plugin = AIBW_SEO::apply( $post_id, $review['fields'] );

		$images = array();
		$mode   = $auto['images'] ? $auto['images'] : AIBW_Settings::get()['images'];
		$plan   = AIBW_Images::plan( $mode );
		if ( $plan['cover'] || $plan['inline'] ) {
			$queries = array();
			if ( $plan['cover'] ) {
				$queries[] = ! empty( $article['featured_image_query'] ) ? $article['featured_image_query'] : ( ! empty( $article['focus_keyword'] ) ? $article['focus_keyword'] : $job->topic_text );
			}
			if ( $plan['inline'] && ! empty( $article['inline_image_queries'] ) && is_array( $article['inline_image_queries'] ) ) {
				$queries = array_merge( $queries, array_slice( $article['inline_image_queries'], 0, (int) $plan['inline'] ) );
			}
			if ( $queries && ( AIBW_Images::is_ready() || AIBW_Images::get_key( 'pexels' ) || AIBW_Images::get_key( 'pixabay' ) ) ) {
				$images = AIBW_Images::attach_queries( $post_id, $queries );
				foreach ( $images as $img ) {
					if ( empty( $img['ok'] ) ) {
						AIBW_Jobs::log_line( $job->id, 'warning', 'importing_images', 'images', $img['error'], $post_id, $job->topic_text );
					}
				}
			} elseif ( $queries ) {
				$images[] = array( 'ok' => false, 'error' => __( 'No image provider key is connected.', 'ai-blog-writer' ) );
				AIBW_Jobs::log_line( $job->id, 'warning', 'importing_images', 'images', __( 'Images were skipped because no image key is connected.', 'ai-blog-writer' ), $post_id, $job->topic_text );
			}
		}

		AIBW_Jobs::update(
			$job->id,
			array(
				'post_id'     => $post_id,
				'images_json' => wp_json_encode( $images ),
				'status'      => 'draft_created',
				'stage'       => 'draft_created',
				'finished_at' => current_time( 'mysql' ),
				'error_message' => '',
			)
		);
		if ( $job->topic_id ) {
			AIBW_Topics::update( $job->topic_id, array( 'status' => 'completed' ) );
		}
		$msg = sprintf(
			/* translators: %s: post title */
			__( 'Draft saved: %s. It was not published.', 'ai-blog-writer' ),
			get_the_title( $post_id )
		);
		if ( ! $seo_plugin ) {
			$msg .= ' ' . __( 'SEO fields are stored on the draft. A frontend SEO plugin is not active, so those fields are not printed as meta tags by themselves.', 'ai-blog-writer' );
		}
		AIBW_Jobs::log_line( $job->id, 'info', 'draft_created', $job->provider, $msg, $post_id, $job->topic_text );
		self::notify( 'success', $msg );
		$failed_images = array_filter(
			$images,
			function ( $img ) {
				return empty( $img['ok'] );
			}
		);
		if ( $failed_images ) {
			self::notify( 'images', __( 'One or more images could not be imported. The draft was still saved.', 'ai-blog-writer' ) );
		}
		return array( 'ok' => true, 'message' => $msg, 'post_id' => $post_id );
	}

	public static function retry( $job_id ) {
		$job = AIBW_Jobs::get( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'aibw_job', __( 'Job not found.', 'ai-blog-writer' ) );
		}
		$auto = AIBW_Settings::automation();
		if ( (int) $job->attempts >= (int) $auto['max_retries'] ) {
			return new WP_Error( 'aibw_job', __( 'This job has used its retry limit.', 'ai-blog-writer' ) );
		}
		if ( $job->post_id && get_post_meta( $job->post_id, '_aibw_user_edited', true ) ) {
			return new WP_Error( 'aibw_job', __( 'The draft has manual edits. Retry was not started.', 'ai-blog-writer' ) );
		}
		$stage = $job->stage && 'draft_created' !== $job->stage ? $job->stage : 'researching';
		if ( in_array( $stage, array( 'queued', 'running' ), true ) ) {
			$stage = 'researching';
		}
		AIBW_Jobs::update(
			$job->id,
			array(
				'status'        => $stage,
				'stage'         => $stage,
				'attempts'      => (int) $job->attempts + 1,
				'error_message' => '',
				'finished_at'   => null,
			)
		);
		if ( $job->topic_id ) {
			AIBW_Topics::update( $job->topic_id, array( 'status' => 'processing' ) );
		}
		AIBW_Jobs::log_line( $job->id, 'info', $stage, '', __( 'Retry requested.', 'ai-blog-writer' ), (int) $job->post_id, $job->topic_text );
		return true;
	}

	private static function fail( $job, $stage, $message, $auth ) {
		$auto = AIBW_Settings::automation();
		AIBW_Jobs::update(
			$job->id,
			array(
				'status'        => 'failed',
				'stage'         => $stage,
				'attempts'      => (int) $job->attempts + 1,
				'error_message' => AIBW_Settings::redact( $message ),
				'finished_at'   => current_time( 'mysql' ),
			)
		);
		if ( $job->topic_id && ! $job->post_id ) {
			AIBW_Topics::update( $job->topic_id, array( 'status' => 'failed' ) );
		}
		AIBW_Jobs::log_line( $job->id, 'error', $stage, $job->provider, $message, (int) $job->post_id, $job->topic_text );
		AIBW_Settings::log( $message, $job->provider );
		self::notify( $auth ? 'auth' : ( 'researching' === $stage ? 'research' : 'failure' ), $message );
		if ( (int) $job->attempts + 1 <= (int) $auto['max_retries'] && ! $auth ) {
			return array( 'ok' => false, 'message' => $message . ' ' . __( 'You can retry this stage from the dashboard.', 'ai-blog-writer' ) );
		}
		return array( 'ok' => false, 'message' => $message );
	}

	public static function decode_article( $raw ) {
		$text = trim( (string) $raw );
		$text = preg_replace( '/^```(?:json)?\s*|\s*```$/m', '', $text );
		$start = strpos( $text, '{' );
		$end   = strrpos( $text, '}' );
		if ( false === $start || false === $end ) {
			return new WP_Error( 'aibw_parse', __( 'The AI did not return JSON.', 'ai-blog-writer' ) );
		}
		$data = json_decode( substr( $text, $start, $end - $start + 1 ), true );
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'aibw_parse', __( 'The AI returned invalid JSON.', 'ai-blog-writer' ) );
		}
		$html = isset( $data['content_html'] ) ? $data['content_html'] : '';
		$html = wp_kses_post( $html );
		if ( strlen( wp_strip_all_tags( $html ) ) < 80 || empty( $data['title'] ) ) {
			return new WP_Error( 'aibw_parse', __( 'The article JSON was missing a title or body.', 'ai-blog-writer' ) );
		}
		$data['title']        = sanitize_text_field( $data['title'] );
		$data['content_html'] = $html;
		$data['slug']         = AIBW_SEO::slug_from_title( isset( $data['slug'] ) ? $data['slug'] : $data['title'] );
		return $data;
	}

	private static function filter_references( $refs, $report ) {
		$allowed = array();
		foreach ( isset( $report['sources'] ) ? $report['sources'] : array() as $source ) {
			if ( ! empty( $source['url'] ) ) {
				$allowed[ untrailingslashit( $source['url'] ) ] = $source;
			}
		}
		$out = array();
		foreach ( (array) $refs as $ref ) {
			$url = isset( $ref['url'] ) ? untrailingslashit( esc_url_raw( $ref['url'] ) ) : '';
			if ( isset( $allowed[ $url ] ) ) {
				$out[] = array(
					'title' => $allowed[ $url ]['title'],
					'url'   => $allowed[ $url ]['url'],
				);
			}
		}
		return $out;
	}

	private static function source_brief( $report ) {
		$lines = array();
		foreach ( array_slice( isset( $report['sources'] ) ? $report['sources'] : array(), 0, 6 ) as $source ) {
			$lines[] = ( isset( $source['title'] ) ? $source['title'] : '' ) . ' | ' . ( isset( $source['url'] ) ? $source['url'] : '' ) . ' | ' . ( isset( $source['excerpt'] ) ? $source['excerpt'] : '' );
		}
		return $lines ? implode( "\n", $lines ) : __( 'No sources were retrieved.', 'ai-blog-writer' );
	}

	private static function default_author() {
		$users = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => array( 'ID' ) ) );
		return $users ? (int) $users[0]->ID : 1;
	}

	private static function note_result( $message ) {
		update_option(
			'aibw_last_run',
			array(
				'time'    => current_time( 'mysql' ),
				'message' => AIBW_Settings::redact( (string) $message ),
			),
			false
		);
	}

	public static function notify( $type, $message ) {
		$auto = AIBW_Settings::automation();
		$map  = array(
			'success'  => 'notify_success',
			'failure'  => 'notify_failure',
			'auth'     => 'notify_auth',
			'research' => 'notify_research',
			'images'   => 'notify_images',
			'budget'   => 'notify_budget',
		);
		if ( empty( $map[ $type ] ) || empty( $auto[ $map[ $type ] ] ) ) {
			return;
		}
		$hash = md5( $type . '|' . $message );
		$sent = get_option( 'aibw_mail_hash', '' );
		$when = (int) get_option( 'aibw_mail_time', 0 );
		if ( $hash === $sent && ( time() - $when ) < HOUR_IN_SECONDS ) {
			return;
		}
		$to = get_option( 'admin_email' );
		if ( ! is_email( $to ) ) {
			return;
		}
		wp_mail(
			$to,
			sprintf( __( '[%s] AI Blog Writer', 'ai-blog-writer' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
			AIBW_Settings::redact( $message ) . "\n\n" . admin_url( 'admin.php?page=aibw-automation' )
		);
		update_option( 'aibw_mail_hash', $hash, false );
		update_option( 'aibw_mail_time', time(), false );
	}

	/**
	 * Ask the connected AI for topic ideas. They are stored as suggestions, not queued.
	 */
	public static function suggest_topics( $count = 5 ) {
		$provider = AIBW_Settings::preferred_provider();
		if ( ! AIBW_Settings::is_ready( $provider ) ) {
			return new WP_Error( 'aibw_nokey', __( 'Connect an AI before requesting topic ideas.', 'ai-blog-writer' ) );
		}
		$auto   = AIBW_Settings::automation();
		$prompt = 'Suggest ' . (int) $count . ' blog topics as a JSON array of objects with title and keyword. Niche: ' . $auto['niche'] . '. Audience: ' . $auto['audience'] . '. Do not repeat common duplicates. JSON only.';
		$raw    = AIBW_Providers::request( $provider, $prompt, AIBW_Settings::get_key( $provider ), AIBW_Settings::get_model( $provider ), 1024, 'Return JSON only.' );
		if ( is_wp_error( $raw ) ) {
			return $raw;
		}
		$start = strpos( $raw, '[' );
		$end   = strrpos( $raw, ']' );
		if ( false === $start ) {
			return new WP_Error( 'aibw_parse', __( 'The AI did not return a topic list.', 'ai-blog-writer' ) );
		}
		$list = json_decode( substr( $raw, $start, $end - $start + 1 ), true );
		if ( ! is_array( $list ) ) {
			return new WP_Error( 'aibw_parse', __( 'The topic list was not valid JSON.', 'ai-blog-writer' ) );
		}
		$ids = array();
		foreach ( $list as $item ) {
			$title = is_array( $item ) && isset( $item['title'] ) ? $item['title'] : (string) $item;
			$id    = AIBW_Topics::insert(
				array(
					'title'   => $title,
					'keyword' => is_array( $item ) && isset( $item['keyword'] ) ? $item['keyword'] : '',
					'status'  => 'suggested',
					'source'  => 'ai',
				)
			);
			if ( ! is_wp_error( $id ) ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}
}
