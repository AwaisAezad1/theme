<?php
defined( 'ABSPATH' ) || exit;

/**
 * Admin menus, pages, AJAX handlers and form handlers.
 */
class AIBW_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menus' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );

		add_action( 'wp_ajax_aibw_generate', array( __CLASS__, 'ajax_generate' ) );
		add_action( 'wp_ajax_aibw_publish', array( __CLASS__, 'ajax_publish' ) );
		add_action( 'wp_ajax_aibw_test', array( __CLASS__, 'ajax_test' ) );
		add_action( 'wp_ajax_aibw_images', array( __CLASS__, 'ajax_images' ) );
		add_action( 'wp_ajax_aibw_test_image', array( __CLASS__, 'ajax_test_image' ) );

		add_action( 'admin_post_aibw_save_accounts', array( __CLASS__, 'save_accounts' ) );
		add_action( 'admin_post_aibw_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_aibw_clear_log', array( __CLASS__, 'clear_log' ) );
		add_action( 'admin_post_aibw_save_automation', array( __CLASS__, 'save_automation' ) );
		add_action( 'admin_post_aibw_automation_action', array( __CLASS__, 'automation_action' ) );
		add_action( 'admin_post_aibw_topic_action', array( __CLASS__, 'topic_action' ) );

		add_filter( 'plugin_action_links_' . AIBW_BASENAME, array( __CLASS__, 'action_links' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Menus & assets                                                      */
	/* ------------------------------------------------------------------ */

	public static function menus() {
		add_menu_page( __( 'AI Blog Writer', 'ai-blog-writer' ), __( 'AI Blog Writer', 'ai-blog-writer' ), 'edit_posts', 'aibw', array( __CLASS__, 'page_writer' ), 'dashicons-edit-page', 25 );
		add_submenu_page( 'aibw', __( 'Write a Blog', 'ai-blog-writer' ), __( 'Write a Blog', 'ai-blog-writer' ), 'edit_posts', 'aibw', array( __CLASS__, 'page_writer' ) );
		add_submenu_page( 'aibw', __( 'AI Accounts', 'ai-blog-writer' ), __( 'AI Accounts', 'ai-blog-writer' ), 'manage_options', 'aibw-accounts', array( __CLASS__, 'page_accounts' ) );
		add_submenu_page( 'aibw', __( 'Settings', 'ai-blog-writer' ), __( 'Settings', 'ai-blog-writer' ), 'manage_options', 'aibw-settings', array( __CLASS__, 'page_settings' ) );
		add_submenu_page( 'aibw', __( 'History', 'ai-blog-writer' ), __( 'History', 'ai-blog-writer' ), 'edit_posts', 'aibw-history', array( __CLASS__, 'page_history' ) );
		add_submenu_page( 'aibw', __( 'Automation', 'ai-blog-writer' ), __( 'Automation', 'ai-blog-writer' ), 'manage_options', 'aibw-automation', array( __CLASS__, 'page_automation' ) );
		add_submenu_page( 'aibw', __( 'Topic Queue', 'ai-blog-writer' ), __( 'Topic Queue', 'ai-blog-writer' ), 'manage_options', 'aibw-topics', array( __CLASS__, 'page_topics' ) );
		add_submenu_page( 'aibw', __( 'Content Calendar', 'ai-blog-writer' ), __( 'Content Calendar', 'ai-blog-writer' ), 'manage_options', 'aibw-calendar', array( __CLASS__, 'page_calendar' ) );
		add_submenu_page( 'aibw', __( 'Generated Drafts', 'ai-blog-writer' ), __( 'Generated Drafts', 'ai-blog-writer' ), 'edit_posts', 'aibw-drafts', array( __CLASS__, 'page_drafts' ) );
	}

	public static function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=aibw' ) ) . '">' . esc_html__( 'Write a Blog', 'ai-blog-writer' ) . '</a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=aibw-accounts' ) ) . '">' . esc_html__( 'AI Accounts', 'ai-blog-writer' ) . '</a>'
		);
		return $links;
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'aibw' ) ) {
			return;
		}
		wp_enqueue_style( 'aibw-admin', AIBW_URL . 'assets/admin.css', array(), AIBW_VERSION );
		wp_enqueue_script( 'aibw-admin', AIBW_URL . 'assets/admin.js', array(), AIBW_VERSION, true );
		wp_localize_script(
			'aibw-admin',
			'AIBW',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'aibw_nonce' ),
				'i18n'  => array(
					'needTopic'   => __( 'Please type a topic first.', 'ai-blog-writer' ),
					'writing'     => __( 'Writing your blog... this can take up to a minute.', 'ai-blog-writer' ),
					'generate'    => __( 'Generate Blog', 'ai-blog-writer' ),
					'regenerate'  => __( 'Generate Blog', 'ai-blog-writer' ),
					'saving'      => __( 'Saving...', 'ai-blog-writer' ),
					'testing'     => __( 'Testing...', 'ai-blog-writer' ),
					'badResponse' => __( 'The server did not answer properly. If this keeps happening, your host may be cutting long requests - try a shorter blog length.', 'ai-blog-writer' ),
					'needTitle'   => __( 'Please give the blog a title.', 'ai-blog-writer' ),
					'needContent' => __( 'The blog is empty.', 'ai-blog-writer' ),
					'findingImages' => __( 'Finding pictures...', 'ai-blog-writer' ),
					'noImage'     => __( 'No other picture found for this one.', 'ai-blog-writer' ),
					'imagesFailed' => __( 'The blog is ready, but pictures could not be added:', 'ai-blog-writer' ),
					'swap'        => __( 'Swap picture', 'ai-blog-writer' ),
					'remove'      => __( 'Remove', 'ai-blog-writer' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Pages                                                               */
	/* ------------------------------------------------------------------ */

	public static function page_writer() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		$settings    = AIBW_Settings::get();
		$providers   = AIBW_Providers::all();
		$ready       = AIBW_Settings::ready_providers();
		$selected    = AIBW_Settings::preferred_provider();
		$categories  = get_categories( array( 'hide_empty' => false ) );
		$can_publish = current_user_can( 'publish_posts' );
		$static_front = ( 'page' === get_option( 'show_on_front' ) );
		$images_ready = AIBW_Images::is_ready();
		include AIBW_DIR . 'includes/templates/writer-page.php';
	}

	public static function page_accounts() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		$settings  = AIBW_Settings::get();
		$providers = AIBW_Providers::all();
		$img_sources = AIBW_Images::sources();
		$msg       = self::flash();
		include AIBW_DIR . 'includes/templates/accounts-page.php';
	}

	public static function page_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		$settings     = AIBW_Settings::get();
		$categories   = get_categories( array( 'hide_empty' => false ) );
		$static_front = ( 'page' === get_option( 'show_on_front' ) );
		$msg          = self::flash();
		include AIBW_DIR . 'includes/templates/settings-page.php';
	}

	public static function page_automation() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		AIBW_DB::maybe_upgrade();
		$auto       = AIBW_Settings::automation();
		$settings   = AIBW_Settings::get();
		$categories = get_categories( array( 'hide_empty' => false ) );
		$authors    = get_users( array( 'role__in' => array( 'administrator', 'editor', 'author' ), 'fields' => array( 'ID', 'display_name' ) ) );
		$jobs       = AIBW_Jobs::counts();
		$topics     = AIBW_Topics::counts();
		$recent     = AIBW_Jobs::recent( 8 );
		$queue      = AIBW_Topics::list_topics( array( 'status' => 'pending', 'limit' => 8 ) );
		$last       = get_option( 'aibw_last_run', array() );
		$usage      = AIBW_Jobs::usage_today();
		$msg        = self::flash();
		$logs       = AIBW_Jobs::query_logs( array() );
		include AIBW_DIR . 'includes/templates/automation-page.php';
	}

	public static function page_topics() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		AIBW_DB::maybe_upgrade();
		$topics     = AIBW_Topics::list_topics( array( 'limit' => 100 ) );
		$categories = get_categories( array( 'hide_empty' => false ) );
		$msg        = self::flash();
		$edit       = null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['topic'] ) ) {
			$edit = AIBW_Topics::get( absint( $_GET['topic'] ) );
		}
		include AIBW_DIR . 'includes/templates/topics-page.php';
	}

	public static function page_calendar() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		AIBW_DB::maybe_upgrade();
		$topics = AIBW_Topics::list_topics( array( 'limit' => 100 ) );
		$msg    = self::flash();
		include AIBW_DIR . 'includes/templates/calendar-page.php';
	}

	public static function page_drafts() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'draft', 'pending' ),
				'posts_per_page' => 30,
				'meta_key'       => '_aibw_generated', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
		$focus = null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['draft'] ) ) {
			$focus = get_post( absint( $_GET['draft'] ) );
		}
		$msg = self::flash();
		include AIBW_DIR . 'includes/templates/drafts-page.php';
	}

	public static function page_history() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'posts_per_page' => 20,
				'meta_key'       => '_aibw_generated', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
		$log = AIBW_Settings::get_log();
		$msg = self::flash();
		include AIBW_DIR . 'includes/templates/history-page.php';
	}

	/** One-time message shown after a form is saved. */
	private static function flash() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$code = isset( $_GET['aibw_msg'] ) ? sanitize_key( wp_unslash( $_GET['aibw_msg'] ) ) : '';
		$all  = array(
			'saved'    => __( 'Saved.', 'ai-blog-writer' ),
			'cleared'  => __( 'Error log cleared.', 'ai-blog-writer' ),
			'ran'      => __( 'Automation step finished. Check the result below.', 'ai-blog-writer' ),
			'paused'   => __( 'Automation paused.', 'ai-blog-writer' ),
			'resumed'  => __( 'Automation resumed.', 'ai-blog-writer' ),
			'retried'  => __( 'Retry started.', 'ai-blog-writer' ),
			'topic'    => __( 'Topic updated.', 'ai-blog-writer' ),
			'imported' => __( 'Topics imported.', 'ai-blog-writer' ),
			'error'    => __( 'That action could not be completed.', 'ai-blog-writer' ),
		);
		return isset( $all[ $code ] ) ? $all[ $code ] : '';
	}

	private static function back( $page, $code ) {
		wp_safe_redirect( add_query_arg( array( 'page' => $page, 'aibw_msg' => $code ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Form handlers                                                       */
	/* ------------------------------------------------------------------ */

	private static function clean_model( $value ) {
		return preg_replace( '/[^A-Za-z0-9._:\/-]/', '', (string) $value );
	}

	public static function save_accounts() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_save_accounts' );

		$settings  = AIBW_Settings::get();
		$providers = AIBW_Providers::all();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$keys   = isset( $_POST['key'] ) && is_array( $_POST['key'] ) ? wp_unslash( $_POST['key'] ) : array();
		$models = isset( $_POST['model'] ) && is_array( $_POST['model'] ) ? wp_unslash( $_POST['model'] ) : array();
		$clear  = isset( $_POST['clear'] ) && is_array( $_POST['clear'] ) ? wp_unslash( $_POST['clear'] ) : array();
		// phpcs:enable

		foreach ( array_keys( $providers ) as $id ) {
			if ( ! empty( $clear[ $id ] ) ) {
				unset( $settings['keys'][ $id ] );
			} elseif ( isset( $keys[ $id ] ) && '' !== trim( (string) $keys[ $id ] ) ) {
				$settings['keys'][ $id ] = AIBW_Settings::encrypt( trim( sanitize_text_field( $keys[ $id ] ) ) );
			}
			if ( isset( $models[ $id ] ) ) {
				$model = self::clean_model( $models[ $id ] );
				if ( '' === $model ) {
					unset( $settings['models'][ $id ] );
				} else {
					$settings['models'][ $id ] = $model;
				}
			}
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$default = isset( $_POST['default_provider'] ) ? sanitize_key( wp_unslash( $_POST['default_provider'] ) ) : 'groq';
		$settings['default_provider'] = isset( $providers[ $default ] ) ? $default : 'groq';
		$settings['fallback']         = empty( $_POST['fallback'] ) ? 0 : 1;

		$img_sources = AIBW_Images::sources();
		$img_keys    = isset( $_POST['img_key'] ) && is_array( $_POST['img_key'] ) ? wp_unslash( $_POST['img_key'] ) : array();
		$img_clear   = isset( $_POST['img_clear'] ) && is_array( $_POST['img_clear'] ) ? wp_unslash( $_POST['img_clear'] ) : array();
		$img_source  = isset( $_POST['image_source'] ) ? sanitize_key( wp_unslash( $_POST['image_source'] ) ) : 'pexels';
		// phpcs:enable

		foreach ( array_keys( $img_sources ) as $sid ) {
			if ( ! empty( $img_clear[ $sid ] ) ) {
				unset( $settings['image_keys'][ $sid ] );
			} elseif ( isset( $img_keys[ $sid ] ) && '' !== trim( (string) $img_keys[ $sid ] ) ) {
				$settings['image_keys'][ $sid ] = AIBW_Settings::encrypt( trim( sanitize_text_field( $img_keys[ $sid ] ) ) );
			}
		}
		$settings['image_source'] = isset( $img_sources[ $img_source ] ) ? $img_source : 'pexels';

		AIBW_Settings::update( $settings );
		self::back( 'aibw-accounts', 'saved' );
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_save_settings' );

		$settings = AIBW_Settings::get();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$tone   = isset( $_POST['tone'] ) ? sanitize_key( wp_unslash( $_POST['tone'] ) ) : 'informative';
		$length = isset( $_POST['length'] ) ? sanitize_key( wp_unslash( $_POST['length'] ) ) : 'medium';

		$settings['tone']     = array_key_exists( $tone, AIBW_Generator::tones() ) ? $tone : 'informative';
		$settings['length']   = array_key_exists( $length, AIBW_Generator::lengths() ) ? $length : 'medium';
		$settings['language'] = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : 'English';
		$settings['category'] = isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0;
		$settings['sticky']   = empty( $_POST['sticky'] ) ? 0 : 1;
		$images               = isset( $_POST['images'] ) ? sanitize_key( wp_unslash( $_POST['images'] ) ) : 'some';
		$settings['images']   = array_key_exists( $images, AIBW_Images::modes() ) ? $images : 'some';
		// phpcs:enable

		AIBW_Settings::update( $settings );
		self::back( 'aibw-settings', 'saved' );
	}

	public static function clear_log() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_clear_log' );
		AIBW_Settings::clear_log();
		self::back( 'aibw-history', 'cleared' );
	}

	/* ------------------------------------------------------------------ */
	/* AJAX                                                                */
	/* ------------------------------------------------------------------ */

	public static function ajax_generate() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-blog-writer' ) ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 200 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$topic    = isset( $_POST['topic'] ) ? sanitize_textarea_field( wp_unslash( $_POST['topic'] ) ) : '';
		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$tone     = isset( $_POST['tone'] ) ? sanitize_key( wp_unslash( $_POST['tone'] ) ) : 'informative';
		$length   = isset( $_POST['length'] ) ? sanitize_key( wp_unslash( $_POST['length'] ) ) : 'medium';
		$language = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : 'English';
		$notes    = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';
		$images   = isset( $_POST['images'] ) ? sanitize_key( wp_unslash( $_POST['images'] ) ) : 'none';
		// phpcs:enable

		// Pictures only work when an image source is connected.
		$images = ( array_key_exists( $images, AIBW_Images::modes() ) && AIBW_Images::is_ready() ) ? $images : 'none';

		$topic = trim( mb_substr( $topic, 0, 500 ) );
		if ( mb_strlen( $topic ) < 3 ) {
			wp_send_json_error( array( 'message' => __( 'Please type a topic first.', 'ai-blog-writer' ) ) );
		}
		if ( ! AIBW_Providers::get( $provider ) ) {
			wp_send_json_error( array( 'message' => __( 'Please choose an AI.', 'ai-blog-writer' ) ) );
		}

		$result = AIBW_Generator::generate(
			$topic,
			$provider,
			array(
				'tone'     => array_key_exists( $tone, AIBW_Generator::tones() ) ? $tone : 'informative',
				'length'   => array_key_exists( $length, AIBW_Generator::lengths() ) ? $length : 'medium',
				'language' => mb_substr( $language, 0, 40 ),
				'notes'    => mb_substr( $notes, 0, 500 ),
				'images'   => $images,
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( $result );
	}

	public static function ajax_publish() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-blog-writer' ) ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$status   = ( isset( $_POST['status'] ) && 'draft' === $_POST['status'] ) ? 'draft' : 'publish';
		$title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$content  = isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '';
		$topic    = isset( $_POST['topic'] ) ? sanitize_textarea_field( wp_unslash( $_POST['topic'] ) ) : '';
		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$sticky   = ! empty( $_POST['sticky'] );
		$category = isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0;
		$cover    = isset( $_POST['cover'] ) ? json_decode( wp_unslash( $_POST['cover'] ), true ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field is sanitised below.
		// phpcs:enable

		$cover = is_array( $cover ) && ! empty( $cover['src'] ) ? array(
			'src'    => esc_url_raw( (string) $cover['src'] ),
			'alt'    => isset( $cover['alt'] ) ? sanitize_text_field( (string) $cover['alt'] ) : '',
			'credit' => isset( $cover['credit'] ) ? wp_kses( (string) $cover['credit'], array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ) ) ) : '',
		) : array();

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 200 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		if ( 'publish' === $status && ! current_user_can( 'publish_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You can save drafts, but you are not allowed to publish.', 'ai-blog-writer' ) ) );
		}
		if ( '' === $title ) {
			wp_send_json_error( array( 'message' => __( 'Please give the blog a title.', 'ai-blog-writer' ) ) );
		}
		if ( '' === trim( wp_strip_all_tags( $content ) ) ) {
			wp_send_json_error( array( 'message' => __( 'The blog is empty.', 'ai-blog-writer' ) ) );
		}

		$post_id = AIBW_Generator::publish(
			array(
				'status'   => $status,
				'title'    => $title,
				'content'  => $content,
				'topic'    => $topic,
				'provider' => $provider,
				'sticky'   => $sticky,
				'category' => $category,
				'cover'    => $cover,
			)
		);
		if ( is_wp_error( $post_id ) ) {
			wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
		}

		$on_posts_front = ( 'posts' === get_option( 'show_on_front' ) );
		if ( 'draft' === $status ) {
			$message = __( 'Saved as a draft. You can finish it in the WordPress editor.', 'ai-blog-writer' );
		} elseif ( $on_posts_front ) {
			$message = __( 'Done! Your blog is now on your front page.', 'ai-blog-writer' );
		} else {
			$message = __( 'Published! Note: your front page is a fixed page, so add the shortcode [aibw_latest_blogs] to it to show your newest AI blogs there.', 'ai-blog-writer' );
		}

		wp_send_json_success(
			array(
				'message'  => $message,
				'view_url' => 'publish' === $status ? get_permalink( $post_id ) : get_preview_post_link( $post_id ),
				'edit_url' => get_edit_post_link( $post_id, 'raw' ),
				'home_url' => home_url( '/' ),
				'status'   => $status,
			)
		);
	}

	public static function ajax_test() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-blog-writer' ) ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$key      = isset( $_POST['key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['key'] ) ) ) : '';
		$model    = isset( $_POST['model'] ) ? self::clean_model( wp_unslash( $_POST['model'] ) ) : '';
		// phpcs:enable

		if ( ! AIBW_Providers::get( $provider ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown AI.', 'ai-blog-writer' ) ) );
		}
		if ( '' === $key ) {
			$key = AIBW_Settings::get_key( $provider ); // Use the saved key when the field is empty.
		}
		if ( '' === $model ) {
			$model = AIBW_Settings::get_model( $provider );
		}

		$start  = microtime( true );
		$result = AIBW_Providers::test( $provider, $key, $model );
		$ms     = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				/* translators: %d: milliseconds */
				'message' => sprintf( __( 'Connected! The AI answered in %d ms.', 'ai-blog-writer' ), $ms ),
				'models'  => AIBW_Providers::list_models( $provider, $key ),
			)
		);
	}
	/**
	 * Finds one stock photo per search phrase. The browser calls this right after the blog text
	 * appears, so the text is never held up by the picture search.
	 */
	public static function ajax_images() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-blog-writer' ) ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- verified above; values are sanitised below.
		$queries = isset( $_POST['queries'] ) ? json_decode( wp_unslash( $_POST['queries'] ), true ) : array();
		$exclude = isset( $_POST['exclude'] ) ? json_decode( wp_unslash( $_POST['exclude'] ), true ) : array();
		// phpcs:enable

		$queries = is_array( $queries ) ? array_slice( $queries, 0, 7 ) : array();
		$exclude = is_array( $exclude ) ? array_map( 'sanitize_text_field', array_slice( $exclude, 0, 30 ) ) : array();

		if ( ! AIBW_Images::is_ready() ) {
			wp_send_json_error( array( 'message' => __( 'No image source is connected yet. Add a free key on the AI Accounts page.', 'ai-blog-writer' ) ) );
		}

		$items = array();
		foreach ( $queries as $q ) {
			$hit = AIBW_Images::find( (string) $q, $exclude );
			if ( is_wp_error( $hit ) ) {
				AIBW_Settings::log( $hit->get_error_message(), 'images' );
				wp_send_json_error( array( 'message' => $hit->get_error_message() ) );
			}
			if ( $hit ) {
				$exclude[] = $hit['uid'];
			}
			$items[] = $hit;
		}

		wp_send_json_success( array( 'items' => $items ) );
	}

	public static function ajax_test_image() {
		check_ajax_referer( 'aibw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-blog-writer' ) ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$source = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : '';
		$key    = isset( $_POST['key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['key'] ) ) ) : '';
		// phpcs:enable

		if ( ! isset( AIBW_Images::sources()[ $source ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown image source.', 'ai-blog-writer' ) ) );
		}
		if ( '' === $key ) {
			$key = AIBW_Images::get_key( $source );
		}

		$result = AIBW_Images::test( $source, $key );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'message' => __( 'Connected! Photos can be found.', 'ai-blog-writer' ) ) );
	}

	public static function save_automation() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_save_automation' );
		$settings = AIBW_Settings::get();
		$auto     = AIBW_Settings::automation();
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$auto['enabled']              = empty( $_POST['enabled'] ) ? 0 : 1;
		$freq                         = isset( $_POST['frequency'] ) ? sanitize_key( wp_unslash( $_POST['frequency'] ) ) : 'daily';
		$auto['frequency']            = in_array( $freq, array( 'daily', 'weekly', 'days' ), true ) ? $freq : 'daily';
		$time                         = isset( $_POST['time'] ) ? sanitize_text_field( wp_unslash( $_POST['time'] ) ) : '09:00';
		$auto['time']                 = preg_match( '/^\d{2}:\d{2}$/', $time ) ? $time : '09:00';
		$days                         = isset( $_POST['weekdays'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['weekdays'] ) ) : array();
		$auto['weekdays']             = array_values( array_filter( $days, function ( $d ) { return $d >= 0 && $d <= 6; } ) );
		$auto['articles']             = isset( $_POST['articles'] ) ? absint( $_POST['articles'] ) : 1;
		$auto['min_words']            = isset( $_POST['min_words'] ) ? absint( $_POST['min_words'] ) : 600;
		$auto['max_words']            = isset( $_POST['max_words'] ) ? absint( $_POST['max_words'] ) : 1200;
		$auto['language']             = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '';
		$tone                         = isset( $_POST['tone'] ) ? sanitize_key( wp_unslash( $_POST['tone'] ) ) : '';
		$auto['tone']                 = array_key_exists( $tone, AIBW_Generator::tones() ) ? $tone : '';
		$auto['audience']             = isset( $_POST['audience'] ) ? sanitize_text_field( wp_unslash( $_POST['audience'] ) ) : '';
		$auto['niche']                = isset( $_POST['niche'] ) ? sanitize_text_field( wp_unslash( $_POST['niche'] ) ) : '';
		$auto['category']             = isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0;
		$auto['tags']                 = isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '';
		$auto['author']               = isset( $_POST['author'] ) ? absint( $_POST['author'] ) : 0;
		$images                       = isset( $_POST['images'] ) ? sanitize_key( wp_unslash( $_POST['images'] ) ) : '';
		$auto['images']               = array_key_exists( $images, AIBW_Images::modes() ) ? $images : '';
		$primary                      = isset( $_POST['image_primary'] ) ? sanitize_key( wp_unslash( $_POST['image_primary'] ) ) : '';
		$fallback                     = isset( $_POST['image_fallback'] ) ? sanitize_key( wp_unslash( $_POST['image_fallback'] ) ) : '';
		$auto['image_primary']        = isset( AIBW_Images::sources()[ $primary ] ) ? $primary : '';
		$auto['image_fallback']       = isset( AIBW_Images::sources()[ $fallback ] ) ? $fallback : '';
		$mode                         = isset( $_POST['research_mode'] ) ? sanitize_key( wp_unslash( $_POST['research_mode'] ) ) : 'required';
		$auto['research_mode']        = in_array( $mode, array( 'required', 'optional', 'off' ), true ) ? $mode : 'required';
		$rp                           = isset( $_POST['research_provider'] ) ? sanitize_key( wp_unslash( $_POST['research_provider'] ) ) : 'wikipedia';
		$auto['research_provider']    = array_key_exists( $rp, AIBW_Research::providers() ) ? $rp : 'wikipedia';
		$auto['allow_warning_drafts'] = empty( $_POST['allow_warning_drafts'] ) ? 0 : 1;
		$auto['seo_checks']           = empty( $_POST['seo_checks'] ) ? 0 : 1;
		foreach ( array( 'notify_success', 'notify_failure', 'notify_auth', 'notify_research', 'notify_images', 'notify_budget' ) as $flag ) {
			$auto[ $flag ] = empty( $_POST[ $flag ] ) ? 0 : 1;
		}
		$auto['daily_budget']       = isset( $_POST['daily_budget'] ) ? (float) wp_unslash( $_POST['daily_budget'] ) : 0;
		$auto['max_retries']        = isset( $_POST['max_retries'] ) ? absint( $_POST['max_retries'] ) : 2;
		$auto['max_step_seconds']   = isset( $_POST['max_step_seconds'] ) ? absint( $_POST['max_step_seconds'] ) : 40;
		$tmode                      = isset( $_POST['topic_mode'] ) ? sanitize_key( wp_unslash( $_POST['topic_mode'] ) ) : 'queue';
		$auto['topic_mode']         = in_array( $tmode, array( 'queue', 'ideas' ), true ) ? $tmode : 'queue';
		$auto['log_retention_days'] = isset( $_POST['log_retention_days'] ) ? absint( $_POST['log_retention_days'] ) : 30;
		$brave                      = isset( $_POST['brave_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['brave_key'] ) ) ) : '';
		// phpcs:enable
		if ( '' !== $brave ) {
			if ( ! isset( $settings['research_keys'] ) || ! is_array( $settings['research_keys'] ) ) {
				$settings['research_keys'] = array();
			}
			$settings['research_keys']['brave'] = AIBW_Settings::encrypt( $brave );
		}
		if ( $auto['image_primary'] ) {
			$settings['image_source'] = $auto['image_primary'];
		}
		$settings['automation'] = $auto;
		AIBW_Settings::update( $settings );
		if ( $auto['enabled'] && empty( $auto['paused'] ) ) {
			AIBW_Scheduler::arm( AIBW_Scheduler::next_timestamp() );
		} else {
			AIBW_Scheduler::unschedule();
		}
		self::back( 'aibw-automation', 'saved' );
	}

	public static function automation_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_automation_action' );
		$action = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$settings = AIBW_Settings::get();
		$auto     = AIBW_Settings::automation();
		if ( 'pause' === $action ) {
			$auto['paused'] = 1;
			$settings['automation'] = $auto;
			AIBW_Settings::update( $settings );
			AIBW_Scheduler::unschedule();
			self::back( 'aibw-automation', 'paused' );
		}
		if ( 'resume' === $action ) {
			$auto['paused']  = 0;
			$auto['enabled'] = 1;
			$settings['automation'] = $auto;
			AIBW_Settings::update( $settings );
			AIBW_Scheduler::arm( AIBW_Scheduler::next_timestamp() );
			self::back( 'aibw-automation', 'resumed' );
		}
		if ( 'run' === $action ) {
			if ( function_exists( 'set_time_limit' ) ) {
				@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			}
			AIBW_Automation::step( true );
			if ( AIBW_Jobs::active() ) {
				AIBW_Scheduler::arm( time() + 60 );
			}
			self::back( 'aibw-automation', 'ran' );
		}
		if ( 'retry' === $action ) {
			$id = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
			$ok = AIBW_Automation::retry( $id );
			if ( is_wp_error( $ok ) ) {
				AIBW_Settings::log( $ok->get_error_message(), '' );
				self::back( 'aibw-automation', 'error' );
			}
			AIBW_Automation::step( true );
			self::back( 'aibw-automation', 'retried' );
		}
		self::back( 'aibw-automation', 'error' );
	}

	public static function topic_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-blog-writer' ) );
		}
		check_admin_referer( 'aibw_topic_action' );
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$id = isset( $_POST['topic_id'] ) ? absint( $_POST['topic_id'] ) : 0;
		if ( 'add' === $do || 'edit' === $do ) {
			$data = array(
				'title'          => isset( $_POST['title'] ) ? wp_unslash( $_POST['title'] ) : '',
				'keyword'        => isset( $_POST['keyword'] ) ? wp_unslash( $_POST['keyword'] ) : '',
				'audience'       => isset( $_POST['audience'] ) ? wp_unslash( $_POST['audience'] ) : '',
				'category'       => isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0,
				'tags'           => isset( $_POST['tags'] ) ? wp_unslash( $_POST['tags'] ) : '',
				'priority'       => isset( $_POST['priority'] ) ? (int) $_POST['priority'] : 0,
				'scheduled_date' => isset( $_POST['scheduled_date'] ) ? wp_unslash( $_POST['scheduled_date'] ) : '',
				'notes'          => isset( $_POST['notes'] ) ? wp_unslash( $_POST['notes'] ) : '',
				'source'         => 'manual',
				'status'         => 'pending',
			);
			$result = 'edit' === $do ? AIBW_Topics::update( $id, $data ) : AIBW_Topics::insert( $data );
			self::back( 'aibw-topics', is_wp_error( $result ) ? 'error' : 'topic' );
		}
		if ( 'import' === $do ) {
			$text = isset( $_POST['bulk'] ) ? sanitize_textarea_field( wp_unslash( $_POST['bulk'] ) ) : '';
			if ( ! empty( $_FILES['csv']['tmp_name'] ) && is_uploaded_file( $_FILES['csv']['tmp_name'] ) ) {
				$raw = file_get_contents( $_FILES['csv']['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				if ( is_string( $raw ) ) {
					$text .= "\n" . $raw;
				}
			}
			AIBW_Topics::import_lines( $text );
			self::back( 'aibw-topics', 'imported' );
		}
		if ( 'suggest' === $do ) {
			$ids = AIBW_Automation::suggest_topics( 5 );
			self::back( 'aibw-topics', is_wp_error( $ids ) ? 'error' : 'topic' );
		}
		if ( 'delete' === $do ) {
			AIBW_Topics::delete( $id );
			self::back( 'aibw-topics', 'topic' );
		}
		if ( in_array( $do, array( 'skip', 'retry', 'approve' ), true ) ) {
			$status = 'skip' === $do ? 'skipped' : ( 'approve' === $do ? 'pending' : 'pending' );
			AIBW_Topics::update( $id, array( 'status' => $status ) );
			self::back( 'aibw-topics', 'topic' );
		}
		self::back( 'aibw-topics', 'error' );
	}
}
