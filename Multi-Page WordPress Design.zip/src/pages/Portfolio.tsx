import { useState } from "react";
type NavFn = (page: any) => void;

const filters = ["All", "B2B", "E-commerce", "SaaS", "Professional Services"];

const projects = [
  {
    title: "Apex Consulting",
    category: "B2B",
    result: "+312% qualified leads",
    desc: "Complete rebrand and WordPress rebuild for a 40-person management consultancy. Repositioned them from commodity to premium.",
    img: "photo-1467232004584-a241de8bcf5d",
    color: "#1A1A2E",
  },
  {
    title: "LuxWear Shop",
    category: "E-commerce",
    result: "$200k new MRR",
    desc: "WooCommerce store with custom checkout flow, size finder tool, and abandoned cart sequences. Conversion rate up 4.2×.",
    img: "photo-1556742049-0cfed4f6a45d",
    color: "#1A1A1A",
  },
  {
    title: "TradeFlow",
    category: "SaaS",
    result: "2.8s → 0.9s load",
    desc: "Performance overhaul and conversion redesign for a fintech SaaS. Trial signups increased 87% post-launch.",
    img: "photo-1460925895917-afdab827c52f",
    color: "#0D1A1A",
  },
  {
    title: "Nova Health",
    category: "Professional Services",
    result: "-40% bounce rate",
    desc: "Multi-location healthcare provider. New site architecture, local SEO, and patient conversion funnels.",
    img: "photo-1581056771107-24ca5f033842",
    color: "#1A0D0D",
  },
  {
    title: "Meridian Law",
    category: "Professional Services",
    result: "3× consultation bookings",
    desc: "Positioning overhaul and WordPress build for a boutique litigation firm competing against BigLaw.",
    img: "photo-1521791136064-7986c2920216",
    color: "#0D1A0D",
  },
  {
    title: "Flux Analytics",
    category: "SaaS",
    result: "+68% demo requests",
    desc: "Product marketing site with interactive demo, ROI calculator, and segmented messaging by buyer persona.",
    img: "photo-1551288049-bebda4e38f71",
    color: "#1A1A0D",
  },
];

export default function PortfolioPage({ navigate }: { navigate: NavFn }) {
  const [filter, setFilter] = useState("All");
  const filtered = filter === "All" ? projects : projects.filter(p => p.category === filter);

  return (
    <div>
      {/* HERO */}
      <section style={{ padding: "6rem 2rem 4rem", maxWidth: 1280, margin: "0 auto" }}>
        <div className="section-label" style={{ marginBottom: "1.5rem" }}>Our Work</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: "2rem" }}>
          <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 5vw, 5rem)", fontWeight: 900, lineHeight: 1.05, letterSpacing: "-0.02em" }}>
            Work that<br />
            <em style={{ color: "#FF5500", fontStyle: "italic" }}>delivers.</em>
          </h1>
          <p style={{ color: "#777", maxWidth: 380, fontSize: "0.95rem", lineHeight: 1.8 }}>
            Every project here has a measurable outcome attached. We don't show pretty screenshots — we show results.
          </p>
        </div>
      </section>

      {/* FILTERS */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem 3rem" }}>
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
          {filters.map((f) => (
            <button key={f} onClick={() => setFilter(f)} style={{
              fontFamily: "'Outfit', sans-serif", fontSize: "0.75rem", fontWeight: 700,
              letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.55rem 1.2rem",
              border: "1px solid", cursor: "pointer", transition: "all 0.2s",
              background: filter === f ? "#FF5500" : "transparent",
              color: filter === f ? "#080808" : "#555",
              borderColor: filter === f ? "#FF5500" : "#2A2A2A",
            }}>
              {f}
            </button>
          ))}
        </div>
      </section>

      {/* GRID */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem 7rem" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: "1.5rem" }}>
          {filtered.map((p, i) => (
            <div key={i} className="card-hover" style={{ overflow: "hidden", background: p.color, cursor: "pointer" }}>
              <div style={{ position: "relative", aspectRatio: "16/10", overflow: "hidden", background: "#111" }}>
                <img
                  src={`https://images.unsplash.com/${p.img}?w=700&h=440&fit=crop&auto=format`}
                  alt={p.title + " website"}
                  style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.65, transition: "transform 0.4s, opacity 0.3s" }}
                  onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.04)"; e.currentTarget.style.opacity = "0.8"; }}
                  onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.opacity = "0.65"; }}
                />
                <div style={{ position: "absolute", top: "1rem", left: "1rem", background: "#FF5500", padding: "0.3rem 0.8rem", fontSize: "0.68rem", fontWeight: 700, color: "#080808", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                  {p.result}
                </div>
              </div>
              <div style={{ padding: "1.8rem" }}>
                <div style={{ fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.12em", color: "#FF5500", textTransform: "uppercase", marginBottom: "0.6rem" }}>{p.category}</div>
                <h3 className="font-display" style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "0.8rem" }}>{p.title}</h3>
                <p style={{ color: "#666", fontSize: "0.85rem", lineHeight: 1.75 }}>{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* RESULTS STRIP */}
      <section style={{ background: "#111", padding: "5rem 2rem", borderTop: "1px solid #1A1A1A", borderBottom: "1px solid #1A1A1A" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          <div className="section-label" style={{ marginBottom: "1rem", textAlign: "center" }}>Collective Impact</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "3rem", marginTop: "2rem" }}>
            {[
              { val: "340+", label: "Sites Launched" },
              { val: "4.8×", label: "Avg. Conversion Lift" },
              { val: "95+", label: "Avg PageSpeed Score" },
              { val: "$12M+", label: "Revenue Attributed" },
            ].map((s, i) => (
              <div key={i} style={{ textAlign: "center" }}>
                <div className="font-display" style={{ fontSize: "3rem", fontWeight: 900, color: "#FF5500", lineHeight: 1 }}>{s.val}</div>
                <div style={{ fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.12em", color: "#555", textTransform: "uppercase", marginTop: "0.6rem" }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "7rem 2rem", textAlign: "center" }}>
        <div style={{ maxWidth: 600, margin: "0 auto" }}>
          <h2 className="font-display" style={{ fontSize: "clamp(2rem, 4vw, 3.2rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "1.5rem" }}>
            Your project could be next.
          </h2>
          <p style={{ color: "#666", marginBottom: "2.5rem", lineHeight: 1.8 }}>We take on 4–6 new projects per quarter. Spots fill fast.</p>
          <button className="btn-primary" onClick={() => navigate("Contact")}>Check Availability →</button>
        </div>
      </section>
    </div>
  );
}
