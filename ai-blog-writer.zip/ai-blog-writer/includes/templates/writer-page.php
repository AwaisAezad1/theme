<?php
/**
 * "Write a Blog" page.
 *
 * Variables: $settings, $providers, $ready, $selected, $categories, $can_publish, $static_front
 */
defined( 'ABSPATH' ) || exit;
?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'AI Blog Writer', 'ai-blog-writer' ); ?></h1>
	<p class="aibw-lead"><?php esc_html_e( 'Type a topic, choose an AI, and get a finished blog post you can add to your front page in one click.', 'ai-blog-writer' ); ?></p>

	<?php if ( empty( $ready ) ) : ?>
		<div class="aibw-card aibw-setup">
			<h2><?php esc_html_e( 'First, connect an AI', 'ai-blog-writer' ); ?></h2>
			<p><?php esc_html_e( 'No AI is connected yet. The quickest way to start is the free Groq account - it takes about two minutes and needs no credit card.', 'ai-blog-writer' ); ?></p>
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
				<p><a class="button button-primary button-hero" href="<?php echo esc_url( admin_url( 'admin.php?page=aibw-accounts' ) ); ?>"><?php esc_html_e( 'Connect an AI', 'ai-blog-writer' ); ?></a></p>
			<?php else : ?>
				<p><?php esc_html_e( 'Ask a site administrator to connect an AI on the AI Accounts page.', 'ai-blog-writer' ); ?></p>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<div id="aibw-form" class="aibw-card">
		<h2><span class="aibw-step">1</span> <?php esc_html_e( 'What should the blog be about?', 'ai-blog-writer' ); ?></h2>
		<textarea id="aibw-topic" rows="3" maxlength="500" placeholder="<?php esc_attr_e( 'e.g. 10 easy ways to save money on groceries', 'ai-blog-writer' ); ?>"></textarea>
		<p class="description"><?php esc_html_e( 'The AI will write a blog about exactly what you type here.', 'ai-blog-writer' ); ?></p>

		<h2><span class="aibw-step">2</span> <?php esc_html_e( 'Choose your AI', 'ai-blog-writer' ); ?></h2>
		<div class="aibw-providers">
			<?php
			foreach ( $providers as $wrp_id => $p ) :
				$is_ready = in_array( $wrp_id, $ready, true );
				?>
				<label class="aibw-provider<?php echo $wrp_id === $selected && $is_ready ? ' is-selected' : ''; ?><?php echo $is_ready ? '' : ' is-disabled'; ?>">
					<input type="radio" name="aibw_provider" value="<?php echo esc_attr( $wrp_id ); ?>" <?php checked( $wrp_id === $selected && $is_ready ); ?> <?php disabled( ! $is_ready ); ?>>
					<span class="aibw-provider-name"><?php echo esc_html( $p['label'] ); ?></span>
					<span class="aibw-provider-blurb"><?php echo esc_html( $p['blurb'] ); ?></span>
					<?php if ( $is_ready ) : ?>
						<span class="aibw-badge aibw-badge-ok"><?php esc_html_e( 'Ready', 'ai-blog-writer' ); ?></span>
					<?php elseif ( current_user_can( 'manage_options' ) ) : ?>
						<a class="aibw-badge aibw-badge-off" href="<?php echo esc_url( admin_url( 'admin.php?page=aibw-accounts' ) ); ?>"><?php esc_html_e( 'Not connected - set up', 'ai-blog-writer' ); ?></a>
					<?php else : ?>
						<span class="aibw-badge aibw-badge-off"><?php esc_html_e( 'Not connected', 'ai-blog-writer' ); ?></span>
					<?php endif; ?>
				</label>
			<?php endforeach; ?>
		</div>

		<details class="aibw-more">
			<summary><?php esc_html_e( 'More options (tone, length, language)', 'ai-blog-writer' ); ?></summary>
			<div class="aibw-grid">
				<p>
					<label for="aibw-tone"><?php esc_html_e( 'Tone', 'ai-blog-writer' ); ?></label>
					<select id="aibw-tone">
						<?php foreach ( AIBW_Generator::tones() as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['tone'], $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<p>
					<label for="aibw-length"><?php esc_html_e( 'Length', 'ai-blog-writer' ); ?></label>
					<select id="aibw-length">
						<?php foreach ( AIBW_Generator::lengths() as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['length'], $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<p>
					<label for="aibw-language"><?php esc_html_e( 'Language', 'ai-blog-writer' ); ?></label>
					<input type="text" id="aibw-language" value="<?php echo esc_attr( $settings['language'] ); ?>">
				</p>
			</div>
			<p>
				<label for="aibw-notes"><?php esc_html_e( 'Anything else the AI should know? (optional)', 'ai-blog-writer' ); ?></label>
				<textarea id="aibw-notes" rows="2" maxlength="500" placeholder="<?php esc_attr_e( 'e.g. Mention our free shipping offer. Keep paragraphs short.', 'ai-blog-writer' ); ?>"></textarea>
			</p>
		</details>

		<p class="aibw-actions">
			<button type="button" id="aibw-generate" class="button button-primary button-hero" <?php disabled( empty( $ready ) ); ?>><?php esc_html_e( 'Generate Blog', 'ai-blog-writer' ); ?></button>
			<span class="spinner" id="aibw-spinner"></span>
			<span id="aibw-status" class="aibw-status" role="status" aria-live="polite"></span>
		</p>
	</div>

	<div id="aibw-result" class="aibw-card" hidden>
		<h2><span class="aibw-step">3</span> <?php esc_html_e( 'Review and add to your site', 'ai-blog-writer' ); ?></h2>
		<div id="aibw-notice" class="notice notice-warning inline" hidden><p></p></div>
		<p class="aibw-by"><?php esc_html_e( 'Written by', 'ai-blog-writer' ); ?> <strong id="aibw-by-name"></strong>. <?php esc_html_e( 'You can edit the title and text below before adding it.', 'ai-blog-writer' ); ?></p>

		<label for="aibw-title" class="screen-reader-text"><?php esc_html_e( 'Blog title', 'ai-blog-writer' ); ?></label>
		<input type="text" id="aibw-title" class="aibw-title">
		<div id="aibw-content" class="aibw-content" contenteditable="true" role="textbox" aria-multiline="true" aria-label="<?php esc_attr_e( 'Blog text', 'ai-blog-writer' ); ?>"></div>

		<div class="aibw-publish-opts">
			<?php if ( $can_publish ) : ?>
				<label><input type="checkbox" id="aibw-sticky" <?php checked( ! empty( $settings['sticky'] ) ); ?>> <?php esc_html_e( 'Keep it at the top of my front page', 'ai-blog-writer' ); ?></label>
			<?php endif; ?>
			<label>
				<?php esc_html_e( 'Category', 'ai-blog-writer' ); ?>
				<select id="aibw-category">
					<option value="0"><?php esc_html_e( 'Default', 'ai-blog-writer' ); ?></option>
					<?php foreach ( $categories as $wrp_cat ) : ?>
						<option value="<?php echo esc_attr( $wrp_cat->term_id ); ?>" <?php selected( (int) $settings['category'], (int) $wrp_cat->term_id ); ?>><?php echo esc_html( $wrp_cat->name ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
		</div>

		<?php if ( $static_front && $can_publish ) : ?>
			<p class="description aibw-warn"><?php esc_html_e( 'Heads-up: your front page is set to a fixed page, so new posts will not appear there automatically. After publishing, put the shortcode [aibw_latest_blogs] on that page (or switch Settings > Reading to "Your latest posts").', 'ai-blog-writer' ); ?></p>
		<?php endif; ?>

		<p class="aibw-actions">
			<?php if ( $can_publish ) : ?>
				<button type="button" id="aibw-publish" class="button button-primary button-hero"><?php esc_html_e( 'Add Blog to Front Page', 'ai-blog-writer' ); ?></button>
			<?php endif; ?>
			<button type="button" id="aibw-draft" class="button button-secondary button-hero"><?php esc_html_e( 'Save as Draft', 'ai-blog-writer' ); ?></button>
			<button type="button" id="aibw-regenerate" class="button-link"><?php esc_html_e( 'Not happy? Write it again', 'ai-blog-writer' ); ?></button>
			<span class="spinner" id="aibw-spinner2"></span>
			<span id="aibw-status2" class="aibw-status" role="status" aria-live="polite"></span>
		</p>
	</div>

	<div id="aibw-done" class="aibw-card aibw-done" hidden>
		<h2 id="aibw-done-msg"></h2>
		<p>
			<a id="aibw-done-view" class="button button-primary" href="#" target="_blank" rel="noopener"><?php esc_html_e( 'View blog', 'ai-blog-writer' ); ?></a>
			<a id="aibw-done-home" class="button" href="#" target="_blank" rel="noopener"><?php esc_html_e( 'View front page', 'ai-blog-writer' ); ?></a>
			<a id="aibw-done-edit" class="button" href="#"><?php esc_html_e( 'Edit in WordPress', 'ai-blog-writer' ); ?></a>
			<button type="button" id="aibw-another" class="button-link"><?php esc_html_e( 'Write another blog', 'ai-blog-writer' ); ?></button>
		</p>
	</div>
</div>
