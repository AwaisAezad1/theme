import { useState } from "react";
type NavFn = (page: any) => void;

const posts = [
  {
    category: "Conversion",
    title: "The 7 WordPress Mistakes That Are Silently Killing Your Conversions",
    excerpt: "Most WordPress sites are leaving 60–80% of potential conversions on the table. Here are the seven fixable issues we see on almost every audit.",
    author: "Jordan Reeves",
    date: "Sep 18, 2026",
    readTime: "8 min read",
    img: "photo-1467232004584-a241de8bcf5d",
    featured: true,
  },
  {
    category: "Performance",
    title: "How We Cut Load Time from 4.2s to 0.8s Without Changing Hosting",
    excerpt: "A technical teardown of our Core Web Vitals optimization process — the exact steps that got a WooCommerce client from failing to 97 on PageSpeed.",
    author: "Priya Nair",
    date: "Sep 5, 2026",
    readTime: "11 min read",
    img: "photo-1460925895917-afdab827c52f",
    featured: false,
  },
  {
    category: "SEO",
    title: "WordPress SEO in 2026: What's Changed and What Still Works",
    excerpt: "Google's algorithm has shifted dramatically this year. Here's our updated technical SEO checklist for WordPress sites that want to rank.",
    author: "Tom Eriksson",
    date: "Aug 22, 2026",
    readTime: "9 min read",
    img: "photo-1551288049-bebda4e38f71",
    featured: false,
  },
  {
    category: "Strategy",
    title: "Why Your Homepage Headline Is Your Most Expensive Problem",
    excerpt: "We analyzed 80 homepage headlines from our clients. The ones that changed made an average 2.4× lift in time-on-site. Here's the pattern.",
    author: "Camille Moreau",
    date: "Aug 10, 2026",
    readTime: "6 min read",
    img: "photo-1509395176047-4a66953fd231",
    featured: false,
  },
  {
    category: "E-commerce",
    title: "WooCommerce Checkout Optimization: The Complete 2026 Playbook",
    excerpt: "Checkout abandonment averages 70%. We've reduced it to under 40% on every store we've touched. Here's our exact playbook.",
    author: "Jordan Reeves",
    date: "Jul 28, 2026",
    readTime: "14 min read",
    img: "photo-1556742049-0cfed4f6a45d",
    featured: false,
  },
  {
    category: "Branding",
    title: "The Brand Architecture That Makes Premium Pricing Stick",
    excerpt: "Price anchoring, value hierarchy, social proof placement — the design decisions that let our clients charge 3–5× more than competitors.",
    author: "Camille Moreau",
    date: "Jul 12, 2026",
    readTime: "7 min read",
    img: "photo-1522071820081-009f0129c71c",
    featured: false,
  },
];

const categories = ["All", "Conversion", "Performance", "SEO", "Strategy", "E-commerce", "Branding"];

export default function BlogPage({ navigate }: { navigate: NavFn }) {
  const [cat, setCat] = useState("All");
  const featured = posts.find(p => p.featured);
  const rest = posts.filter(p => !p.featured);
  const filtered = cat === "All" ? rest : rest.filter(p => p.category === cat);

  return (
    <div>
      {/* HEADER */}
      <section style={{ padding: "6rem 2rem 4rem", maxWidth: 1280, margin: "0 auto" }}>
        <div className="section-label" style={{ marginBottom: "1.5rem" }}>Insights</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: "2rem" }}>
          <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 5vw, 5rem)", fontWeight: 900, lineHeight: 1.05, letterSpacing: "-0.02em" }}>
            The conversion<br />
            <em style={{ color: "#FF5500", fontStyle: "italic" }}>playbook.</em>
          </h1>
          <p style={{ color: "#777", maxWidth: 350, fontSize: "0.9rem", lineHeight: 1.8 }}>
            Tactics, teardowns, and strategy from the team that's built 340+ revenue-generating WordPress sites.
          </p>
        </div>
      </section>

      {/* FEATURED POST */}
      {featured && (
        <section style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem 4rem" }}>
          <div className="card-hover" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", overflow: "hidden", background: "#111", cursor: "pointer" }}>
            <div style={{ position: "relative", overflow: "hidden", minHeight: 420, background: "#0A0A0A" }}>
              <img
                src={`https://images.unsplash.com/${featured.img}?w=700&h=500&fit=crop&auto=format`}
                alt={featured.title}
                style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.65 }}
              />
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, transparent, rgba(17,17,17,0.6))" }} />
              <div style={{ position: "absolute", top: "1.5rem", left: "1.5rem", background: "#FF5500", padding: "0.3rem 0.8rem", fontSize: "0.68rem", fontWeight: 700, color: "#080808", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Featured
              </div>
            </div>
            <div style={{ padding: "4rem 3.5rem", display: "flex", flexDirection: "column", justifyContent: "center" }}>
              <div style={{ fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.12em", color: "#FF5500", textTransform: "uppercase", marginBottom: "1rem" }}>{featured.category}</div>
              <h2 className="font-display" style={{ fontSize: "1.6rem", fontWeight: 700, lineHeight: 1.3, letterSpacing: "-0.01em", marginBottom: "1.2rem" }}>{featured.title}</h2>
              <p style={{ color: "#777", fontSize: "0.9rem", lineHeight: 1.8, marginBottom: "2rem" }}>{featured.excerpt}</p>
              <div style={{ display: "flex", alignItems: "center", gap: "1.2rem", marginBottom: "2rem" }}>
                <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#CCC" }}>{featured.author}</span>
                <span style={{ color: "#333" }}>·</span>
                <span style={{ fontSize: "0.78rem", color: "#555" }}>{featured.date}</span>
                <span style={{ color: "#333" }}>·</span>
                <span style={{ fontSize: "0.78rem", color: "#555" }}>{featured.readTime}</span>
              </div>
              <span className="btn-primary" style={{ alignSelf: "flex-start", cursor: "pointer" }}>Read Article →</span>
            </div>
          </div>
          <style>{`@media (max-width: 900px) { section > div > div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; } }`}</style>
        </section>
      )}

      {/* FILTER + GRID */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem 7rem" }}>
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "3rem" }}>
          {categories.map((c) => (
            <button key={c} onClick={() => setCat(c)} style={{
              fontFamily: "'Outfit', sans-serif", fontSize: "0.72rem", fontWeight: 700,
              letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.5rem 1.1rem",
              border: "1px solid", cursor: "pointer", transition: "all 0.2s",
              background: cat === c ? "#FF5500" : "transparent",
              color: cat === c ? "#080808" : "#555",
              borderColor: cat === c ? "#FF5500" : "#2A2A2A",
            }}>
              {c}
            </button>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "2rem" }}>
          {filtered.map((p, i) => (
            <article key={i} className="card-hover" style={{ background: "#111", overflow: "hidden", cursor: "pointer" }}>
              <div style={{ position: "relative", aspectRatio: "16/9", overflow: "hidden", background: "#0A0A0A" }}>
                <img
                  src={`https://images.unsplash.com/${p.img}?w=600&h=340&fit=crop&auto=format`}
                  alt={p.title}
                  style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.6, transition: "transform 0.35s" }}
                  onMouseEnter={e => (e.currentTarget.style.transform = "scale(1.04)")}
                  onMouseLeave={e => (e.currentTarget.style.transform = "scale(1)")}
                />
              </div>
              <div style={{ padding: "1.8rem" }}>
                <div style={{ fontSize: "0.68rem", fontWeight: 700, letterSpacing: "0.12em", color: "#FF5500", textTransform: "uppercase", marginBottom: "0.7rem" }}>{p.category}</div>
                <h3 className="font-display" style={{ fontSize: "1.1rem", fontWeight: 700, lineHeight: 1.4, marginBottom: "0.8rem" }}>{p.title}</h3>
                <p style={{ color: "#666", fontSize: "0.83rem", lineHeight: 1.75, marginBottom: "1.5rem" }}>{p.excerpt}</p>
                <div style={{ display: "flex", alignItems: "center", gap: "0.8rem", paddingTop: "1rem", borderTop: "1px solid #1A1A1A" }}>
                  <span style={{ fontSize: "0.78rem", fontWeight: 600, color: "#AAA" }}>{p.author}</span>
                  <span style={{ color: "#2A2A2A" }}>·</span>
                  <span style={{ fontSize: "0.75rem", color: "#555" }}>{p.readTime}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* NEWSLETTER */}
      <section style={{ background: "#111", borderTop: "1px solid #1A1A1A", padding: "6rem 2rem" }}>
        <div style={{ maxWidth: 560, margin: "0 auto", textAlign: "center" }}>
          <div className="section-label" style={{ marginBottom: "1rem" }}>Newsletter</div>
          <h2 className="font-display" style={{ fontSize: "2rem", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "1rem" }}>
            One tactical insight.<br />Every two weeks.
          </h2>
          <p style={{ color: "#666", fontSize: "0.9rem", lineHeight: 1.8, marginBottom: "2rem" }}>
            No fluff. Just actionable WordPress and conversion strategies from the Vantage team. 4,200+ readers.
          </p>
          <div style={{ display: "flex", gap: "0", maxWidth: 420, margin: "0 auto" }}>
            <input
              type="email"
              placeholder="your@email.com"
              style={{
                flex: 1, padding: "0.85rem 1.2rem",
                background: "#0A0A0A", border: "1px solid #2A2A2A", borderRight: "none",
                color: "#F4EFE6", fontFamily: "'Outfit', sans-serif", fontSize: "0.9rem", outline: "none",
              }}
            />
            <button className="btn-primary" style={{ whiteSpace: "nowrap" }}>Subscribe</button>
          </div>
          <p style={{ fontSize: "0.72rem", color: "#444", marginTop: "1rem" }}>No spam. Unsubscribe anytime.</p>
        </div>
      </section>
    </div>
  );
}
