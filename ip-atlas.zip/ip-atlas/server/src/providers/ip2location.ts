import { IP2Location } from 'ip2location-nodejs';
import {
  emptyRecord,
  hasData,
  type GeoProvider,
  type GeoRecord,
  type ProviderInfo,
  type ProviderResult,
} from './types.js';
import { PROBE_IPS, countryName, fileSignature, latitude, longitude, text } from './util.js';

type Logger = { info: (m: string) => void; warn: (m: string) => void; error: (m: string) => void };

/** Subset of the IP2Location library we rely on (lets tests inject a stub). */
export interface Ip2LocationLike {
  open(path: string): void;
  close(): number;
  getAll(ip: string): Record<string, unknown>;
  getPackageVersion(): number;
  getDatabaseVersion(): string;
}

/** Placeholder strings the IP2Location library returns instead of data. */
const PLACEHOLDER = /^(-|n\/a|invalid_ip_address|ipv6_not_supported|missing_file)$|not applicable|please upgrade|incorrect ip2location/i;

function field(value: unknown): string | null {
  const t = text(value);
  return t && !PLACEHOLDER.test(t) ? t : null;
}

export function normalizeIp2Location(raw: Record<string, unknown>): GeoRecord {
  const out = emptyRecord();
  const code = field(raw.countryShort)?.toUpperCase() ?? null;
  out.country_code = code && /^[A-Z]{2}$/.test(code) ? code : null;
  // Prefer the short English name so all providers read consistently (IP2Location uses long official names).
  out.country = countryName(out.country_code) ?? field(raw.countryLong);
  out.region = field(raw.region);
  out.city = field(raw.city);
  out.postal_code = field(raw.zipCode);

  let lat = latitude(field(raw.latitude));
  let lon = longitude(field(raw.longitude));
  // Country-only editions report 0,0 for every row: treat as "no coordinates".
  if (lat === null || lon === null || (lat === 0 && lon === 0)) {
    lat = null;
    lon = null;
  }
  out.latitude = lat;
  out.longitude = lon;

  const tz = field(raw.timeZone);
  if (tz && /^[+-]\d{2}:\d{2}$/.test(tz)) out.utc_offset = tz;
  else if (tz && /^[A-Za-z_]+\/[A-Za-z_\-/+0-9]+$/.test(tz)) out.timezone = tz;

  out.isp = field(raw.isp);
  out.domain = field(raw.domain);
  const asn = field(raw.asn);
  out.asn = asn && /^\d{1,10}$/.test(asn) ? Number(asn) : null;
  out.organization = field(raw.as);
  return out;
}

/** "2026.10.1" -> "2026-10-01" */
export function ip2locationDate(version: string): string | null {
  const m = /^(\d{4})\.(\d{1,2})\.(\d{1,2})$/.exec(version.trim());
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  if (y < 2000 || mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

export class Ip2LocationProvider implements GeoProvider {
  readonly id = 'ip2location' as const;
  readonly name = 'IP2Location';
  private db: Ip2LocationLike | null = null;
  private signature: string | null = null;
  private warning: string | null = null;

  constructor(
    private binPath: string,
    private log: Logger,
    private factory: () => Ip2LocationLike = () => new IP2Location() as unknown as Ip2LocationLike,
  ) {}

  private async open(): Promise<boolean> {
    const signature = await fileSignature(this.binPath);
    if (signature === null || signature === this.signature) return false;
    let next: Ip2LocationLike | null = null;
    try {
      next = this.factory();
      next.open(this.binPath);
      if (!(next.getPackageVersion() > 0)) {
        throw new Error('not a valid IP2Location BIN file');
      }
    } catch (err) {
      try {
        next?.close();
      } catch {
        /* ignore */
      }
      this.log.error(`IP2Location database could not be opened: ${err instanceof Error ? err.message : err}`);
      return false;
    }
    const previous = this.db;
    this.db = next;
    this.signature = signature;
    try {
      previous?.close();
    } catch {
      /* ignore */
    }
    this.log.info(`IP2Location database loaded (${this.binPath})`);
    return true;
  }

  async init(): Promise<void> {
    await this.open();
    this.selfTest();
  }

  async reloadIfChanged(): Promise<boolean> {
    const changed = await this.open();
    if (changed) this.selfTest();
    return changed;
  }

  private selfTest(): void {
    this.warning = null;
    if (!this.db) return;
    const resolved = PROBE_IPS.some((ip) => {
      try {
        return normalizeIp2Location(this.db!.getAll(ip)).country_code !== null;
      } catch {
        return false;
      }
    });
    if (!resolved) {
      this.warning =
        'The IP2Location file loaded but could not resolve common test addresses. Make sure it is a current LITE BIN file (DB11 IPv6 recommended).';
      this.log.warn(`IP2Location: ${this.warning}`);
    }
  }

  async lookup(ip: string): Promise<ProviderResult> {
    if (!this.db) {
      return { status: 'unavailable', data: null, message: 'IP2Location database is not installed.' };
    }
    try {
      const record = normalizeIp2Location(this.db.getAll(ip));
      return hasData(record) ? { status: 'ok', data: record } : { status: 'no_data', data: null };
    } catch (err) {
      return { status: 'error', data: null, message: err instanceof Error ? err.message : 'Lookup failed.' };
    }
  }

  info(): ProviderInfo {
    let date: string | null = null;
    try {
      date = this.db ? ip2locationDate(this.db.getDatabaseVersion()) : null;
    } catch {
      date = null;
    }
    return {
      id: this.id,
      name: this.name,
      source: this.db ? 'IP2Location LITE (local database)' : 'IP2Location LITE (not installed)',
      loaded: this.db !== null,
      database_date: date,
      note: null,
      warning: this.warning,
    };
  }

  close(): void {
    try {
      this.db?.close();
    } catch {
      /* ignore */
    }
    this.db = null;
  }
}
