<?php
/**
 * Shop / product category / product tag archive.
 *
 * Override of woocommerce/templates/archive-product.php
 *
 * @package WooCommerce\Templates
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

do_action( 'woocommerce_before_main_content' );

// Category chips: children of the current category, else top-level categories.
$marina_current = is_product_category() ? get_queried_object() : null;
$marina_chips   = get_terms(
    array(
        'taxonomy'   => 'product_cat',
        'hide_empty' => true,
        'parent'     => $marina_current ? $marina_current->term_id : 0,
        'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
        'orderby'    => 'count',
        'order'      => 'DESC',
        'number'     => 8,
    )
);

if ( $marina_current && ( ! $marina_chips || is_wp_error( $marina_chips ) ) ) {
    // Leaf category: show its siblings.
    $marina_chips = get_terms(
        array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => true,
            'parent'     => $marina_current->parent,
            'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
            'number'     => 8,
        )
    );
}

$marina_description = '';
if ( is_product_taxonomy() ) {
    $marina_description = term_description();
} elseif ( is_shop() ) {
    $marina_shop_page   = get_post( wc_get_page_id( 'shop' ) );
    $marina_description = $marina_shop_page ? $marina_shop_page->post_content : '';
}

$marina_eyebrow = is_search() ? __( 'Search', 'marina-clothing' ) : ( $marina_current ? __( 'Collection', 'marina-clothing' ) : __( 'Curation', 'marina-clothing' ) );
?>

<header class="page-hero page-hero--shop">
    <div class="container">
        <?php woocommerce_breadcrumb(); ?>
        <span class="eyebrow"><?php echo esc_html( $marina_eyebrow ); ?></span>
        <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
            <h1 class="page-hero__title woocommerce-products-header__title"><?php woocommerce_page_title(); ?></h1>
        <?php endif; ?>
        <?php if ( $marina_description ) : ?>
            <div class="page-hero__desc"><?php echo wp_kses_post( wpautop( $marina_description ) ); ?></div>
        <?php endif; ?>

        <?php if ( $marina_chips && ! is_wp_error( $marina_chips ) ) : ?>
            <nav class="chip-row chip-row--scroll" aria-label="<?php esc_attr_e( 'Product categories', 'marina-clothing' ); ?>">
                <a class="chip<?php echo ( is_shop() && ! is_search() ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"<?php echo is_shop() ? ' aria-current="page"' : ''; ?>><?php esc_html_e( 'All Pieces', 'marina-clothing' ); ?></a>
                <?php foreach ( $marina_chips as $marina_chip ) : ?>
                    <?php $marina_active = $marina_current && $marina_current->term_id === $marina_chip->term_id; ?>
                    <a class="chip<?php echo $marina_active ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_term_link( $marina_chip ) ); ?>"<?php echo $marina_active ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $marina_chip->name ); ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
    </div>
</header>

<section class="section section--shop">
    <div class="container">
        <?php
        if ( woocommerce_product_loop() ) {
            do_action( 'woocommerce_before_shop_loop' );

            woocommerce_product_loop_start();

            if ( wc_get_loop_prop( 'total' ) ) {
                while ( have_posts() ) {
                    the_post();
                    do_action( 'woocommerce_shop_loop' );
                    wc_get_template_part( 'content', 'product' );
                }
            }

            woocommerce_product_loop_end();

            do_action( 'woocommerce_after_shop_loop' );
        } else {
            do_action( 'woocommerce_no_products_found' );
        }
        ?>
    </div>
</section>

<?php
do_action( 'woocommerce_after_main_content' );

get_footer( 'shop' );
