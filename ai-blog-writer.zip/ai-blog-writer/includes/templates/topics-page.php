<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap aibw-wrap">
	<h1><?php esc_html_e( 'Topic Queue', 'ai-blog-writer' ); ?></h1>
	<?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
	<div class="aibw-card">
		<h2><?php echo $edit ? esc_html__( 'Edit topic', 'ai-blog-writer' ) : esc_html__( 'Add a topic', 'ai-blog-writer' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'aibw_topic_action' ); ?>
			<input type="hidden" name="action" value="aibw_topic_action" />
			<input type="hidden" name="do" value="<?php echo $edit ? 'edit' : 'add'; ?>" />
			<?php if ( $edit ) : ?><input type="hidden" name="topic_id" value="<?php echo (int) $edit->id; ?>" /><?php endif; ?>
			<p><label><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?><br><input class="large-text" name="title" required value="<?php echo esc_attr( $edit ? $edit->title : '' ); ?>" /></label></p>
			<p><label><?php esc_html_e( 'Keyword', 'ai-blog-writer' ); ?> <input name="keyword" value="<?php echo esc_attr( $edit ? $edit->keyword : '' ); ?>" /></label>
			<label><?php esc_html_e( 'Audience', 'ai-blog-writer' ); ?> <input name="audience" value="<?php echo esc_attr( $edit ? $edit->audience : '' ); ?>" /></label></p>
			<p><label><?php esc_html_e( 'Category', 'ai-blog-writer' ); ?>
				<select name="category"><option value="0"><?php esc_html_e( 'Default', 'ai-blog-writer' ); ?></option>
					<?php foreach ( $categories as $cat ) : ?><option value="<?php echo (int) $cat->term_id; ?>" <?php selected( $edit && (int) $edit->category === (int) $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option><?php endforeach; ?>
				</select></label>
			<label><?php esc_html_e( 'Tags', 'ai-blog-writer' ); ?> <input name="tags" value="<?php echo esc_attr( $edit ? $edit->tags : '' ); ?>" /></label>
			<label><?php esc_html_e( 'Priority', 'ai-blog-writer' ); ?> <input type="number" name="priority" value="<?php echo $edit ? (int) $edit->priority : 0; ?>" /></label>
			<label><?php esc_html_e( 'Date', 'ai-blog-writer' ); ?> <input type="date" name="scheduled_date" value="<?php echo esc_attr( $edit && $edit->scheduled_date ? $edit->scheduled_date : '' ); ?>" /></label></p>
			<p><button class="button button-primary"><?php esc_html_e( 'Save topic', 'ai-blog-writer' ); ?></button></p>
		</form>
		<h2><?php esc_html_e( 'Bulk import', 'ai-blog-writer' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
			<?php wp_nonce_field( 'aibw_topic_action' ); ?>
			<input type="hidden" name="action" value="aibw_topic_action" />
			<input type="hidden" name="do" value="import" />
			<p><textarea name="bulk" rows="5" class="large-text" placeholder="<?php esc_attr_e( 'One topic per line. Optional CSV: topic, keyword, audience', 'ai-blog-writer' ); ?>"></textarea></p>
			<p><input type="file" name="csv" accept=".csv,text/csv,text/plain" /></p>
			<p><button class="button"><?php esc_html_e( 'Import', 'ai-blog-writer' ); ?></button></p>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'aibw_topic_action' ); ?>
			<input type="hidden" name="action" value="aibw_topic_action" />
			<button class="button" name="do" value="suggest"><?php esc_html_e( 'Suggest topics with AI', 'ai-blog-writer' ); ?></button>
			<p class="description"><?php esc_html_e( 'Suggestions stay out of the active queue until you approve them.', 'ai-blog-writer' ); ?></p>
		</form>
	</div>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Topic', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Status', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Keyword', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Date', 'ai-blog-writer' ); ?></th><th><?php esc_html_e( 'Note', 'ai-blog-writer' ); ?></th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $topics ) : ?><tr><td colspan="6"><?php esc_html_e( 'The queue is empty.', 'ai-blog-writer' ); ?></td></tr><?php endif; ?>
		<?php foreach ( $topics as $topic ) : ?>
			<tr>
				<td><?php echo esc_html( $topic->title ); ?></td>
				<td><?php echo esc_html( $topic->status ); ?></td>
				<td><?php echo esc_html( $topic->keyword ); ?></td>
				<td><?php echo esc_html( (string) $topic->scheduled_date ); ?></td>
				<td><?php echo esc_html( (string) $topic->similarity_note ); ?></td>
				<td>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=aibw-topics&topic=' . (int) $topic->id ) ); ?>"><?php esc_html_e( 'Edit', 'ai-blog-writer' ); ?></a>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<?php wp_nonce_field( 'aibw_topic_action' ); ?>
						<input type="hidden" name="action" value="aibw_topic_action" />
						<input type="hidden" name="topic_id" value="<?php echo (int) $topic->id; ?>" />
						<?php if ( 'suggested' === $topic->status ) : ?><button class="button-link" name="do" value="approve"><?php esc_html_e( 'Approve', 'ai-blog-writer' ); ?></button><?php endif; ?>
						<?php if ( in_array( $topic->status, array( 'failed', 'skipped' ), true ) ) : ?><button class="button-link" name="do" value="retry"><?php esc_html_e( 'Retry', 'ai-blog-writer' ); ?></button><?php endif; ?>
						<button class="button-link" name="do" value="skip"><?php esc_html_e( 'Skip', 'ai-blog-writer' ); ?></button>
						<button class="button-link" name="do" value="delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this topic?', 'ai-blog-writer' ) ); ?>');"><?php esc_html_e( 'Delete', 'ai-blog-writer' ); ?></button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
