<?php
/**
 * Reusable template tags.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Brand mark: custom logo or the site title set in the wordmark style.
 */
function marina_brand( $context = 'header' ) {
    if ( has_custom_logo() ) {
        the_custom_logo();
        return;
    }

    $tag = 'p';

    printf(
        '<%1$s class="brand__name"><a href="%2$s" rel="home">%3$s</a></%1$s>',
        esc_html( $tag ),
        esc_url( home_url( '/' ) ),
        esc_html( get_bloginfo( 'name' ) )
    );
}

/**
 * Fallback for the primary menu: shop link + top product categories,
 * or pages when WooCommerce isn't active.
 */
function marina_primary_menu_fallback( $args = array() ) {
    $items = array();

    if ( marina_is_woocommerce_active() ) {
        $items[] = array(
            'url'     => wc_get_page_permalink( 'shop' ),
            'label'   => __( 'New Arrivals', 'marina-clothing' ),
            'current' => is_shop(),
        );

        foreach ( marina_get_featured_categories( 5 ) as $term ) {
            $items[] = array(
                'url'     => get_term_link( $term ),
                'label'   => $term->name,
                'current' => is_product_category( $term->term_id ),
            );
        }
    } else {
        foreach ( get_pages( array( 'number' => 6, 'sort_column' => 'menu_order' ) ) as $page ) {
            $items[] = array(
                'url'     => get_permalink( $page ),
                'label'   => $page->post_title,
                'current' => is_page( $page->ID ),
            );
        }
    }

    $class = isset( $args['menu_class'] ) ? $args['menu_class'] : 'menu';

    echo '<ul class="' . esc_attr( $class ) . '">';
    foreach ( $items as $item ) {
        printf(
            '<li class="menu-item%1$s"><a href="%2$s"%3$s>%4$s</a></li>',
            $item['current'] ? ' current-menu-item' : '',
            esc_url( $item['url'] ),
            $item['current'] ? ' aria-current="page"' : '',
            esc_html( $item['label'] )
        );
    }
    echo '</ul>';
}

/**
 * Name of the menu assigned to a location (used as footer column heading).
 */
function marina_menu_name( $location, $fallback ) {
    $locations = get_nav_menu_locations();

    if ( ! empty( $locations[ $location ] ) ) {
        $menu = wp_get_nav_menu_object( $locations[ $location ] );
        if ( $menu ) {
            return $menu->name;
        }
    }

    return $fallback;
}

/**
 * Footer column fallbacks.
 */
function marina_footer_collections_fallback() {
    marina_primary_menu_fallback( array( 'menu_class' => 'footer-links' ) );
}

function marina_footer_concierge_fallback() {
    $links = array();

    if ( marina_is_woocommerce_active() ) {
        $links[ wc_get_page_permalink( 'myaccount' ) ] = __( 'My Account', 'marina-clothing' );
        $links[ wc_get_cart_url() ]                    = __( 'Shopping Bag', 'marina-clothing' );
        $links[ wc_get_checkout_url() ]                = __( 'Checkout', 'marina-clothing' );
    }

    $privacy = get_privacy_policy_url();
    if ( $privacy ) {
        $links[ $privacy ] = __( 'Privacy Policy', 'marina-clothing' );
    }

    foreach ( get_pages( array( 'number' => 3, 'exclude' => marina_wc_page_ids() ) ) as $page ) {
        $links[ get_permalink( $page ) ] = $page->post_title;
    }

    echo '<ul class="footer-links">';
    foreach ( $links as $url => $label ) {
        printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( $url ), esc_html( $label ) );
    }
    echo '</ul>';
}

function marina_footer_legal_fallback() {
    $privacy = get_privacy_policy_url();

    if ( $privacy ) {
        printf(
            '<ul class="footer-legal"><li><a href="%1$s">%2$s</a></li></ul>',
            esc_url( $privacy ),
            esc_html__( 'Privacy Statement', 'marina-clothing' )
        );
    }
}

/**
 * IDs of WooCommerce system pages.
 */
function marina_wc_page_ids() {
    if ( ! marina_is_woocommerce_active() ) {
        return array();
    }

    return array_filter(
        array(
            wc_get_page_id( 'shop' ),
            wc_get_page_id( 'cart' ),
            wc_get_page_id( 'checkout' ),
            wc_get_page_id( 'myaccount' ),
        ),
        function ( $id ) {
            return $id > 0;
        }
    );
}

/**
 * Product categories worth showcasing: non-empty, not "Uncategorized",
 * most populated first.
 */
function marina_get_featured_categories( $limit = 5 ) {
    if ( ! taxonomy_exists( 'product_cat' ) ) {
        return array();
    }

    $terms = get_terms(
        array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => true,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
            'number'     => $limit,
        )
    );

    return is_wp_error( $terms ) ? array() : $terms;
}

/**
 * Editorial page header used on pages, archives, blog, search, shop.
 */
function marina_page_header( $title, $args = array() ) {
    $args = wp_parse_args(
        $args,
        array(
            'eyebrow'     => '',
            'description' => '',
            'breadcrumb'  => true,
            'compact'     => false,
            'tag'         => 'h1',
        )
    );
    ?>
    <header class="page-hero<?php echo $args['compact'] ? ' page-hero--compact' : ''; ?>">
        <div class="container">
            <?php if ( $args['breadcrumb'] ) : ?>
                <?php marina_breadcrumb(); ?>
            <?php endif; ?>

            <?php if ( $args['eyebrow'] ) : ?>
                <span class="eyebrow"><?php echo esc_html( $args['eyebrow'] ); ?></span>
            <?php endif; ?>

            <<?php echo esc_html( $args['tag'] ); ?> class="page-hero__title"><?php echo wp_kses_post( $title ); ?></<?php echo esc_html( $args['tag'] ); ?>>

            <?php if ( $args['description'] ) : ?>
                <div class="page-hero__desc"><?php echo wp_kses_post( wpautop( $args['description'] ) ); ?></div>
            <?php endif; ?>
        </div>
    </header>
    <?php
}

/**
 * Breadcrumbs: WooCommerce's when available, otherwise a simple trail.
 */
function marina_breadcrumb() {
    if ( function_exists( 'woocommerce_breadcrumb' ) ) {
        woocommerce_breadcrumb();
        return;
    }

    if ( is_front_page() ) {
        return;
    }

    echo '<nav class="woocommerce-breadcrumb" aria-label="' . esc_attr__( 'Breadcrumb', 'marina-clothing' ) . '">';
    echo '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'marina-clothing' ) . '</a><span class="sep">/</span>';
    echo '<span>' . esc_html( wp_strip_all_tags( is_singular() ? get_the_title() : get_the_archive_title() ) ) . '</span>';
    echo '</nav>';
}

/**
 * Post meta line: category • date • reading time.
 */
function marina_post_meta() {
    $cats    = get_the_category();
    $words   = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', get_the_ID() ) ) );
    $minutes = max( 1, (int) ceil( $words / 220 ) );

    echo '<div class="post-meta">';

    if ( $cats ) {
        printf(
            '<a class="post-meta__cat" href="%1$s">%2$s</a>',
            esc_url( get_category_link( $cats[0] ) ),
            esc_html( $cats[0]->name )
        );
    }

    printf(
        '<time datetime="%1$s">%2$s</time>',
        esc_attr( get_the_date( DATE_W3C ) ),
        esc_html( get_the_date() )
    );

    /* translators: %d: minutes */
    echo '<span>' . esc_html( sprintf( _n( '%d min read', '%d min read', $minutes, 'marina-clothing' ), $minutes ) ) . '</span>';

    echo '</div>';
}

/**
 * Numbered pagination in the theme style.
 */
function marina_pagination() {
    the_posts_pagination(
        array(
            'mid_size'  => 1,
            'prev_text' => marina_icon( 'chevron_left' ) . '<span class="screen-reader-text">' . esc_html__( 'Previous', 'marina-clothing' ) . '</span>',
            'next_text' => '<span class="screen-reader-text">' . esc_html__( 'Next', 'marina-clothing' ) . '</span>' . marina_icon( 'chevron_right' ),
        )
    );
}

/**
 * Newsletter form (header dispatch + home banner share this).
 */
function marina_newsletter_form( $variant = 'banner' ) {
    $id = 'nl-' . wp_unique_id();
    ?>
    <form class="newsletter-form newsletter-form--<?php echo esc_attr( $variant ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-newsletter>
        <input type="hidden" name="action" value="marina_newsletter">
        <?php wp_nonce_field( 'marina_nonce', 'nonce', false ); ?>
        <label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Email address', 'marina-clothing' ); ?></label>
        <div class="newsletter-form__field">
            <?php if ( 'banner' === $variant ) : ?>
                <?php marina_the_icon( 'mail' ); ?>
            <?php endif; ?>
            <input id="<?php echo esc_attr( $id ); ?>" type="email" name="email" required placeholder="<?php esc_attr_e( 'Enter your personal email', 'marina-clothing' ); ?>" autocomplete="email">
        </div>
        <button type="submit" class="btn <?php echo 'banner' === $variant ? 'btn--accent' : 'btn--primary btn--sm'; ?>">
            <span><?php esc_html_e( 'Subscribe', 'marina-clothing' ); ?></span>
            <?php if ( 'banner' === $variant ) : ?>
                <?php marina_the_icon( 'arrow_forward' ); ?>
            <?php endif; ?>
        </button>
        <p class="newsletter-form__status" role="status" aria-live="polite"></p>
    </form>
    <?php
}

/**
 * Custom comment markup.
 */
function marina_comment_callback( $comment, $args, $depth ) {
    $tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
    ?>
    <<?php echo esc_html( $tag ); ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( 'comment-card', $comment ); ?>>
        <article class="comment-card__body">
            <header class="comment-card__head">
                <?php echo get_avatar( $comment, 44, '', '', array( 'class' => 'comment-card__avatar' ) ); ?>
                <div>
                    <span class="comment-card__author"><?php comment_author_link( $comment ); ?></span>
                    <time class="comment-card__date" datetime="<?php comment_time( 'c' ); ?>"><?php comment_date( '', $comment ); ?></time>
                </div>
            </header>

            <?php if ( '0' === $comment->comment_approved ) : ?>
                <p class="comment-card__pending"><?php esc_html_e( 'Your comment is awaiting moderation.', 'marina-clothing' ); ?></p>
            <?php endif; ?>

            <div class="comment-content">
                <?php comment_text(); ?>
            </div>

            <footer class="comment-card__actions">
                <?php
                comment_reply_link(
                    array_merge(
                        $args,
                        array(
                            'depth'     => $depth,
                            'max_depth' => $args['max_depth'],
                        )
                    )
                );
                edit_comment_link( __( 'Edit', 'marina-clothing' ) );
                ?>
            </footer>
        </article>
    <?php
    // Closing tag is output by Walker_Comment::end_el().
}
