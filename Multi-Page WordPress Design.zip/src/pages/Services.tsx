import { useState } from "react";
type NavFn = (page: any) => void;

const services = [
  {
    id: "web-design",
    title: "WordPress Design & Development",
    price: "From $8,500",
    tag: "Most Popular",
    desc: "A custom WordPress site designed from the ground up around your audience and conversion goals. No page builders. No templates. Pure performance.",
    deliverables: ["Custom WordPress theme", "Mobile-first responsive build", "Core Web Vitals 95+ score", "CMS training & documentation", "3-month post-launch support"],
    img: "photo-1551434678-e076c223a692",
  },
  {
    id: "woocommerce",
    title: "WooCommerce Stores",
    price: "From $12,000",
    tag: "High ROI",
    desc: "Full e-commerce builds on WooCommerce with checkout optimization, abandoned cart recovery, and conversion-focused product pages.",
    deliverables: ["WooCommerce setup & customization", "Checkout funnel optimization", "Payment gateway integration", "Inventory & order management", "Email automation setup"],
    img: "photo-1556742049-0cfed4f6a45d",
  },
  {
    id: "seo",
    title: "SEO & Performance",
    price: "From $2,500/mo",
    tag: "Ongoing",
    desc: "Technical SEO, content strategy, and Core Web Vitals optimization. We don't just chase rankings — we build sustainable organic traffic that converts.",
    deliverables: ["Technical SEO audit & fixes", "Core Web Vitals optimization", "Monthly content strategy", "Backlink building", "Monthly performance reports"],
    img: "photo-1460925895917-afdab827c52f",
  },
  {
    id: "brand",
    title: "Brand & Visual Identity",
    price: "From $5,500",
    tag: "Foundation",
    desc: "Logo, color system, typography, brand guidelines, and messaging architecture. The visual language your WordPress site will be built on.",
    deliverables: ["Logo design (3 concepts)", "Color & typography system", "Brand guidelines document", "Messaging & positioning", "Social media kit"],
    img: "photo-1509395176047-4a66953fd231",
  },
];

const process = [
  { num: "01", title: "Discovery Call", desc: "60-minute deep dive into your goals, audience, and current gaps. No pitch, just understanding." },
  { num: "02", title: "Strategy & Proposal", desc: "We map out the exact approach, timeline, and investment. Full transparency, no surprises." },
  { num: "03", title: "Design Sprint", desc: "Wireframes and designs in Figma. You see every decision before a line of code is written." },
  { num: "04", title: "Build & QA", desc: "Development in a staging environment with rigorous testing across devices and browsers." },
  { num: "05", title: "Launch & Optimize", desc: "Smooth launch, then 90 days of monitoring and iteration to maximize performance." },
];

export default function ServicesPage({ navigate }: { navigate: NavFn }) {
  const [active, setActive] = useState(0);

  return (
    <div>
      {/* HERO */}
      <section style={{ padding: "6rem 2rem 5rem", maxWidth: 1280, margin: "0 auto" }}>
        <div className="section-label" style={{ marginBottom: "1.5rem" }}>Services & Pricing</div>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 5vw, 5rem)", fontWeight: 900, lineHeight: 1.05, letterSpacing: "-0.02em", maxWidth: 700, marginBottom: "2rem" }}>
          Everything you need.<br />
          <em style={{ color: "#FF5500", fontStyle: "italic" }}>Nothing you don't.</em>
        </h1>
        <p style={{ color: "#888", fontSize: "1rem", lineHeight: 1.9, maxWidth: 550 }}>
          We offer focused services built around WordPress and conversion. No bloated retainers, no padding — just the work that moves the needle.
        </p>
      </section>

      {/* SERVICE TABS */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem 7rem" }}>
        {/* Tab pills */}
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "3rem", borderBottom: "1px solid #1A1A1A", paddingBottom: "1.5rem" }}>
          {services.map((s, i) => (
            <button key={i} onClick={() => setActive(i)} style={{
              fontFamily: "'Outfit', sans-serif", fontSize: "0.78rem", fontWeight: 700,
              letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.6rem 1.4rem",
              border: "1px solid", cursor: "pointer", transition: "all 0.2s",
              background: active === i ? "#FF5500" : "transparent",
              color: active === i ? "#080808" : "#666",
              borderColor: active === i ? "#FF5500" : "#333",
            }}>
              {s.title.split(" ")[0]}
            </button>
          ))}
        </div>

        {/* Active panel */}
        {services.map((s, i) => i === active && (
          <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "start" }}>
            <div>
              {s.tag && (
                <div style={{ display: "inline-block", background: "#FF5500", color: "#080808", fontSize: "0.68rem", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", padding: "0.3rem 0.8rem", marginBottom: "1.5rem" }}>{s.tag}</div>
              )}
              <h2 className="font-display" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "1rem", lineHeight: 1.2 }}>{s.title}</h2>
              <div className="font-display" style={{ fontSize: "1.5rem", fontWeight: 600, color: "#FF5500", marginBottom: "1.5rem" }}>{s.price}</div>
              <p style={{ color: "#888", lineHeight: 1.9, marginBottom: "2.5rem", fontSize: "0.95rem" }}>{s.desc}</p>

              <div style={{ marginBottom: "2.5rem" }}>
                <div className="section-label" style={{ marginBottom: "1.2rem" }}>What's included</div>
                {s.deliverables.map((d, j) => (
                  <div key={j} style={{ display: "flex", alignItems: "center", gap: "0.8rem", padding: "0.8rem 0", borderBottom: "1px solid #1A1A1A" }}>
                    <span style={{ color: "#FF5500", fontSize: "0.8rem" }}>✓</span>
                    <span style={{ fontSize: "0.88rem", color: "#CCC" }}>{d}</span>
                  </div>
                ))}
              </div>

              <div style={{ display: "flex", gap: "1rem" }}>
                <button className="btn-primary" onClick={() => navigate("Contact")}>Get a Quote</button>
                <button className="btn-ghost" onClick={() => navigate("Portfolio")}>See Examples</button>
              </div>
            </div>

            <div>
              <div style={{ position: "relative", overflow: "hidden", background: "#111", aspectRatio: "4/3" }}>
                <img
                  src={`https://images.unsplash.com/${s.img}?w=700&h=530&fit=crop&auto=format`}
                  alt={s.title}
                  style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.7 }}
                />
                <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(255,85,0,0.15) 0%, transparent 60%)" }} />
              </div>
            </div>
          </div>
        ))}
        <style>{`@media (max-width: 900px) { section > div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; } }`}</style>
      </section>

      {/* PROCESS */}
      <section style={{ background: "#0D0D0D", padding: "7rem 2rem" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          <div className="section-label" style={{ marginBottom: "1rem" }}>Our Process</div>
          <h2 className="font-display" style={{ fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "4rem", maxWidth: 500 }}>
            No surprises. No delays. Just delivery.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1px", background: "#1A1A1A" }}>
            {process.map((p, i) => (
              <div key={i} style={{ background: "#0D0D0D", padding: "2.5rem 2rem" }}>
                <div style={{ fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.15em", color: "#FF5500", marginBottom: "1.5rem" }}>{p.num}</div>
                <h3 className="font-display" style={{ fontSize: "1.1rem", fontWeight: 700, marginBottom: "0.8rem" }}>{p.title}</h3>
                <p style={{ color: "#555", fontSize: "0.85rem", lineHeight: 1.8 }}>{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section style={{ maxWidth: 800, margin: "0 auto", padding: "7rem 2rem" }}>
        <div className="section-label" style={{ marginBottom: "1rem" }}>FAQ</div>
        <h2 className="font-display" style={{ fontSize: "clamp(2rem, 3vw, 2.5rem)", fontWeight: 700, letterSpacing: "-0.02em", marginBottom: "3rem" }}>Common questions.</h2>
        {[
          { q: "How long does a typical project take?", a: "WordPress sites typically take 6–10 weeks from kickoff to launch, depending on complexity. We'll give you a precise timeline in your proposal." },
          { q: "Do you work with existing WordPress sites?", a: "Yes. We offer full redesigns, performance overhauls, and conversion audits on existing WordPress installations." },
          { q: "What happens after launch?", a: "Every project includes 3 months of post-launch support. After that, we offer ongoing maintenance and growth retainers." },
          { q: "Do you offer payment plans?", a: "We structure projects in milestones — typically 40% upfront, 40% at design approval, and 20% at launch." },
        ].map((item, i) => (
          <div key={i} style={{ borderBottom: "1px solid #1A1A1A", padding: "2rem 0" }}>
            <div className="font-display" style={{ fontSize: "1.05rem", fontWeight: 700, marginBottom: "1rem" }}>{item.q}</div>
            <p style={{ color: "#777", fontSize: "0.9rem", lineHeight: 1.8 }}>{item.a}</p>
          </div>
        ))}
      </section>

      {/* CTA */}
      <section style={{ background: "#FF5500", padding: "6rem 2rem", textAlign: "center" }}>
        <h2 className="font-display" style={{ fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 900, color: "#080808", letterSpacing: "-0.02em", marginBottom: "1.5rem" }}>
          Let's scope your project.
        </h2>
        <p style={{ color: "rgba(0,0,0,0.65)", marginBottom: "2.5rem", fontSize: "1rem" }}>Free consultation. We'll tell you exactly what you need — and what you don't.</p>
        <button onClick={() => navigate("Contact")} style={{
          background: "#080808", color: "#F4EFE6", fontFamily: "'Outfit', sans-serif",
          fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", fontSize: "0.82rem",
          padding: "1rem 2.8rem", border: "none", cursor: "pointer",
        }}>Book a Free Call →</button>
      </section>
    </div>
  );
}
