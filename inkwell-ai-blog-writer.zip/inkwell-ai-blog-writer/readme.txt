=== Inkwell AI Blog Writer ===
Contributors: awaisaezad
Tags: ai, blog, content, writer, openai
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Type a topic, pick an AI (ChatGPT, Claude, Gemini, Perplexity or free Groq) and add the finished blog to your front page in one click.

== Description ==

1. Go to Inkwell AI Blog Writer > Write a Blog.
2. Type what the blog should be about.
3. Choose which AI writes it.
4. Press Generate Blog, read and edit the result, then press "Add Blog to Front Page" (or "Save as Draft").

Supported AIs: Groq (free), ChatGPT (OpenAI), Claude (Anthropic), Gemini (Google), Perplexity.

= Using your own or paid account =

On Inkwell AI Blog Writer > AI Accounts each AI has Sign up / Log in / Get API key buttons. Create or log in to your account, copy the API key and paste it in. Your plan, credits and limits then apply. AI companies do not allow websites to sign in with a normal chat login, so a key is the way to connect an account. Chat subscriptions (for example ChatGPT Plus or Claude Pro) are usually billed separately from API use.

= Front page =

"Add Blog to Front Page" publishes the post and makes it sticky, which keeps it at the top of your blog posts list. If your front page is a fixed page (Settings > Reading), add the shortcode [aibw_latest_blogs count="3"] to that page.

= Other features =

* Optional automatic fallback to the free AI if a paid AI fails.
* Tone, length, language and extra-instruction options.
* Model picker filled from your own account after "Test connection".
* History page with your AI blogs and an error log.

= External services =

When you press Generate Blog, the topic, your writing options and your API key are sent to the AI you selected. Nothing is sent to the plugin authors.

* Groq: https://groq.com/privacy-policy/
* OpenAI: https://openai.com/policies/privacy-policy
* Anthropic: https://www.anthropic.com/privacy
* Google: https://policies.google.com/privacy
* Perplexity: https://www.perplexity.ai/hub/legal/privacy-policy

= Security notes =

API keys are stored encrypted using your site's secret keys (WordPress salts). If you change the salts in wp-config.php, re-enter your keys. Always review AI text for accuracy before publishing.

== Changelog ==

= 1.0.0 =
* First release.
