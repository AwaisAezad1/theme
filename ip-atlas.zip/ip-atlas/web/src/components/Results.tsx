import { useEffect, useRef, useState } from 'react';
import type { LookupResponse, ProviderId, ProviderInfo, ProviderResult, Summary } from '../types';
import { PROVIDER_IDS } from '../types';
import {
  DASH,
  copyText,
  formatClock,
  formatCoordinates,
  formatDate,
  openStreetMapUrl,
  visibleRows,
} from '../lib/format';
import { Icon, type IconName } from './Icons';

const NAMES: Record<ProviderId, string> = { maxmind: 'MaxMind', ipinfo: 'IPinfo', ip2location: 'IP2Location' };

const STATUS_TEXT: Record<string, string> = {
  no_data: 'No record for this IP',
  unavailable: 'Database not installed',
  error: 'Lookup failed',
  skipped: 'Not requested',
};

export function ResultSkeleton() {
  return (
    <div className="result-panel p-6 sm:p-8" aria-busy="true" aria-label="Loading results">
      <div className="skeleton mb-5 h-3 w-28" />
      <div className="skeleton mb-4 h-10 w-64 max-w-full" />
      <div className="skeleton h-4 w-48 max-w-full" />
    </div>
  );
}

function CopyButton({ text, label }: { text: string; label: string }) {
  const [state, setState] = useState<'idle' | 'copied' | 'failed'>('idle');
  const timer = useRef<number | undefined>(undefined);
  useEffect(() => () => window.clearTimeout(timer.current), []);
  async function onClick() {
    const ok = await copyText(text);
    setState(ok ? 'copied' : 'failed');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setState('idle'), 1800);
  }
  return (
    <button type="button" onClick={onClick} className="button-secondary">
      <Icon name={state === 'copied' ? 'check' : 'copy'} className="h-4 w-4" />
      <span aria-live="polite">{state === 'copied' ? 'Copied' : state === 'failed' ? 'Copy failed' : label}</span>
    </button>
  );
}

function Field({ label, value, mono = false }: { label: string; value: string | null | undefined; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-5 border-b border-white/[0.06] py-3 last:border-0">
      <dt className="shrink-0 text-xs text-slate-500">{label}</dt>
      <dd className={`min-w-0 break-words text-right text-sm font-semibold text-slate-100 ${mono ? 'font-mono' : ''}`}>{value || DASH}</dd>
    </div>
  );
}

function Card({ icon, title, children }: { icon: IconName; title: string; children: React.ReactNode }) {
  return (
    <section className="data-card" aria-label={title}>
      <div className="mb-3 flex items-center gap-3 text-cyan-300">
        <Icon name={icon} />
        <h3 className="text-sm font-semibold text-white">{title}</h3>
      </div>
      <dl>{children}</dl>
    </section>
  );
}

function locationLine(s: Summary | null): string {
  if (!s) return '';
  return [s.city, s.region, s.country].filter(Boolean).join(', ');
}

function Overview({ data }: { data: LookupResponse }) {
  const s = data.summary!;
  const tz = s.timezone;
  const clock = formatClock(tz?.local_time);
  const sources = s.sources;
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card icon="pin" title="Location">
        <Field label="Country" value={s.country ? `${s.country}${s.country_code ? ` (${s.country_code})` : ''}` : s.country_code} />
        <Field label="Region" value={s.region} />
        <Field label="City" value={s.city} />
        <Field label="Postal code" value={s.postal_code} />
        <Field label="Coordinates" value={formatCoordinates(s.latitude, s.longitude)} mono />
      </Card>
      <Card icon="network" title="Network">
        <Field label="ASN" value={s.asn !== null ? `AS${s.asn}` : null} mono />
        <Field label="Organization" value={s.organization} />
        <Field label="IP version" value={`IPv${data.version}`} />
        <Field label="Address type" value={data.range} />
        <Field label="Continent" value={s.continent} />
      </Card>
      <Card icon="clock" title="Time & timezone">
        <Field label="Timezone" value={tz?.id} />
        <Field label="UTC offset" value={tz?.utc_offset ? `UTC${tz.utc_offset}` : null} mono />
        <Field label="Local time" value={clock} mono />
        <Field label="Local date" value={formatDate(tz?.local_time)} />
        <Field
          label="Data from"
          value={[sources.location, sources.network]
            .filter((v, i, a): v is ProviderId => v !== null && a.indexOf(v) === i)
            .map((id) => NAMES[id])
            .join(' + ') || null}
        />
      </Card>
    </div>
  );
}

function cellText(result: ProviderResult, get: (r: NonNullable<ProviderResult['data']>) => string | null): { text: string; muted: boolean } {
  if (result.status === 'ok' && result.data) {
    const v = get(result.data);
    return { text: v ?? DASH, muted: v === null };
  }
  return { text: STATUS_TEXT[result.status] ?? DASH, muted: true };
}

function ProviderHeader({ id, result, info }: { id: ProviderId; result: ProviderResult; info?: ProviderInfo }) {
  const ok = result.status === 'ok';
  return (
    <div>
      <div className="flex items-center gap-2 text-sm font-semibold text-white">
        <span className={`h-2 w-2 rounded-full ${ok ? 'bg-emerald-400' : 'bg-slate-600'}`} aria-hidden="true" />
        {NAMES[id]}
      </div>
      {info?.database_date && <div className="mt-0.5 text-[11px] font-normal text-slate-500">Data from {formatDate(info.database_date)}</div>}
    </div>
  );
}

function Comparison({ data, infos }: { data: LookupResponse; infos: ProviderInfo[] }) {
  const results = PROVIDER_IDS.map((id) => data.providers[id]);
  const rows = visibleRows(results);
  const infoOf = (id: ProviderId) => infos.find((i) => i.id === id);
  const notes = PROVIDER_IDS.map((id) => ({ id, note: infoOf(id)?.note })).filter((n) => n.note);
  const { matching, total } = data.summary?.country_agreement ?? { matching: 0, total: 0 };

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="section-label">Compare providers</p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white">What each database reports</h2>
        </div>
        {total > 1 && (
          <p className={`rounded-full border px-3 py-1 text-xs font-semibold ${matching === total ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-300' : 'border-amber-400/30 bg-amber-400/10 text-amber-300'}`}>
            {matching === total ? `All ${total} providers agree on the country` : `${matching} of ${total} providers agree on the country`}
          </p>
        )}
      </div>

      {/* Desktop / tablet: table */}
      <div className="hidden overflow-x-auto rounded-xl border border-white/[0.075] bg-[#0b1a29]/65 sm:block">
        <table className="w-full min-w-[640px] border-collapse text-left">
          <caption className="sr-only">Geolocation data for {data.ip} from MaxMind, IPinfo and IP2Location</caption>
          <thead>
            <tr className="border-b border-white/[0.08]">
              <th scope="col" className="w-[17%] px-5 py-4 text-xs font-medium text-slate-500">Field</th>
              {PROVIDER_IDS.map((id) => (
                <th key={id} scope="col" className="px-5 py-4 align-top">
                  <ProviderHeader id={id} result={data.providers[id]} info={infoOf(id)} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => {
              const differs = row.differs?.(results) ?? false;
              return (
                <tr key={row.key} className="border-b border-white/[0.05] last:border-0">
                  <th scope="row" className="px-5 py-3.5 text-xs font-medium text-slate-500">
                    {row.label}
                    {differs && (
                      <span className="ml-2 rounded bg-amber-400/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-300" title="Providers report different values">
                        differs
                      </span>
                    )}
                  </th>
                  {PROVIDER_IDS.map((id) => {
                    const c = cellText(data.providers[id], row.get);
                    return (
                      <td key={id} className={`px-5 py-3.5 text-sm ${c.muted ? 'text-slate-600' : 'font-semibold text-slate-100'} ${row.key === 'coords' || row.key === 'asn' ? 'font-mono' : ''}`}>
                        {c.text}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile: one card per provider */}
      <div className="grid gap-4 sm:hidden">
        {PROVIDER_IDS.map((id) => (
          <section key={id} className="data-card" aria-label={NAMES[id]}>
            <div className="mb-2"><ProviderHeader id={id} result={data.providers[id]} info={infoOf(id)} /></div>
            <dl>
              {rows.map((row) => {
                const c = cellText(data.providers[id], row.get);
                return (
                  <div key={row.key} className="flex items-baseline justify-between gap-4 border-b border-white/[0.06] py-2.5 last:border-0">
                    <dt className="shrink-0 text-xs text-slate-500">{row.label}</dt>
                    <dd className={`min-w-0 break-words text-right text-sm ${c.muted ? 'text-slate-600' : 'font-semibold text-slate-100'}`}>{c.text}</dd>
                  </div>
                );
              })}
            </dl>
          </section>
        ))}
      </div>

      {notes.map((n) => (
        <p key={n.id} className="mt-3 text-xs leading-5 text-slate-500">
          <span className="font-semibold text-slate-400">{NAMES[n.id]}:</span> {n.note}
        </p>
      ))}
      <p className="mt-3 text-xs leading-5 text-slate-500">
        IP geolocation is approximate. It usually identifies the area of an internet provider's network, not a street address.
      </p>
    </div>
  );
}

interface Props {
  data: LookupResponse;
  loading: boolean;
  isOwn: boolean;
  infos: ProviderInfo[];
}

export default function Results({ data, loading, isOwn, infos }: Props) {
  const s = data.summary;
  const place = locationLine(s);
  const apiPath = isOwn ? '/api/v1/ip' : `/api/v1/ip/${encodeURIComponent(data.ip)}`;

  return (
    <div className={loading ? 'opacity-60 transition-opacity' : 'transition-opacity'} aria-live="polite">
      <div className="result-panel">
        <div className="map-lines" />
        {s?.latitude != null && <div className="map-pulse hidden xl:block" />}
        <div className="relative z-10 flex flex-col gap-6 p-6 sm:p-8 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <p className="section-label">{isOwn ? 'Your IP address' : 'IP address'}</p>
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <h2 className="break-all font-mono text-3xl font-medium tracking-tight text-white sm:text-5xl">{data.ip}</h2>
              <span className="rounded-md border border-cyan-300/20 bg-cyan-300/10 px-2 py-1 text-[11px] font-bold text-cyan-200">IPv{data.version}</span>
            </div>
            {data.is_public ? (
              <p className="mt-3 text-base text-slate-300">{place || 'Location unknown'}</p>
            ) : null}
          </div>
          <div className="flex flex-wrap gap-2.5">
            <CopyButton text={data.ip} label="Copy IP" />
            {s?.latitude != null && s.longitude != null && (
              <a href={openStreetMapUrl(s.latitude, s.longitude)} target="_blank" rel="noopener noreferrer" className="button-secondary">
                Open map <Icon name="external" className="h-4 w-4" />
              </a>
            )}
            <a href={`${apiPath}?pretty=1`} target="_blank" rel="noopener noreferrer" className="button-secondary">
              JSON <Icon name="external" className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>

      {!data.is_public && (
        <div className="mt-5 flex gap-3 rounded-xl border border-amber-400/25 bg-amber-400/[0.06] p-5 text-sm leading-6 text-amber-100">
          <Icon name="alert" className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" />
          <div>
            <p className="font-semibold">{data.notice ?? 'This address has no public location data.'}</p>
            <p className="mt-1 text-amber-100/80">
              Private, loopback and reserved addresses only exist inside local networks. Try a public address such as 8.8.8.8, or visit this site from a public connection to see your own details.
            </p>
          </div>
        </div>
      )}

      {data.is_public && !s && (
        <div className="mt-5 rounded-xl border border-white/10 bg-white/[0.03] p-5 text-sm text-slate-300">
          None of the databases has a record for this address yet. Not every IP is covered.
        </div>
      )}

      {data.is_public && s && (
        <div className="mt-6 space-y-12">
          <Overview data={data} />
          <Comparison data={data} infos={infos} />
          <details className="group rounded-xl border border-white/[0.075] bg-[#0b1a29]/50">
            <summary className="cursor-pointer select-none px-5 py-4 text-sm font-semibold text-slate-300 hover:text-white">Raw JSON response</summary>
            <div className="relative border-t border-white/[0.06]">
              <pre className="max-h-96 overflow-auto p-5 text-xs leading-6 text-slate-300">{JSON.stringify(data, null, 2)}</pre>
            </div>
          </details>
        </div>
      )}
    </div>
  );
}
