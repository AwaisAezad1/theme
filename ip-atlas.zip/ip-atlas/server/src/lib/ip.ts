import net from 'node:net';
import ipaddr from 'ipaddr.js';

export interface ParsedIp {
  /** Canonical text form (IPv4 dotted quad, or compressed IPv6). IPv4-mapped IPv6 is unwrapped to IPv4. */
  ip: string;
  version: 4 | 6;
  /** True only for globally routable unicast addresses that can have geolocation data. */
  isPublic: boolean;
  /** Machine-friendly label of the address range ("public", "private", "loopback", ...). */
  range: string;
}

const RANGE_LABELS: Record<string, string> = {
  unicast: 'public',
  uniqueLocal: 'private',
  linkLocal: 'link-local',
  carrierGradeNat: 'carrier-grade-nat',
  ipv4Mapped: 'ipv4-mapped',
};

/**
 * Strictly parse user input as an IP address.
 * Returns null for anything that is not a plain IPv4 (four decimal parts) or IPv6 address.
 * Rejects zone ids ("fe80::1%eth0"), CIDR, ports, inner whitespace, and legacy shorthand like "1.2" or "0x7f.1".
 */
export function parseIp(input: string): ParsedIp | null {
  if (typeof input !== 'string') return null;
  let value = input.trim();
  if (value.startsWith('[') && value.endsWith(']')) value = value.slice(1, -1);
  if (value.length === 0 || value.length > 45) return null;
  if (/[%/\s]/.test(value)) return null;
  if (net.isIP(value) === 0) return null;

  let addr: ipaddr.IPv4 | ipaddr.IPv6;
  try {
    addr = ipaddr.parse(value);
  } catch {
    return null;
  }

  if (addr.kind() === 'ipv6' && (addr as ipaddr.IPv6).isIPv4MappedAddress()) {
    addr = (addr as ipaddr.IPv6).toIPv4Address();
  }

  const rangeName = addr.range();
  return {
    ip: addr.toString(),
    version: addr.kind() === 'ipv4' ? 4 : 6,
    isPublic: rangeName === 'unicast',
    range: RANGE_LABELS[rangeName] ?? rangeName,
  };
}

// ---------------------------------------------------------------------------
// Trusted proxy handling
// ---------------------------------------------------------------------------

const NAMED_RANGES: Record<string, string[]> = {
  loopback: ['127.0.0.0/8', '::1/128'],
  linklocal: ['169.254.0.0/16', 'fe80::/10'],
  uniquelocal: ['10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', 'fc00::/7'],
};
NAMED_RANGES.private = [...NAMED_RANGES.loopback!, ...NAMED_RANGES.linklocal!, ...NAMED_RANGES.uniquelocal!];

/**
 * Build a predicate telling whether a connecting socket address is a trusted reverse proxy.
 * Spec: comma separated list of "true", "false", named ranges (loopback, linklocal, uniquelocal, private),
 * single IPs and CIDR blocks.
 */
export function buildTrustedProxyCheck(spec: string): (address: string | undefined) => boolean {
  const tokens = spec
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean);

  if (tokens.length === 0 || (tokens.length === 1 && tokens[0]!.toLowerCase() === 'false')) {
    return () => false;
  }
  if (tokens.some((t) => t.toLowerCase() === 'true')) {
    return () => true;
  }

  const ranges: Array<[ipaddr.IPv4 | ipaddr.IPv6, number]> = [];
  const add = (cidr: string) => {
    try {
      if (cidr.includes('/')) {
        ranges.push(ipaddr.parseCIDR(cidr));
      } else {
        const a = ipaddr.parse(cidr);
        ranges.push([a, a.kind() === 'ipv4' ? 32 : 128]);
      }
    } catch {
      throw new Error(
        `Invalid TRUST_PROXY entry "${cidr}". Use true, false, loopback, linklocal, uniquelocal, an IP or a CIDR.`,
      );
    }
  };
  for (const token of tokens) {
    const named = NAMED_RANGES[token.toLowerCase()];
    if (named) named.forEach(add);
    else add(token);
  }

  return (address) => {
    if (!address) return false;
    let addr: ipaddr.IPv4 | ipaddr.IPv6;
    try {
      addr = ipaddr.process(address);
    } catch {
      return false;
    }
    return ranges.some(([range, bits]) => addr.kind() === range.kind() && addr.match(range, bits));
  };
}
