<?php
/**
 * Theme setup and configuration.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function wds_setup() {
    load_theme_textdomain(
        'wp-developer-starter',
        WDS_DIR . '/languages'
    );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'custom-background' );

    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );

    add_theme_support(
        'customize-selective-refresh-widgets'
    );

    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu', 'wp-developer-starter' ),
            'footer'  => __( 'Footer Menu', 'wp-developer-starter' ),
        )
    );
}
add_action( 'after_setup_theme', 'wds_setup' );

/**
 * Set content width.
 */
function wds_content_width() {
    $GLOBALS['content_width'] = 1200;
}
add_action( 'after_setup_theme', 'wds_content_width', 0 );
